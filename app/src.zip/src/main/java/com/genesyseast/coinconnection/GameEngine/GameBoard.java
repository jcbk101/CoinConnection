package com.genesyseast.coinconnection.GameEngine;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.genesyseast.coinconnection.CustomControls.BoardTile;
import com.genesyseast.coinconnection.GameGraphics.CardsGridLayout;
import com.genesyseast.coinconnection.GameGraphics.ConnectionsGridLayout;
import com.genesyseast.coinconnection.R;
import com.genesyseast.coinconnection.Variables.PointXYZ;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public class GameBoard
{
    public              ArrayList<BoardTile>  boardTiles;
    public              int[][]               boardMap;
    //
    private             int                   mapDataIndex;
    private             int                   mapWidth;
    private             int                   mapHeight;
    private             int                   maxTiles;
    private             int                   mapColors;
    //
    public              ConnectionsGridLayout connectionsGrid;
    public              CardsGridLayout       cardsGrid;
    //
    public static       GameBoard             instance;
    //
    private             GameEngine            gameEngine;
    private             Context               context;
    // Mapping data for the board images
    public              int[]                 gemsPerLevel;
    public              int[]                 xmlMapBgs;
    public              int[]                 xmlMapColors;
    public              int[]                 xmlTargets;
    // Background images for the main playing area
    public              int[]                 xmlBackgrounds;
    //
    public              int[]                 cardSet;
    public static       int[]                 coinSet;
    public static       int[]                 coinGlow;
    public static       int[]                 coinBg;
    public static       int[]                 coinSpinSpeed;
    public              int                   maxColors;
    public              int                   maxGems;
    public              int                   maxTargets;
    public              int                   neededPoints;
    public              String                objMessage;
    private             int[][]               test            = {
            { 4, 5, 0, 2, 0, 3, 0 }, // 0
            { 2, 1, 4, 5, 1, 2, 4 }, // 1
            { 5, 2, 3, 3, 4, 3, 2 },// 2
            { -1, 6, 6, 4, 5, 0, -1 }, // 3
            { 3, 1, 3, 2, 6, 0, 1 }, // 4
            { 5, 6, 0, 4, 1, 5, 3 }, // 5
            { 2, 1, 3, 6, 1, 3, 5 } // 6
    };
    //
    public static       ArrayList<TextView>   targetViewsList = new ArrayList<>();
    public static final int                   BASE_CARDS      = 4;
    
    
    /**
     * Getters for current map Width, Height, and Max Color
     *
     * @return
     */
    public int getMapWidth()
    {
        return mapWidth;
    }
    
    public int getMapHeight()
    {
        return mapHeight;
    }
    
    public int getMapColors()
    {
        return mapColors;
    }
    
    public int getMaxTiles()
    {
        return maxTiles;
    }
    
    public ArrayList<BoardTile> getBoardTiles()
    {
        return boardTiles;
    }
    
    public int[][] getBoardMap()
    {
        return boardMap;
    }
    
    public int[] getCoinSet()
    {
        return coinSet;
    }

    public int[] getCoinGlow()
    {
        return coinGlow;
    }
    
    public int getMaxColors()
    {
        return maxColors;
    }
    
    public int[] getCoinBg()
    {
        return coinBg;
    }
    
    public int[] getCardSet()
    {
        return cardSet;
    }
    
    
    /**
     * //####################################
     * <p>
     * No instantiated allowed!
     * <p>
     * //####################################
     */
    private GameBoard( Context context )
    {
        this.context = context;
        gameEngine = GameEngine.getInstance( context );
        
        // Determine the max colors by the current level
        xmlMapColors = context.getResources().getIntArray( R.array.colors_per_level );
        
        // Determine the max coin match targets by the current level
        xmlTargets = context.getResources().getIntArray( R.array.targets_per_level );
        
        
        // Process Map sizes, Data, and BGs: Convert the Resource Array Pointer
        // to index of usable resource array values
        TypedArray arrays;
        TypedArray coins_set;
        
        //############################
        // Map Board images
        //############################
        arrays = context.getResources().obtainTypedArray( R.array.xmlMapBG );
        xmlMapBgs = new int[ arrays.length() ];
        //
        for ( int i = 0; i < arrays.length(); i++ )
        {
            xmlMapBgs[ i ] = arrays.getResourceId( i, 0 );
        }
        
        //############################
        // Board icons: Coins
        //############################
        arrays = context.getResources().obtainTypedArray( R.array.coin_icon_list );
        
        // Symbols on the board
        coinSet = new int[ arrays.length() ];
        
        //
        for ( int i = 0; i < arrays.length(); i++ )
        {
            // Read in each integer Resource ID
            coinSet[ i ] = arrays.getResourceId( i, 0 );
        }
        
        
        arrays = context.getResources().obtainTypedArray( R.array.coin_glow_list );
        
        // Symbols on the board glow
        coinGlow = new int[ arrays.length() ];
        
        //
        for ( int i = 0; i < arrays.length(); i++ )
        {
            // Read in each integer Resource ID
            coinGlow[ i ] = arrays.getResourceId( i, 0 );
        }
        
        
        //############################
        // Board icons: Cards
        //############################
        arrays = context.getResources().obtainTypedArray( R.array.card_icon_list );
        cardSet = new int[ arrays.length() ];
        
        //
        for ( int i = 0; i < arrays.length(); i++ )
        {
            // Cards
            cardSet[ i ] = arrays.getResourceId( i, 0 );
        }
        
        
        //############################
        // Game Playfield Backgrounds
        //############################
        arrays = context.getResources().obtainTypedArray( R.array.game_bgs );
        xmlBackgrounds = new int[ arrays.length() ];
        //
        for ( int i = 0; i < arrays.length(); i++ )
        {
            xmlBackgrounds[ i ] = arrays.getResourceId( i, 0 );
        }
        
        // Recycle baby!
        arrays.recycle();
    }
    
    
    /**
     * //####################################
     * <p>
     * Create a single instance only
     * <p>
     * //####################################
     *
     * @return
     */
    public static synchronized GameBoard getInstance( Context context )
    {
        if ( instance == null )
        {
            instance = new GameBoard( context );
        }
        
        return instance;
    }
    
    
    /**
     * //####################################
     * <p>
     * Build the board based on the
     * loaded map data for Connections Game
     * <p>
     * //####################################
     *
     * @param context N/A
     * @param view    N/A
     */
    public void BuildConnectionsBoard( Context context, int currentBoard, ArrayList<BoardTile> boardTiles, View view )
    {
        Random    r     = new Random();
        BoardTile tile;
        int[][]   mapData;
        int       index = currentBoard;
        int       level;
        int       maxCoins;
        int       coinCountTotal;
        int       gemCountTotal;
        
        
        //
        // Need the dimensions
        //
        mapWidth = 7;
        mapHeight = 7;
        maxTiles = (mapHeight * mapWidth);
        
        
        // Mapping index for the board
        this.mapDataIndex = currentBoard;
        
        // Add data to the board tiles by filling
        // the ArrayList with Mapping data
        this.boardTiles = boardTiles;
        
        // Place the map in 2D Array for for easier access
        boardMap = new int[ mapHeight ][ mapWidth ];
        boardTiles.clear();
        
        // Get the current level for the current area
        level = GameEngine.currentLevel;
        
        
        //########################################
        // (32 Areas / 4) == 8 advanced starting
        // levels for coin colors
        //########################################
        index = level;
        index += (GameEngine.currentLevel / 4);
        //
        if ( index >= GameEngine.MAX_LEVEL_COLORS )
        {
            // Can't be higher than MAX_LEVEL_COLORS
            index = (GameEngine.MAX_LEVEL_COLORS - 1);
        }
        
        
        //#################################
        //
        // Make it a little harder
        //
        //#################################
        //        int[]    adjust    = context.getResources().getIntArray( R.array.area_adjust );
        String[] adjust = context.getResources().getStringArray( R.array.area_adjust );
        String[] list   = context.getResources().getStringArray( R.array.connections_targets );
        
        String[] targetSet = list[ level % 18 ].split( "," );
        
        // TODO: remove this code. all will be XML
        String[] adjustSet = adjust[ GameEngine.currentLevel % 32 ].split( "," );
        int      min, max, adj, bg_type;
        
        // Coin targets
        min = Integer.parseInt( targetSet[ 0 ].trim() );
        // Jewel targets
        max = Integer.parseInt( targetSet[ 1 ].trim() );
        
        // Area adjustments
        adj = Integer.parseInt( adjustSet[ 0 ].trim() );
        bg_type = Integer.parseInt( adjustSet[ 1 ].trim() );
        
        
        // Value is inclusive
        maxCoins = r.nextInt( min + adj ) + 1;
        
        // Value is inclusive
        maxGems = r.nextInt( max + adj ) + 1;
        
        
        //##############################
        //
        // Do not give gems if not ready
        //
        //##############################
        if ( max == 0 && GameEngine.currentLevel == 0 )
        {
            maxGems = 0;
        }
        
        // Set a universal target count for both types
        if ( maxGems > 4 )
        {
            maxGems = 4;
        }
        
        
        //##############################
        //
        // Get the max colors we can use
        //
        //##############################
        // TODO fix all this shit!
        maxColors = xmlMapColors[ index % xmlMapColors.length ];
        
        // Sometimes, we don't want gems
        if ( maxCoins > 3 )
        {
            if ( r.nextBoolean() && maxGems >= 4 )
            {
                maxGems = r.nextInt( 4 );
            }
        }
        
        //
        if ( maxGems > 0 )
        {
            if ( maxCoins >= BoardTile.MAX_COINS )
            {
                // Remove the gold coin. Game will be too hard
                maxCoins = BoardTile.MAX_COINS - 1;
            }
            
            //
            if ( maxColors >= BoardTile.MAX_COINS )
            {
                maxColors = BoardTile.MAX_COINS - 1;
            }
        }
        else
        {
            // No gems were loaded
            if ( maxCoins >= BoardTile.MAX_COINS )
            {
                // Remove the gold coin. Game will be too hard
                maxCoins = BoardTile.MAX_COINS;
            }
            
            //
            if ( maxColors >= BoardTile.MAX_COINS )
            {
                maxColors = BoardTile.MAX_COINS;
            }
        }
        
        //
        maxTargets = (maxCoins + maxGems);
        
        
        //############################
        //
        // Max time allowed
        //
        //############################
        TypedArray arrays = context.getResources().obtainTypedArray( R.array.time_allowed );
        
        int[] timeList = new int[ arrays.length() ];
        //
        for ( int i = 0; i < arrays.length(); i++ )
        {
            String value = arrays.getString( i );
            
            if ( value != null )
            {
                timeList[ i ] = ( int ) (Double.parseDouble( value ) * 60000f);
            }
        }
        
        // Add a few seconds for harder levels
        // TODO remove this code. in XML
        gameEngine.timeAllowed = timeList[ GameEngine.currentLevel % 18 ];
        //        gameEngine.timeAllowed += (adjust[ gameEngine.loadedArea ] * 15000);
        gameEngine.timeAllowed += (Integer.parseInt( adjustSet[ 0 ] ) * 15000);
        //        gameEngine.timeAllowed = 20000;
        arrays.recycle();
        
        
        //#############################################
        //
        // Build the main board
        //
        //#############################################
        
        // Get the mapping data set
        mapData = getCoinMapFormat( xmlMapBgs[ currentBoard ], mapWidth, mapHeight );
        
        for ( int y = 0; y < mapHeight; y++ )
        {
            for ( int x = 0; x < mapWidth; x++ )
            {
                // Each entry in each column of the current row
                index = mapData[ y ][ x ];
                
                //
                // VALID Tile type
                //
                if ( index != 0 )
                {
                    // Display the tile immediately
                    tile = new BoardTile( context, BoardTile.STATE_ACTIVE, (y * mapWidth) + x );
                    tile.setScaleType( ImageView.ScaleType.FIT_CENTER );
                    
                    //
                    index = r.nextInt( maxColors );
                    
                    // Assign a color to the new tile
                    tile.tileNum = index;
                    
                    // DEBUG
                    //                        tile.tileNum = test[ y ][ x ];
                    
                    tile.specialItem = 0;
                    boardTiles.add( tile );
                    boardMap[ y ][ x ] = 1;
                    
                    // The value is good
                    continue;
                }
                
                //
                // Default to here: INVALID Tile type
                //
                tile = new BoardTile( context, BoardTile.STATE_INACTIVE, (y * mapWidth) + x );
                tile.tileNum = -1;
                tile.specialItem = 0;
                boardMap[ y ][ x ] = -1;
                
                // Add the processed tile
                boardTiles.add( tile );
            }
        }
        
        //
        connectionsGrid = view.findViewById( R.id.boardGridLayout );
        connectionsGrid.removeAllViews();
        connectionsGrid.setMapHeight( mapHeight );
        connectionsGrid.setMapWidth( mapWidth );
        connectionsGrid.setMainView( view );
        
        
        // To fix bugs
/*
        boardTiles.get( 8 ).tileNum = BoardTile.PURLE_GEM;
        boardTiles.get( 8 ).specialItem = 3;
    
        boardTiles.get( 9 ).tileNum = 0;
        boardTiles.get( 15 ).tileNum = 0;
        boardTiles.get( 21 ).tileNum = 0;
*/
        
        
        //###################################
        // IMPORTANT!!!!!!
        // Make sure we have at least a
        // single match!
        // NEVER include specials here
        //###################################
        boolean valid = connectionsGrid.checkIfMatchesExist( true, false );
        if ( !valid )
        {
            connectionsGrid.useShuffler( null );
        }
        
        
        //##################################
        //
        // Set up the "Target" coins
        //
        //##################################
        ViewGroup group = view.findViewById( R.id.boardTargetHolder );
        int       count = group.getChildCount();
        
        // Clear this list of targets
        targetViewsList.clear();
        
        for ( int i = 0; i < count; i++ )
        {
            View v = group.getChildAt( i );
            
            if ( v instanceof TextView && v.getId() != R.id.targetText )
            {
                targetViewsList.add( ( TextView ) v );
                v.setVisibility( View.GONE );
            }
        }
        
        
        //####################################
        //
        // Choose the colors we wish to use
        //
        //####################################
        ArrayList<Integer> coinsList = new ArrayList<>();
        
        //
        coinsList.clear();
        // If Less than what we will display
        // then randomly select colors to target
        if ( maxCoins < maxColors )
        {
            int color;
            
            while ( coinsList.size() < maxCoins )
            {
                color = r.nextInt( maxColors );
                if ( coinsList.contains( color ) )
                {
                    continue;
                }
                
                // Add it to the buffer
                coinsList.add( color );
            }
        }
        else
        {
            // Add all colors to the list
            for ( int i = 0; i < maxColors; i++ )
            {
                coinsList.add( i );
            }
        }
        
        
        //####################################
        //
        // Set status of each target and the
        // amount needed for completion
        //
        //####################################
        coinCountTotal = 0;
        for ( int i = 0; i < coinsList.size(); i++ )
        {
            TextView v     = targetViewsList.get( coinsList.get( i ) );
            PointXYZ point = new PointXYZ();
            
            //            count = r.nextInt( 10 + (gameEngine.loadedArea / 2) ) + xmlTargets[ index ];
            count = r.nextInt( 10 + (GameEngine.currentLevel * 2) ) + xmlTargets[ index ];
            
            if ( GameEngine.debugMode )
            {
                count = 1;
            }
            
            // Use this to set a points requirement number
            coinCountTotal += count;
            
            // Count
            point.x = count;
            // Index into Targets Array
            point.y = coinsList.get( i );
            //
            v.setTag( point );
            v.setVisibility( View.INVISIBLE );
            v.setText( String.format( Locale.getDefault(), "%2d", count ) );
        }
        
        
        //####################################
        //
        // Because "Specials" follow, Gems
        // must be added here
        //
        //####################################
        gemCountTotal = 0;
        if ( maxGems > 0 )
        {
            coinsList.clear();
            coinsList = connectionsGrid.findGemSlot( maxGems );
            
            for ( int i = 0; i < coinsList.size(); i++ )
            {
                TextView v     = targetViewsList.get( coinsList.get( i ) + BoardTile.MAX_COINS );
                PointXYZ point = new PointXYZ();
                
                //                count = r.nextInt( 1 + adjust[ gameEngine.loadedArea ] ) + 1;
                count = r.nextInt( 1 + Integer.parseInt( adjustSet[ 0 ] ) ) + 1;
                
                if ( GameEngine.debugMode )
                {
                    count = 2;
                }
                
                // Gems per slot
                gemCountTotal += count;
                
                // Count
                point.x = count;
                // Index into Targets Array
                //                point.y = (coinsList.get( i ) - BoardTile.MAX_COINS) + BoardTile.RED_GEM;
                point.y = (coinsList.get( i ) + BoardTile.RED_GEM);
                
                //
                v.setTag( point );
                v.setVisibility( View.INVISIBLE );
                v.setText( String.format( Locale.getDefault(), "%2d", count ) );
            }
        }
        
        
        //####################################
        //
        // Any special carrying over from
        // last game?
        //
        //####################################
        for ( int i = 0; i < gameEngine.savedSpecials.size(); i++ )
        {
            PointXYZ c = gameEngine.savedSpecials.get( i );
            tile = boardTiles.get( c.x );
            
            //
            if ( tile.tileNum != -1 )
            {
                if ( tile.tileNum < BoardTile.BOMB )
                {
                    tile.tileNum = c.y;
                    tile.specialItem = c.z;
                    tile.specialTile = ( int ) c.degree;
                }
                else
                {
                    int next = r.nextInt( boardTiles.size() );
                    tile = boardTiles.get( next );
                    
                    //
                    while ( tile.tileNum == -1 || boardTiles.get( next ).tileNum >= BoardTile.BOMB )
                    {
                        next = r.nextInt( boardTiles.size() );
                        tile = boardTiles.get( next );
                    }
                    
                    //
                    tile.tileNum = c.y;
                    tile.specialItem = c.z;
                    tile.specialTile = ( int ) c.degree;
                }
            }
        }
        
        
        // No longer required
        gameEngine.savedSpecials.clear();
        
        
        //#################################
        //
        // Select the Objective Message
        //
        //#################################
        
        // Should we add point requirement
        String[] messages  = context.getResources().getStringArray( R.array.connections_messages );
        String[] panelsStr = new String[]{ "Remove back panels", "Remove all gem bags;", "Remove all chests;", "Remove all chests and gem bags;" };
        String   barf;
        boolean  pointsReq = r.nextBoolean();
        boolean  panelsReq = false;
        
        
        GameEngine.penaltyMode = false;
        if ( maxCoins > 1 )
        {
            // Can't do penalty with only one coin
            // Do we want a penalty mode?
            GameEngine.penaltyMode = (r.nextInt( 3 ) == 1);
            if ( GameEngine.penaltyMode )
            {   // Never require points with penalty mode!
                pointsReq = false;
            }
        }
        
        //
        // Build the string. Include back panels
        if ( bg_type > 0 )
        {
            panelsReq = r.nextBoolean();
            
            // Disable for now
            panelsReq = false;
        }
        //
        bg_type = -1;
        
        //
        if ( maxGems == 0 )
        {
            if ( !pointsReq )
            {
                barf = (panelsReq ? panelsStr[ 0 ] : "");
                
                neededPoints = 0;
                objMessage = String.format( Locale.getDefault(), messages[ 0 ], maxCoins, barf );
                if ( panelsReq )
                {
                    // Remove all back panels by solving matches
                    bg_type = 0;
                }
            }
            else
            {
                barf = (panelsReq ? panelsStr[ 2 ] : "");
                
                // Minimum 3 per match!
                coinCountTotal *= 2;
                neededPoints = (coinCountTotal * GameEngine.POINTS_PER_TILE);
                objMessage = String.format( Locale.getDefault(), messages[ 1 ], maxCoins, neededPoints, barf );
                if ( panelsReq )
                {
                    // Add random chest that either give points
                    // or are mimics that take points / add to coin targets
                    bg_type = 2;
                }
            }
        }
        else if ( maxGems > 0 )
        {
            if ( !pointsReq )
            {
                barf = (panelsReq ? panelsStr[ 1 ] : "");
                
                neededPoints = 0;
                objMessage = String.format( Locale.getDefault(), messages[ 2 ], maxCoins, maxGems, barf );
                if ( panelsReq )
                {
                    // Add random gem bags that either simply expose Gems
                    // or expose gems AFTER adding to gem count / take points
                    bg_type = 1;
                }
            }
            else
            {
                barf = (panelsReq ? panelsStr[ 3 ] : "");
                
                // Minimum 3 per match!
                coinCountTotal *= 2;
                neededPoints = (coinCountTotal * GameEngine.POINTS_PER_TILE);
                neededPoints += (gemCountTotal * GameEngine.POINTS_PER_GEM);
                //
                objMessage = String.format( Locale.getDefault(), messages[ 3 ], maxCoins, neededPoints, maxGems, barf );
                if ( panelsReq )
                {
                    // Add random chest and gem bags that either simply expose Gems / give points
                    // or expose gems AFTER adding to gem count / take points / add to coin targets
                    bg_type = 3;
                }
            }
        }
        
        
        //
        // If it's level 16 , then inform the player of the shorter time
        //
        if ( (level + 1) == 16 )
        {
            objMessage = messages[ 4 ] + objMessage;
        }
        
        //        if ( (level + 1) == 17 && gameEngine.loadedArea > (GameEngine.MAX_AREAS / 2) )
        if ( GameEngine.penaltyMode )
        {
            objMessage = messages[ 5 ] + objMessage;
        }
        
        //############################
        //
        // Update the grid
        //
        //############################
        connectionsGrid.onDrawGrid();
    }
    
    
    /**
     * //####################################
     * <p>
     * Build the board based on the
     * loaded map data for Cards Game
     * <p>
     * //####################################
     *
     * @param context N/A
     * @param view    N/A
     */
    public void BuildCardsBoard( Context context, int currentBoard, ArrayList<BoardTile> boardTiles, View view )
    {
        Random     r        = new Random();
        BoardTile  tile;
        int[][]    mapData;
        int        index    = currentBoard;
        int        level;
        TypedArray arrays;
        String[]   messages = context.getResources().getStringArray( R.array.cards_messages );
        
        
        //#################################
        //
        // Need the dimensions
        //
        //#################################
        mapWidth = 8;
        mapHeight = 8;
        maxTiles = (mapHeight * mapWidth);
        neededPoints = 0;
        
        // Add data to the board tiles by filling
        // the ArrayList with Mapping data
        this.boardTiles = boardTiles;
        
        
        // Place the map in 2D Array for for easier access
        boardMap = new int[ mapHeight ][ mapWidth ];
        boardTiles.clear();
        
        
        // Get the current level for the current area
        level = GameEngine.currentLevel;
        if ( level < 0 )
        {
            level = 0;
        }
        
        
        //########################################
        //
        // (32 Areas / 4) == 8 advanced starting
        // levels for coin colors
        //
        //########################################
        index = level;
        index += (GameEngine.currentLevel / 4);
        //
        if ( index >= GameEngine.MAX_LEVEL_COLORS )
        {
            // Can't be higher than MAX_LEVEL_COLORS
            index = (GameEngine.MAX_LEVEL_COLORS - 1);
        }
        
        
        //#################################
        //
        // Make it a little harder
        //
        //#################################
        String[] adjust    = context.getResources().getStringArray( R.array.area_adjust );
        String[] list      = context.getResources().getStringArray( R.array.cards_targets );
        String[] targetSet = list[ level ].split( "," );
        String[] adjustSet = adjust[ GameEngine.currentLevel ].split( "," );
        
        int min, max;
        
        // Coin targets
        max = Integer.parseInt( targetSet[ 0 ].trim() );
        maxColors = r.nextInt( max + Integer.parseInt( adjustSet[ 0 ] ) ) + 1;
        
        // Gem targets
        max = Integer.parseInt( targetSet[ 1 ].trim() );
        maxGems = r.nextInt( max + Integer.parseInt( adjustSet[ 0 ] ) ) + 1;
        
        //
        if ( maxColors > BoardTile.MAX_COINS )
        {
            maxColors = BoardTile.MAX_COINS;
        }
        //
        if ( maxGems > 4 )
        {
            maxGems = 4;
        }
        
        
        // Sometimes, we don't want gems
        if ( maxColors > 3 )
        {
            if ( r.nextBoolean() && maxGems >= 4 )
            {
                maxGems = r.nextInt( 4 );
            }
        }
        
        // Set a universal target count for both types
        maxTargets = (maxColors + maxGems);
        
        
        //#############################################
        //
        // Build the main board
        //
        //#############################################
        // Get the mapping data set
        arrays = context.getResources().obtainTypedArray( R.array.cards_map_data );
        TypedArray mapSet = context.getResources().obtainTypedArray( arrays.getResourceId( (currentBoard % arrays.length()), R.array.square_map ) );
        
        mapData = new int[ mapHeight ][ mapWidth ];
        
        //
        for ( int i = 0; i < mapSet.length(); i++ )
        {
            String value = mapSet.getString( i );
            
            if ( value != null )
            {
                String[] items = value.split( "," );
                
                for ( int x = 0; x < items.length; x++ )
                {
                    mapData[ i ][ x ] = Integer.parseInt( items[ x ] );
                }
            }
        }
        
        // Code clean up
        arrays.recycle();
        mapSet.recycle();
        
        //##################################
        //
        // Available tiles need to be
        // assigned
        //
        //##################################
        int           availableTiles = 0;
        List<Integer> cardList       = new ArrayList<>();
        
        for ( int y = 0; y < mapHeight; y++ )
        {
            for ( int x = 0; x < mapWidth; x++ )
            {
                // Each entry in each column of the current row
                index = mapData[ y ][ x ];
                
                //
                // VALID Tile type
                //
                if ( index != 0 )
                {
                    boardMap[ y ][ x ] = 1;
                    
                    availableTiles++;
                }
                else
                {
                    boardMap[ y ][ x ] = -1;
                }
            }
        }
        
        
        //###################################
        //
        // Do we have more targets than
        // available tiles
        //
        //###################################
        if ( availableTiles < (maxTargets * 2) )
        {
            while ( availableTiles < (maxTargets * 2) && maxTargets > 1 )
            {
                if ( maxColors >= maxGems )
                {
                    if ( maxColors > 0 )
                    {
                        maxColors--;
                    }
                }
                else
                {
                    if ( maxGems > 0 )
                    {
                        maxTargets--;
                    }
                }
                
                maxTargets = (maxColors + maxGems);
            }
        }
        
        //
        // Create random tiles
        int           colors  = 0;
        int           jewels  = 0;
        List<Integer> targets = new ArrayList<>();
        
        //
        for ( int i = 0; i < maxColors; i++ )
        {
            // Base cards "?", "Sad face", Hint card, ???-Card
            // Skip those
            cardList.add( BASE_CARDS + colors );
            cardList.add( BASE_CARDS + colors );
            
            //
            targets.add( colors );
            colors++;
        }
        
        //
        for ( int i = 0; i < maxGems; i++ )
        {
            // Base cards "?" and "Sad face"
            // Skip those
            cardList.add( BASE_CARDS + jewels + BoardTile.MAX_COINS );
            cardList.add( BASE_CARDS + jewels + BoardTile.MAX_COINS );
            
            //
            targets.add( jewels + BoardTile.MAX_COINS );
            jewels++;
        }
        
        
        // If we are giving a hint card to add hints
        if ( r.nextBoolean() )
        {
            // Hint card: Adds 1
            cardList.add( 2 );
            cardList.add( 2 );
        }
        
        // If we are giving a moves card to add moves
        if ( r.nextBoolean() )
        {
            // Move card: Adds 1 + what was used
            cardList.add( 3 );
            cardList.add( 3 );
        }
        
        //
        for ( int i = cardList.size(); i < availableTiles; i += 2 )
        {
            // Base cards "?", "Sad face", Hint, and ???-Card
            // We want to use sad faces for all unused tiles
            cardList.add( 1 );
            cardList.add( 1 );
        }
        
        //
        // Now shuffle the list and then place them
        //
        for ( int i = 0; i < 4; i++ )
        {
            Collections.shuffle( cardList );
            Collections.shuffle( cardList );
        }
        
        
        //#################################
        //
        // Build the map
        //
        //#################################
        int currentCard = 0;
        
        for ( int y = 0; y < mapHeight; y++ )
        {
            for ( int x = 0; x < mapWidth; x++ )
            {
                // Each entry in each column of the current row
                index = mapData[ y ][ x ];
                
                //
                // VALID Tile type
                //
                if ( index != 0 )
                {
                    // Display the tile immediately
                    tile = new BoardTile( context, BoardTile.STATE_ACTIVE, (y * mapWidth) + x );
                    tile.setScaleType( ImageView.ScaleType.FIT_CENTER );
                    
                    // Question mark box
                    tile.tileNum = cardSet[ 0 ];
                    // Array indexing. Subtract 2 for "?" and ":(" cards
                    tile.specialTile = cardList.get( currentCard );
                    tile.specialItem = -1;
                    // Flipped card images
                    tile.card[ 0 ] = cardSet[ 0 ];
                    tile.card[ 1 ] = cardSet[ cardList.get( currentCard ) ];
                    
                    //
                    if ( GameEngine.debugMode && tile.specialTile > 1 )
                    {
                        tile.card[ 0 ] = R.drawable.happy_face_emoji;
                        tile.tileNum = tile.card[ 0 ];
                    }
                    
                    //
                    if ( GameEngine.debugMode && (tile.card[ 1 ] == R.drawable.card_hint_glass_gold || tile.card[ 1 ] == R.drawable.card_free_moves_gold) )
                    {
                        tile.card[ 0 ] = R.drawable.sad_face_emoji;
                        tile.tileNum = tile.card[ 0 ];
                    }
                    
                    
                    currentCard++;
                    //
                    boardTiles.add( tile );
                    boardMap[ y ][ x ] = 1;
                    
                    // The value is good
                    continue;
                }
                
                //
                // Default to here: INVALID Tile type
                //
                tile = new BoardTile( context, BoardTile.STATE_INACTIVE, (y * mapWidth) + x );
                tile.tileNum = -1;
                tile.specialTile = -1;
                tile.specialItem = 1;
                tile.card[ 0 ] = -1;
                tile.card[ 1 ] = -1;
                //
                boardMap[ y ][ x ] = -1;
                
                // Add the processed tile
                boardTiles.add( tile );
            }
        }
        
        
        //
        // Send out a few messages
        //
        cardsGrid = view.findViewById( R.id.boardGridLayout );
        cardsGrid.removeAllViews();
        cardsGrid.setMapHeight( mapHeight );
        cardsGrid.setMapWidth( mapWidth );
        cardsGrid.setView_main( view );
        
        
        //##################################
        //
        // Set up the "Target" coins
        //
        //##################################
        ViewGroup group = view.findViewById( R.id.boardTargetHolder );
        int       count = group.getChildCount();
        
        // Clear this list of targets
        targetViewsList.clear();
        
        for ( int i = 0; i < count; i++ )
        {
            TextView v = ( TextView ) group.getChildAt( i );
            
            if ( v != null && v.getId() != R.id.targetText )
            {
                targetViewsList.add( v );
                v.setVisibility( View.GONE );
            }
        }
        
        
        //####################################
        //
        // Set status of each target and the
        // amount needed for completion
        //
        //####################################
        for ( int i = 0; i < targets.size(); i++ )
        {
            int c = targets.get( i );
            
            TextView v     = targetViewsList.get( c );
            PointXYZ point = new PointXYZ();
            
            count = 1;
            
            //
            point.x = count;
            v.setTag( point );
            v.setVisibility( View.INVISIBLE );
            v.setText( String.format( Locale.getDefault(), "%2d", count ) );
        }
        
        
        //#####################################
        //
        //
        //
        //#####################################
        int moveCount = 0;
        for ( BoardTile tiles : boardTiles )
        {
            if ( tiles.tileNum != -1 )
            {
                moveCount++;
            }
        }
        
        //
        // Time calculations used to make moves per level
        // a little more complex
        int[] timeDeduct = { 3, 3, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2 };
        //        int[] timeDeduct = { 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2 };
        
        // Set the maximum move amount for this level
        gameEngine.boardMoves = (moveCount - (moveCount / timeDeduct[ level ]));
        
        
        //#################################
        //
        // Select the Objective Message
        //
        //#################################
        if ( maxGems > 0 && maxColors > 0 )
        {
            objMessage = String.format( Locale.getDefault(), messages[ 0 ], gameEngine.boardMoves, maxColors, maxGems );
        }
        else if ( maxColors == 0 && maxGems > 0 )
        {
            objMessage = String.format( Locale.getDefault(), messages[ 1 ], gameEngine.boardMoves, maxGems );
        }
        else if ( maxColors > 0 && maxGems == 0 )
        {
            objMessage = String.format( Locale.getDefault(), messages[ 2 ], gameEngine.boardMoves, maxColors );
        }
        
        
        //############################
        //
        // Update the grid
        //
        //############################
        cardsGrid.onDrawGrid();
    }
    
    
    /**
     * //####################################
     * <p>
     * Prevent start game generated matches
     * When checking game matches, be sure to check both
     * game pieces being swapped
     * <p>
     * //####################################
     *
     * @param columnX   N/A
     * @param rowY      N/A
     * @param boardTile N/A
     *
     * @return N/A
     */
    public boolean DuplicateAt( int columnX, int rowY, int boardTile )
    {
        // Test to the left
        if ( columnX > 1 )
        {
            if ( boardTiles.get( (rowY * mapWidth) + (columnX - 1) ).tileNum == boardTile && boardTiles.get( (rowY * mapWidth) + (columnX - 2) ).tileNum == boardTile )
            {
                return true;
            }
        }
        
        // Test to the right
        if ( (columnX + 2) < mapWidth )
        {
            if ( ((rowY * mapWidth) + (columnX + 2)) < boardTiles.size() )
            {
                if ( boardTiles.get( (rowY * mapWidth) + (columnX + 1) ).tileNum == boardTile && boardTiles.get( (rowY * mapWidth) + (columnX + 2) ).tileNum == boardTile )
                {
                    return true;
                }
            }
        }
        
        // Test up
        if ( rowY > 1 )
        {
            
            if ( boardTiles.get( ((rowY - 1) * mapWidth) + columnX ).tileNum == boardTile && boardTiles.get( ((rowY - 2) * mapWidth) + columnX ).tileNum == boardTile )
            {
                return true;
            }
        }
        
        // Test down
        if ( (rowY + 2) < mapHeight )
        {
            
            if ( (((rowY + 2) * mapWidth) + columnX) < boardTiles.size() )
            {
                if ( boardTiles.get( ((rowY + 1) * mapWidth) + columnX ).tileNum == boardTile && boardTiles.get( ((rowY + 2) * mapWidth) + columnX ).tileNum == boardTile )
                {
                    return true;
                }
            }
        }
        
        
        return false;
    }
    
    
    /**
     * //####################################
     * <p>
     * Return a pixel from an image view at x/y location
     * <p>
     * //####################################
     *
     * @param resID
     * @param gridX
     * @param gridY
     *
     * @return
     */
    private int[][] getCoinMapFormat( int resID, int gridX, int gridY )
    {
        Bitmap  loadBmp;
        int     width;
        int     height;
        int     pixel  = 0;
        int[][] mapper = new int[ gridY ][ gridX ];
        
        
        // Try to detect the mapping
        try
        {
            loadBmp = BitmapFactory.decodeResource( context.getResources(), resID );
            height = (loadBmp.getHeight() / gridY);
            width = (loadBmp.getWidth() / gridX);
            
            // Split the image into tile sized sections if possible
            //            bitmaps = Bitmap.createBitmap( loadBmp, (x * width), (y * height), width, height );
            
            for ( int y = 0; y < gridY; y++ )
            {
                for ( int x = 0; x < gridX; x++ )
                {
                    pixel = loadBmp.getPixel( (x * width) + (width / 2), (y * height) + (height / 2) );
                    
                    if ( (pixel & 0xFF000000) == 0 )
                    {
                        mapper[ y ][ x ] = 0;
                    }
                    else
                    {
                        mapper[ y ][ x ] = 1;
                    }
                }
            }
        }
        catch ( Exception ex )
        {
            ex.printStackTrace();
        }
        
        
        return mapper;
    }
    
    
    /**
     * //####################################
     * <p>
     * Choose a board image to use
     * <p>
     * //####################################
     *
     * @param context
     *
     * @return
     */
    public static int getBoardImage( Context context, int currentBoardImage, boolean noDuplicate )
    {
        TypedArray   arrays     = context.getResources().obtainTypedArray( R.array.xmlMapBG );
        SecureRandom r          = new SecureRandom();
        GameEngine   gameEngine = GameEngine.getInstance( context );
        int          image;
        int          count      = 0;
        int          adjust;
        // TODO fix this mess
        int level  = GameEngine.currentLevel;
        int length = arrays.length();
        
        
        // We don't need anymore
        arrays.recycle();
        
        // Get the range that we can use
        if ( level > 7 && level < 16 )
        {
            // Using levels 9 to 16, start at images 18 - 35
            adjust = 18;
        }
        // Gold border, final board image for this area
        else if ( level == 16 )
        {
            // Using final level. There are 36 lower levels images
            // I made 32 Final Board images for 32 Areas
            // MOD the AREA value with 32 to not cause a crash
            return 36;
        }
        else
        {
            // Using levels 1 to 8, start at images 0 to 17
            adjust = 0;
        }
        
        
        if ( noDuplicate && currentBoardImage != -1 )
        {
            Integer index;
            image = currentBoardImage;
            
            // Do not want any duplicates. Not even in the same group of 4
            while ( count < 50 && (currentBoardImage >> 2) == (image >> 2) )
            {
                image = r.nextInt( 18 ) + adjust;
                
                // Not a good one yet
                index = image;
                if ( gameEngine.usedBG.contains( index ) )
                {
                    currentBoardImage = image;
                }
                
                count++;
            }
            
            // Add to the list
            gameEngine.usedBoard.add( image );
        }
        else
        {
            image = r.nextInt( 18 ) + adjust;
            gameEngine.usedBoard.add( image );
        }
        
        return image;
    }
    
    
    /**
     * //####################################
     * <p>
     * Test all board tiles for this tileNum
     * <p>
     * //####################################
     *
     * @param tileNum
     *
     * @return
     */
    public boolean hasBoardTile( int tileNum )
    {
        for ( BoardTile tile : boardTiles )
        {
            if ( tile.tileNum == tileNum )
            {
                return true;
            }
        }
        
        return false;
    }
}
