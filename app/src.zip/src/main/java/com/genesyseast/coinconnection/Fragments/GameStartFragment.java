package com.genesyseast.coinconnection.Fragments;


import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.Toast;

import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.widget.ShareDialog;
import com.genesyseast.coinconnection.CustomControls.ImageScroll;
import com.genesyseast.coinconnection.Dialogs.SettingsDialog;
import com.genesyseast.coinconnection.Support.AnimationValues;
import com.genesyseast.coinconnection.Support.CustomBounceInterpolator;
import com.genesyseast.coinconnection.Support.GameState;
import com.genesyseast.coinconnection.CustomControls.GradientTextView;
import com.genesyseast.coinconnection.Dialogs.AboutDialog;
import com.genesyseast.coinconnection.Dialogs.ErrorDialog;
import com.genesyseast.coinconnection.GameEngine.GameBoard;
import com.genesyseast.coinconnection.GameEngine.GameEngine;
import com.genesyseast.coinconnection.MainActivity;
import com.genesyseast.coinconnection.PlaySound.PlaySound;
import com.genesyseast.coinconnection.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class GameStartFragment
        extends Fragment
        implements View.OnClickListener
{
    public static String      APP_PNAME = "com.genesyseast.coinconnection";
    private       GameEngine  gameEngine;
    // This will be applied to each menu layout for the menu navagation
    private       View        view_main;
    private       ShareDialog shareDialog;
    
    
    private int[] long_buttons = {
            R.id.playResumeButton, R.id.playButton, R.id.settingsButton, R.id.aboutApp
    };
    
    private int[] square_buttons = {
            R.id.aboutApp, R.id.rateMe, R.id.emailButton, R.id.webpageButton, R.id.devApps, R.id.socialMedia
    };
    
    
    public GameStartFragment()
    {
    }
    
    
    /**
     * Build the views needed to display
     *
     * @param inflater           N/A
     * @param container          N/A
     * @param savedInstanceState N/A
     *
     * @return N/A
     */
    @Override
    public View onCreateView( LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState )
    {
        // Inflate the layout for this fragment
        view_main = inflater.inflate( R.layout.game_start_fragment, container, false );
        
        // Required empty public constructor
        gameEngine = GameEngine.getInstance( getContext() );
        
        
        //####################################
        //
        // Intercept the back key
        //
        //####################################
        view_main.setFocusableInTouchMode( true );
        view_main.requestFocus();
        view_main.setOnKeyListener( new View.OnKeyListener()
        {
            @Override
            public boolean onKey( View v, int keyCode, KeyEvent event )
            {
                if ( keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP )
                {
                    if ( getActivity() != null )
                    {
                        getActivity().onBackPressed();
                        return true;
                    }
                }
                
                return false;
            }
        } );
        
        
        //####################################
        // Animate the view
        // Start: Fade in
        // Return from a "pop fragment": previous view was faded out
        //####################################
        view_main.setAlpha( 0f );
        //
        
        initButtons();
        loadStartData( view_main );
        
        // Inflate the layout for this fragment
        return view_main;
    }
    
    
    /**
     * Universal data loader
     *
     * @param view_main
     */
    private void loadStartData( View view_main )
    {
        final View        title    = view_main.findViewById( R.id.mainTitle );
        final ImageScroll scroller = view_main.findViewById( R.id.bgScroller );
        
        
        if ( gameEngine.soundPlayer != null )
        {
            if ( !GameEngine.musicIsPlaying )
            {
                //@@@@@@@@@@@@@@@@@@@
                gameEngine.soundPlayer.playBgMusic( PlaySound.MENU_BG_GONE_FISHIN_BY_MEMORAPHILE, PlaySound.LOOP );
                gameEngine.currentBGMusic = PlaySound.MENU_BG_GONE_FISHIN_BY_MEMORAPHILE << 2;
            }
        }
        
        //
        scroller.scrollTheImage( 30000, 0, ValueAnimator.INFINITE );
        
        //
        title.setVisibility( View.VISIBLE );
        title.setAlpha( 1 );
        view_main.animate().setDuration( 1000 ).alpha( 1f ).withEndAction( new Runnable()
        {
            @Override
            public void run()
            {
                rateMyApp();
            }
        } ).start();
    }
    
    
    /**
     * //##############################
     * <p>
     * Get the button listeners and
     * animations started
     * <p>
     * //##############################
     */
    public void initButtons()
    {
        try
        {
            if ( getContext() != null && getActivity() != null )
            {
                
                GradientTextView button;
                
                //#############################
                //
                // Resume game button
                //
                //#############################
                if ( GameState.getSaveStatus( getContext() ) )
                {
                    button = view_main.findViewById( R.id.playResumeButton );
                    button.setOnClickListener( GameStartFragment.this );
                    
                    //
                    button.setVisibility( View.VISIBLE );
                    button.setScaleX( 0f );
                    button.setScaleY( 0f );
                    button.animate().scaleX( 1f ).scaleY( 1f ).setInterpolator( new CustomBounceInterpolator( .2, 20 ) );
                    button.animate().setDuration( AnimationValues.SLIDE_TIME );
                    button.animate().setStartDelay( (AnimationValues.FADE_TIME << 1) + (AnimationValues.FADE_TIME / 2) );
                    button.animate().start();
                }
                else
                {
                    button = view_main.findViewById( R.id.playResumeButton );
                    button.setOnClickListener( GameStartFragment.this );
                    button.setVisibility( View.GONE );
                }
                
                
                //#############################
                //
                // Show square buttons
                //
                //#############################
                for ( int i = 0; i < square_buttons.length; i++ )
                {
                    final View imgButton;
                    Animation  animation;
                    
                    imgButton = view_main.findViewById( square_buttons[ i ] );
                    imgButton.setOnClickListener( GameStartFragment.this );
                }
                
                //#############################
                //
                // Springy button
                //
                //#############################
                for ( int i = long_buttons.length - 1; i > -1; i-- )
                {
                    button = view_main.findViewById( long_buttons[ i ] );
                    button.setOnClickListener( GameStartFragment.this );
                }
                
                
                //#############################
                //
                // Spinning star over letter "N"
                //
                //#############################
                View                 star     = view_main.findViewById( R.id.titleSparkle );
                PropertyValuesHolder sx       = PropertyValuesHolder.ofFloat( "scaleX", 1, 1.3f, 1 );
                PropertyValuesHolder sy       = PropertyValuesHolder.ofFloat( "scaleY", 1, 1.3f, 1 );
                PropertyValuesHolder rot      = PropertyValuesHolder.ofFloat( "rotation", 0, 360 );
                ObjectAnimator       starAnim = ObjectAnimator.ofPropertyValuesHolder( star, sx, sy, rot );
                
                //
                starAnim.setDuration( 15000 ).setRepeatCount( ValueAnimator.INFINITE );
                starAnim.setInterpolator( new LinearInterpolator() );
                starAnim.start();
                star.setTag( starAnim );
                
                
                //#############################
                //
                // Exit App button
                //
                //#############################
                View exit = view_main.findViewById( R.id.exitButton );
                exit.setOnClickListener( GameStartFragment.this );
                
            }
        }
        catch ( Exception ex )
        {
            ex.printStackTrace();
        }
    }
    
    
    /**
     * Process all button clicks for the menu system
     *
     * @param v N/A
     */
    @Override
    public void onClick( View v )
    {
        final int id = v.getId();
        
        //#######################################
        //
        // Main menu buttons
        //
        //#######################################
        if ( gameEngine.soundPlayer != null )
        {
            gameEngine.soundPlayer.playBgSfx( PlaySound.BUTTON_CLICK );
        }
        
        
        //
        //        LevelSelector.pressedButtonClick( v ).start();
        
        if ( id == R.id.playResumeButton && getView() != null )
        {
            View view = getView();
            
            //@@@@@@@@@@@@@@@@@@@@@ Play game start sound
            if ( gameEngine.soundPlayer != null )
            {
                gameEngine.soundPlayer.playBgSfx( PlaySound.START_GAME );
            }
            
            // Clear Current BG and Board list data to prevent duplicates
            gameEngine.usedBG.clear();
            gameEngine.usedBoard.clear();
            
            
            if ( gameEngine.soundPlayer != null )
            {
                if ( GameEngine.musicIsPlaying )
                {
                    gameEngine.soundPlayer.fadeOutMusic();
                }
            }
            
            // Transition to LevelSelect
            // Or start a game if this is the first time playing!
            view.animate().alpha( 0f ).setDuration( AnimationValues.FADE_TIME ).withEndAction( new Runnable()
            {
                @Override
                public void run()
                {
                    int type = 0;
                    
                    // Skip level select if the game has NEVER been played!
                    gameEngine.resumeGame = true;
                    
                    // Add the level select, but do not show it
                    FragmentLoader.SwapFragment( getActivity(), getContext(), new LevelSelector(), FragmentLoader.STACK_REPLACE_FRAGMENT );
                    
                    if ( getContext() != null )
                    {
                        type = GameState.getSaveGameType( getContext() );
                    }
                    
                    //
                    if ( type == 0 )
                    {
                        // Start a Connections game!
                        FragmentLoader.SwapFragment( getActivity(), getContext(), new ConnectionsFragment(), FragmentLoader.STACK_REPLACE_FRAGMENT );
                    }
                    else
                    {
                        // Start a Card game!
                        FragmentLoader.SwapFragment( getActivity(), getContext(), new CardsFragment(), FragmentLoader.STACK_REPLACE_FRAGMENT );
                    }
                    
                    // Memory Leak?
                    gameEngine = null;
                }
            } ).start();
            
            return;
        }
        else if ( id == R.id.playButton && getView() != null )
        {
            View view = getView();
            
            //@@@@@@@@@@@@@@@@@@@@@ Play game start sound
            if ( gameEngine.soundPlayer != null )
            {
                gameEngine.soundPlayer.playBgSfx( PlaySound.START_GAME );
                //                gameEngine.sndPlayer.soundPool.unload( sound );
            }
            
            // Clear Current BG and Board list data to prevent duplicates
            gameEngine.usedBG.clear();
            gameEngine.usedBoard.clear();
            
            //##############################
            //
            // Transition to LevelSelect
            // Or start a game if this is
            // the first time playing!
            //
            //##############################
            view.animate().alpha( 0f ).setDuration( AnimationValues.FADE_TIME ).withEndAction( new Runnable()
            {
                @Override
                public void run()
                {
                    // Skip level select if the game has NEVER been played!
                    if ( GameEngine.currentLevel == 0 )
                    {
                        //####################################
                        // No need to continue if animations
                        // are disabled
                        //####################################
                        if ( getContext() != null && MainActivity.checkSystemAnimationsDuration( getContext() ) == 0 )
                        {
                            AlertDialog.Builder dialog = new AlertDialog.Builder( getContext() );
                            
                            dialog.setMessage(
                                    "This device currently has animations disabled. In order to use this app, animation support is required. Please enable device animations, and then restart the app. Thank you." );
                            dialog.setPositiveButton( "Exit", new DialogInterface.OnClickListener()
                            {
                                @Override
                                public void onClick( DialogInterface dialog, int which )
                                {
                                    if ( getActivity() != null )
                                    {
                                        getActivity().finish();
                                    }
                                    System.exit( 1 );
                                }
                            } );
                            
                            //
                            dialog.create().show();
                            return;
                        }
                        
                        //
                        // Sound Engine
                        //
                        if ( gameEngine.soundPlayer != null )
                        {
                            if ( GameEngine.musicIsPlaying )
                            {
                                gameEngine.soundPlayer.fadeOutMusic();
                            }
                        }
                        
                        // Add the level select, but do not show it
                        FragmentLoader.SwapFragment( getActivity(), getContext(), new LevelSelector(), FragmentLoader.STACK_REPLACE_FRAGMENT );
                        // Start a game!
                        FragmentLoader.SwapFragment( getActivity(), getContext(), new ConnectionsFragment(), FragmentLoader.STACK_REPLACE_FRAGMENT );
                        
                        //
                        if ( getContext() != null )
                        {
                            gameEngine.currentBoardImage = GameBoard.getBoardImage( getContext(), 0, false );
                        }
                    }
                    else
                    {
/*
                        FragementLoader.SwapFragment( getActivity(), getContext(), new GameCompleted(),
                                                      FragementLoader.STACK_REPLACE_FRAGMENT
                                                    );
                        
*/
                        FragmentLoader.SwapFragment( getActivity(), getContext(), new LevelSelector(), FragmentLoader.STACK_REPLACE_FRAGMENT );
                    }
                    
                    // Memory Leak?
                    gameEngine = null;
                }
            } ).start();
            
            return;
        }
        
        
        //##################################
        //
        // Load the game sounds to start
        // All others play default click
        //
        //##################################
        if ( id == R.id.exitButton && getActivity() != null )
        {
            // Save data to Shared pref file
            gameEngine.savePrefData();
            getActivity().finish();
            
            return;
        }
        else if ( id == R.id.settingsButton )
        {
            if ( getActivity() != null )
            {
                SettingsDialog dialog = new SettingsDialog();
                dialog.setCancelable( false );
                dialog.show( getActivity().getSupportFragmentManager(), "Settings" );
            }
            
            return;
        }
        
        
        //################################
        //
        // Bottom row buttons
        //
        //################################
        if ( id == R.id.rateMe && getActivity() != null )
        {
            SharedPreferences        prefs;
            SharedPreferences.Editor editor;
            
            prefs = getActivity().getSharedPreferences( "cc_rate_sys", Context.MODE_PRIVATE );
            // Open the editor
            editor = prefs.edit();
            
            try
            {
                startActivity( new Intent( Intent.ACTION_VIEW, Uri.parse( "http://play.google.com/store/apps/details?id=" + APP_PNAME ) ) );
            }
            catch ( android.content.ActivityNotFoundException nfe2 )
            {
                Toast.makeText( getContext(), "Could not load Market place", Toast.LENGTH_SHORT ).show();
            }
            //            }
            finally
            {   // At least they clicked the rate button
                editor.putBoolean( "hide_app_rate", true );
                editor.commit();
            }
        }
        else if ( id == R.id.emailButton )
        {
            String mailto = "mailto:genesyseast@gmail.com" + "?cc=" + "" + "&subject=" + Uri.encode( "Regarding your game: " + getString( R.string.app_name ) );
            
            Intent emailIntent = new Intent( Intent.ACTION_SENDTO );
            emailIntent.setData( Uri.parse( mailto ) );
            
            try
            {
                startActivity( emailIntent );
            }
            catch ( ActivityNotFoundException e )
            {
                Toast.makeText( getContext(), "No email app available", Toast.LENGTH_SHORT ).show();
            }
        }
        else if ( id == R.id.webpageButton )
        {
            Intent browserIntent = new Intent( Intent.ACTION_VIEW, Uri.parse( "https://sites.google.com/view/genesyseast-privacy-policy/home" ) );
            startActivity( browserIntent );
        }
        else if ( id == R.id.aboutApp && getActivity() != null )
        {
            AboutDialog dialog = new AboutDialog();
            dialog.setCancelable( false );
            dialog.show( getActivity().getSupportFragmentManager(), "About" );
        }
        else if ( id == R.id.devApps )
        {
            try
            {
                ErrorDialog dialog = new ErrorDialog();
                
                dialog.setTitle( "More Apps" ).setMessage( "You will be redirected to view the developer's collection of Apps. Is this okay?" );
                dialog.setAlertIcon( R.drawable.game_pad );
                dialog.setYesText( "Yes" ).setNoText( "No Thanks" );
                dialog.setButtons( ErrorDialog.YES_BUTTON | ErrorDialog.NO_BUTTON );
                dialog.setOnErrorListener( new ErrorDialog.OnErrorListener()
                {
                    @Override
                    public void onErrorExitClick( int buttonClicked )
                    {
                        if ( buttonClicked == ErrorDialog.YES_BUTTON )
                        {
                            try
                            {
                                startActivity( new Intent( Intent.ACTION_VIEW, Uri.parse( "https://play.google.com/store/apps/dev?id=8645290608649850542&hl=en_US" ) ) );
                            }
                            catch ( Exception ex )
                            {
                                Toast.makeText( getContext(), "Could not load Dev's collections", Toast.LENGTH_SHORT ).show();
                            }
                        }
                        
                        // Close the box!
                        dialog.dismiss();
                    }
                } );
                
                if ( getActivity() != null )
                {
                    dialog.show( getActivity().getSupportFragmentManager(), null );
                }
            }
            catch ( android.content.ActivityNotFoundException nfe2 )
            {
                Toast.makeText( getContext(), "Could not load Dev's collections", Toast.LENGTH_SHORT ).show();
            }
            //            }
        }
        else if ( id == R.id.socialMedia )
        {
            shareDialog = new ShareDialog( GameStartFragment.this );
            
            if ( ShareDialog.canShow( ShareLinkContent.class ) )
            {
                ShareLinkContent content;
                content = new ShareLinkContent.Builder().setContentTitle( "Look at what I'm playing!" ).setContentDescription( "I've tried Coin Connection, now it's your turn!" )
                                                        //                        .setContentUrl(Uri.parse("http://developers.facebook.com/android"))
                                                        .setContentUrl( Uri.parse( "https://play.google.com/store/apps/details?id=" + APP_PNAME ) ).build();
                
                shareDialog.show( content );
                
                ShareLinkContent linkContent = new ShareLinkContent.Builder().setContentUrl( Uri.parse( "https://play.google.com/store/apps/details?id=" + APP_PNAME ) ).build();
                shareDialog.show( linkContent );
            }
            else
            {
                Toast.makeText( getContext(), "Unable to Share...Try again.", Toast.LENGTH_SHORT ).show();
            }
        }
    }
    
    
    /**
     * Booster upgrade
     */
    public static void handleBoosterUpgrade( Activity activity, Context context )
    {
/*
        final ErrorDialog dialog       = new ErrorDialog();
        GameEngine        gameEngine   = GameEngine.getInstance( context );
        final int         currentBoost = GameEngine.BOOSTERS_CAPACITY;
        
        
        if ( !GameEngine.boostersUpgradable )
        {
            String timeStr = GameEngine.getBoosterTimeLeft( context );
            
            */
        /*            dialog.setMessage( "You are allowed one upgrade per day, and You have already performed an upgrade. Please try again tomorrow and thank you for playing." );*//*

            dialog.setMessage( String.format( Locale.getDefault(), "You are allowed one upgrade per FULL day. Please try again in %s. thank you for playing.", timeStr ) );
            dialog.setTitle( "Boosters Capacity Upgrade" );
            dialog.setYesText( "Close" );
            dialog.setAlertIcon( android.R.drawable.ic_dialog_alert );
            dialog.setOnErrorListener( new ErrorDialog.OnErrorListener()
            {
                @Override
                public void onErrorExitClick( int buttonClicked )
                {
                    dialog.dismiss();
                }
            } );
            //
            dialog.show( (( MainActivity ) activity).getSupportFragmentManager(), "Error" );
        }
        //#################################
        //
        // Player can upgrade
        //
        //#################################
        else if ( GameEngine.BOOSTERS_CAPACITY < GameEngine.MAX_BOOSTERS )
        {
            dialog.setAlertIcon( android.R.drawable.ic_dialog_alert );
            dialog.setTitle( "Boosters Capacity Upgrade" );
            dialog.setMessage( "Would you like to watch a video and increase your booster capacity?" );
            dialog.setYesText( "Yes!" );
            dialog.setNoText( String.format( Locale.getDefault(), "%d is Good", GameEngine.BOOSTERS_CAPACITY ) );
            dialog.setFormImage( R.drawable.neutral_coin ).setCancelable( false );
            dialog.setButtons( ErrorDialog.NO_BUTTON | ErrorDialog.YES_BUTTON );
            //
            if ( activity != null )
            {
                dialog.show( (( MainActivity ) activity).getSupportFragmentManager(), "Error" );
                dialog.setOnErrorListener( new ErrorDialog.OnErrorListener()
                {
                    @Override
                    public void onErrorExitClick( int buttonClicked )
                    {
                        if ( buttonClicked == ErrorDialog.NO_BUTTON )
                        {
                            dialog.dismiss();
                        }
                        else if ( buttonClicked == ErrorDialog.CLOSE_BUTTON )
                        {
                            // If the user has to click this, they
                            // watched the whole video but had to click X
                            if ( GameEngine.rewardGiven )
                            {
                                Toast.makeText( context, "Error occurred. Reward given", Toast.LENGTH_SHORT ).show();
                            }
                            
                            if ( GameEngine.BOOSTERS_CAPACITY == currentBoost )
                            {
                                GameEngine.BOOSTERS_CAPACITY++;
                            }
                            
                            GameEngine.boostersUpgradable = false;
                            
                            // Update the data
                            GameEngine.setBoosterCount( context, GameEngine.BOOSTERS_CAPACITY );
                            
                            //
                            GradientTextView button = activity.findViewById( R.id.boosterUpgrade );
                            if ( button != null )
                            {
                                button.setVisibility( View.INVISIBLE );
                            }
                            
                            //
                            GameEngine.rewardGiven = false;
                            dialog.dismiss();
                        }
                        else
                        {
                            //@@@@@@@@@@@@@@@@@@@ Close Dialog box
                            if ( gameEngine.soundPlayer != null )
                            {
                                gameEngine.soundPlayer.playBgSfx( PlaySound.DIALOG_CLICK );
                            }
                            
                            dialog.setFormImage( R.drawable.happy_coin ).setMessage( "Excellent! Thank you." );
                            dialog.animateShake( true, 750 );
                            dialog.setButtons( ErrorDialog.HIDE_BUTTONS );
                            dialog.setOnShakeAnimationListener( new ErrorDialog.OnAnimationListener()
                            {
                                @Override
                                public void onAnimationEnd()
                                {
                                    dialog.setButtons( ErrorDialog.CLOSE_BUTTON );
                                    
                                    // Show the video
                                    if ( GameEngine.mRewardedVideoAd.isLoaded() )
                                    {
                                        gameEngine.setOnAdReturnListener( new GameEngine.OnAdReturnListener()
                                        {
                                            @Override
                                            public void onAdReturn( int status, int errorFlag )
                                            {
                                                if ( status == GameEngine.AD_REWARDED )
                                                {
                                                    GameEngine.rewardGiven = true;
                                                }
                                                else if ( status == GameEngine.AD_CLOSED )
                                                {
                                                    if ( GameEngine.rewardGiven )
                                                    {
                                                        GameEngine.BOOSTERS_CAPACITY++;
                                                        GameEngine.boostersUpgradable = false;
                                                        
                                                        // Update the data
                                                        GameEngine.setBoosterCount( context, GameEngine.BOOSTERS_CAPACITY );
                                                        
                                                        //
                                                        GradientTextView button = activity.findViewById( R.id.boosterUpgrade );
                                                        if ( button != null )
                                                        {
                                                            button.setVisibility( View.INVISIBLE );
                                                        }
                                                    }
                                                    
                                                    //
                                                    GameEngine.rewardGiven = false;
                                                }
                                            }
                                        } );
                                        //
                                        GameEngine.mRewardedVideoAd.show();
                                        GameEngine.savedDialog = dialog;
                                    }
                                    else
                                    {
                                        Toast.makeText( context, "Error loading video.", Toast.LENGTH_SHORT ).show();
                                        dialog.dismiss();
                                    }
                                }
                            } );
                        }
                    }
                } );
            }
        }
        else
        {
            dialog.setMessage( "You have reached the maximum upgrade limit." );
            //
            dialog.setTitle( "Boosters Capacity Upgrade" );
            dialog.setYesText( "Close" );
            dialog.setAlertIcon( android.R.drawable.ic_dialog_alert );
            dialog.setOnErrorListener( new ErrorDialog.OnErrorListener()
            {
                @Override
                public void onErrorExitClick( int buttonClicked )
                {
                    dialog.dismiss();
                }
            } );
            //
            dialog.show( (( MainActivity ) activity).getSupportFragmentManager(), "Error" );
        }
*/
    }
    
    
    /**
     * App Rater Toast
     */
    private void rateMyApp()
    {
        if ( getContext() != null )
        {
            int DAYS_UNTIL_PROMPT = 3;
            // Min number of launches
            int LAUNCHES_UNTIL_PROMPT = 3;
            
            long              launch_count;
            long              date_firstLaunch;
            long              days_to_wait;
            SharedPreferences prefs = getContext().getSharedPreferences( "cc_rate_sys", Context.MODE_PRIVATE );
            // Open the editor
            SharedPreferences.Editor editor = prefs.edit();
            
            
            // Does this person wish to see the rate system anymore?
            if ( prefs.getBoolean( "hide_app_rate", false ) )
            {
                return;
            }
            
            // Save the Show / Hide info
            editor.putBoolean( "hide_app_rate", false );
            
            // Increment launch counter
            launch_count = prefs.getLong( "launch_count", 0 ) + 1;
            editor.putLong( "launch_count", launch_count );
            
            // Get date of first launch
            date_firstLaunch = prefs.getLong( "date_first_launch", 0 );
            if ( date_firstLaunch == 0 )
            {
                date_firstLaunch = System.currentTimeMillis();
                editor.putLong( "date_first_launch", date_firstLaunch );
            }
            
            // Get days to wait
            days_to_wait = prefs.getLong( "days_to_wait", DAYS_UNTIL_PROMPT );
            editor.putLong( "days_to_wait", DAYS_UNTIL_PROMPT );
            
            
            //########################################
            //
            // Wait at least n days before opening
            //
            //########################################
            if ( launch_count >= LAUNCHES_UNTIL_PROMPT )
            {
                // Does it meet the time threshold
                if ( System.currentTimeMillis() >= (date_firstLaunch + (days_to_wait * 24 * 60 * 60 * 1000)) )
                {
                    final ErrorDialog dialog = new ErrorDialog();
                    int[]             resIds = gameEngine.arrayFromResource( R.array.star_burst );
                    
                    
                    //@@@@@@@@@@@@@@@@@@@@@ Error sound
                    if ( gameEngine.soundPlayer != null )
                    {
                        gameEngine.soundPlayer.playBgSfx( PlaySound.ERROR );
                    }
                    
                    dialog.setAlertIcon( R.drawable.ic_help_black_24dp );
                    dialog.setTitle( "Rate This App" ).setMessage( getString( R.string.rate_me_plea ) );
                    dialog.setYesText( getString( R.string.rate_yes ) ).setCancelText( getString( R.string.rate_no ) );
                    dialog.setNoText( getString( R.string.rate_remind ) );
                    //
                    dialog.animateFormImage( resIds );
                    dialog.setFormImageBG( R.drawable.box_a_blue ).setCancelable( false );
                    dialog.setButtons( ErrorDialog.MAIN_BUTTONS );
                    //
                    if ( getActivity() != null )
                    {
                        dialog.show( getActivity().getSupportFragmentManager(), "Error" );
                        dialog.setOnErrorListener( new ErrorDialog.OnErrorListener()
                        {
                            @Override
                            public void onErrorExitClick( int buttonClicked )
                            {
                                if ( buttonClicked == ErrorDialog.CANCEL_BUTTON )
                                {
                                    Toast.makeText( getContext(), "Thank you. Will not ask again...", Toast.LENGTH_SHORT ).show();
                                    //
                                    editor.putBoolean( "hide_app_rate", true );
                                    editor.commit();
                                    //
                                    dialog.dismiss();
                                }
                                else if ( buttonClicked == ErrorDialog.NO_BUTTON )
                                {
                                    // Remind the player later
                                    Toast.makeText( getContext(), "Thanks! I'll try.", Toast.LENGTH_SHORT ).show();
                                    editor.putLong( "days_to_wait", 1 );
                                    // Relaunch again after 3 relaunches
                                    editor.putLong( "launch_count", 0 );
                                    editor.commit();
                                    //
                                    dialog.dismiss();
                                }
                                else
                                {
                                    // Yes was clicked
                                    ImageView rateMe = view_main.findViewById( R.id.rateMe );
                                    onClick( rateMe );
                                    //
                                    dialog.dismiss();
                                }
                            }
                        } );
                    }
                }
            }
            
            //
            editor.commit();
        }
    }
    
    
    /**
     * //###########################
     * <p>
     * View Pager Methods
     * <p>
     * //###########################
     */
/*
    @Override
    public void onPageSelected( int position )
    {
        if ( position == 0 && getActivity() != null )
        {
            try
            {
                HelpDialog helpDialog = new HelpDialog( false );
                helpDialog.setCancelable( false );
                helpDialog.show( getActivity().getSupportFragmentManager(), "Help" );
                
                helpDialog.setOnDismisser( new HelpDialog.OnDismisser()
                {
                    @Override
                    public void onDismiss()
                    {
                        viewPager.setCurrentItem( MAIN_MENU_PAGE );
                    }
                } );
                
                //
                Button button = view_main.findViewById( R.id.helpBackButton );
                button.setVisibility( View.INVISIBLE );
            }
            catch ( NullPointerException npe )
            {
                npe.printStackTrace();
            }
        }
    }
*/
    @Override
    public void onDestroy()
    {
        View view = view_main.findViewById( R.id.titleSparkle );
        if ( view.getTag() != null )
        {
            ObjectAnimator obj = (( ObjectAnimator ) view.getTag());
            obj.end();
            view.setTag( null );
        }
        
        view = view_main.findViewById( R.id.playButton );
        if ( view.getTag() != null )
        {
            ObjectAnimator obj = (( ObjectAnimator ) view.getTag());
            obj.end();
            view.setTag( null );
        }
        
        view = null;
        view_main = null;
        gameEngine = null;
        shareDialog = null;
        
        super.onDestroy();
    }
    
}