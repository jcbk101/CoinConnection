package com.genesyseast.coinconnection.Support;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.genesyseast.coinconnection.CustomControls.BoardTile;
import com.genesyseast.coinconnection.CustomControls.CustomTimer;
import com.genesyseast.coinconnection.Fragments.CardsFragment;
import com.genesyseast.coinconnection.Fragments.ConnectionsFragment;
import com.genesyseast.coinconnection.GameEngine.GameBoard;
import com.genesyseast.coinconnection.GameEngine.GameEngine;
import com.genesyseast.coinconnection.R;
import com.genesyseast.coinconnection.Variables.PointXYZ;

import java.util.ArrayList;
import java.util.Locale;

public class GameState
{
    private static GameEngine gameEngine;
    private static GameBoard  gameBoard;
    
    
    /**
     * Check if we have a save state
     *
     * @param context
     *
     * @return
     */
    public static boolean getSaveStatus( Context context )
    {
        if ( context != null )
        {
            SharedPreferences prefs = context.getSharedPreferences( "game_state", Context.MODE_PRIVATE );
            
            return prefs.getBoolean( "save_exist", false );
        }
        else
        {
            return false;
        }
    }
    
    
    /**
     * //##################################
     * <p>
     * Save all game data to the Shared
     * Preferences
     * <p>
     * //##################################
     */
    public static void saveGameState( Context context, int gameType, View view )
    {
        if ( context != null )
        {
            SharedPreferences        prefs;
            SharedPreferences.Editor editor;
            StringBuilder            board = new StringBuilder();
            
            //
            prefs = context.getSharedPreferences( "game_state", Context.MODE_PRIVATE );
            // Open the editor
            editor = prefs.edit();
            
            gameBoard = GameBoard.getInstance( context );
            gameEngine = GameEngine.getInstance( context );
            
            
            //################################
            //
            //
            //
            //################################
            editor.putBoolean( "save_exist", true );
            //
            editor.putLong( "current_time", CustomTimer.currentTime );
            editor.putInt( "current_bgm", gameEngine.currentBGMusic );
            editor.putInt( "current_bg", gameEngine.currentBackground );
            editor.putInt( "current_board", gameEngine.currentBoardImage );
            editor.putInt( "current_moves", gameEngine.boardMoves );
            editor.putInt( "current_level", GameEngine.currentLevel );
            
            
            //##################################
            //
            // Matching Card Game
            //
            //##################################
            editor.putInt( "game_type", gameType );
            
            if ( gameType == 1 )
            {
                editor.putInt( "card_hints_left", CardsFragment.cardHintCount );
                editor.putInt( "current_score", CardsFragment.levelScore );
                editor.putInt( "coin_count", gameBoard.maxColors );
                editor.putInt( "jewel_count", gameBoard.maxGems );
                
                // Board layout
                for ( BoardTile tile : gameBoard.boardTiles )
                {
                    int value;
                    
                    value = tile.getState();
                    value |= (tile.specialTile & 0xFF) << 8;
                    
                    board.append( value );
                    
                    if ( tile.getPosition() < (gameBoard.boardTiles.size() - 1) )
                    {
                        board.append( "," );
                    }
                }
                
                // Save the board tiles
                editor.putString( "board_tiles", board.toString() );
                board.setLength( 0 );
                
                
                //##################################
                //
                // Get the views for the current
                // scene
                //
                //##################################
                ViewGroup group = view.findViewById( R.id.boardTargetHolder );
                int       count = group.getChildCount();
                
                for ( int i = 0; i < count; i++ )
                {
                    View v = group.getChildAt( i );
                    
                    if ( v instanceof TextView && v.getId() != R.id.targetText )
                    {
                        if ( v.getTag() != null )
                        {
                            PointXYZ point = ( PointXYZ ) v.getTag();
                            
                            board.append( point.x );
                            if ( i < (count - 1) )
                            {
                                board.append( "," );
                            }
                        }
                        else
                        {
                            board.append( "-1" );
                            if ( i < (count - 1) )
                            {
                                board.append( "," );
                            }
                        }
                    }
                }
                
                // Save the board targets
                editor.putString( "targets", board.toString() );
                board.setLength( 0 );
            }
            //##############################################
            //
            // Standard connection game
            //
            //##############################################
            else
            {
                editor.putInt( "current_score", ConnectionsFragment.levelScore );
                editor.putInt( "coin_count", gameBoard.maxColors );
                editor.putInt( "jewel_count", gameBoard.maxGems );
                
                // Board layout
                for ( BoardTile tile : gameBoard.boardTiles )
                {
                    board.append( tile.tileNum );
                    
                    if ( tile.getPosition() < (gameBoard.boardTiles.size() - 1) )
                    {
                        board.append( "," );
                    }
                }
                
                // Save the board tiles
                editor.putString( "board_tiles", board.toString() );
                board.setLength( 0 );
                
                
                //##################################
                //
                // Get the views for the current
                // scene
                //
                //##################################
                ViewGroup group = view.findViewById( R.id.boardTargetHolder );
                int       count = group.getChildCount();
                
                for ( int i = 0; i < count; i++ )
                {
                    View v = group.getChildAt( i );
                    
                    if ( v instanceof TextView && v.getId() != R.id.targetText )
                    {
                        if ( v.getTag() != null )
                        {
                            PointXYZ point = ( PointXYZ ) v.getTag();
                            
                            board.append( point.x );
                            board.append( "," );
                            
                            // Target Index
                            board.append( point.y );
                            if ( i < (count - 1) )
                            {
                                board.append( "," );
                            }
                        }
                        else
                        {
                            board.append( "-1" );
                            board.append( "," );
                            
                            // Target Index
                            board.append( "-1" );
                            if ( i < (count - 1) )
                            {
                                board.append( "," );
                            }
                        }
                    }
                }
                
                // Save the board targets
                editor.putString( "targets", board.toString() );
                board.setLength( 0 );
            }
            
            //
            editor.commit();
        }
    }
    
    
    /**
     * /#######################################
     * <p>
     * Detect the same game format
     * <p>
     * //#######################################
     */
    public static int getSaveGameType( Context context )
    {
        SharedPreferences prefs = context.getSharedPreferences( "game_state", Context.MODE_PRIVATE );
        
        return prefs.getInt( "game_type", 0 );
    }
    
    
    /**
     * /#######################################
     * <p>
     * Load all shared pref data
     * <p>
     * //#######################################
     */
    public static void loadGameState( Context context )
    {
        if ( context != null )
        {
            SharedPreferences        prefs    = context.getSharedPreferences( "game_state", Context.MODE_PRIVATE );
            SharedPreferences.Editor editor   = prefs.edit();
            boolean                  saveExist;
            int                      gameType = 0;
            
            gameBoard = GameBoard.getInstance( context );
            gameEngine = GameEngine.getInstance( context );
            
            
            //################################
            //
            //
            //
            //################################
            saveExist = prefs.getBoolean( "save_exist", false );
            
            //
            if ( saveExist )
            {
                CustomTimer.currentTime = prefs.getLong( "current_time", 0 );
                gameEngine.currentBGMusic = prefs.getInt( "current_bgm", 0 );
                gameEngine.currentBackground = prefs.getInt( "current_bg", 0 );
                gameEngine.currentBoardImage = prefs.getInt( "current_board", 0 );
                gameEngine.boardMoves = prefs.getInt( "current_moves", 0 );
                
                // Has it been converted yet?
                if ( !prefs.getBoolean( "level_converted", false ) )
                {
                    GameEngine.currentLevel = prefs.getInt( "current_area", 0 ) * 18;
                    // This will reset the current area BACK to this level. Must be careful
                    GameEngine.currentLevel += prefs.getInt( "current_level", 0 );
                    
                    // Remove this. No longer used
                    editor.remove( "current_area" );
                    
                    //Save converted data
                    editor.putInt( "current_level", GameEngine.currentLevel );
                    editor.putBoolean( "level_converted", true );
                    
                    //
                    editor.commit();
                }
                else
                {
                    GameEngine.currentLevel = prefs.getInt( "current_level", 0 );
                }
                
                // Get the game type
                gameType = prefs.getInt( "game_type", 0 );
                
                //
                String boardTiles = prefs.getString( "board_tiles", "" );
                String targets    = prefs.getString( "targets", "" );
                
                String[] bt = boardTiles.split( "," );
                String[] tg = targets.split( "," );
                
                
                //####################################
                //
                //
                //
                //####################################
                if ( gameType == 0 )
                {
                    // Connections game info
                    ConnectionsFragment.levelScore = prefs.getInt( "current_score", 0 );
/*
                    gameBoard.maxColors = prefs.getInt( "coin_count", 0 );
                    gameBoard.maxJewels = prefs.getInt( "jewel_count", 0 );
*/
                    
                    // Load Board Tiles
                    if ( ConnectionsFragment.boardTiles != null && ConnectionsFragment.boardTiles.size() > 0 )
                    {
                        for ( int i = 0; i < bt.length; i++ )
                        {
                            BoardTile tile = ConnectionsFragment.boardTiles.get( i );
                            String    text = bt[ i ];
                            
                            tile.tileNum = Integer.parseInt( text );
                            if ( tile.tileNum > BoardTile.CLOCK )
                            {
                                tile.specialItem = 2;
                            }
                            else
                            {
                                tile.specialItem = 0;
                            }
                        }
                    }
                    
                    // Load Target Data
                    if ( ConnectionsFragment.view_main != null )
                    {
                        ConstraintLayout    layout      = ConnectionsFragment.view_main.findViewById( R.id.boardTargetHolder );
                        int                 children    = layout.getChildCount();
                        ArrayList<TextView> targetViews = new ArrayList<>();
                        
                        // Get those views
                        for ( int c = 0; c < children; c++ )
                        {
                            View view = layout.getChildAt( c );
                            
                            if ( view instanceof TextView && view.getId() != R.id.targetText )
                            {
                                targetViews.add( ( TextView ) view );
                            }
                        }
                        
                        
                        for ( int i = 0; i < targetViews.size(); i++ )
                        {
                            if ( i >= (tg.length / 2) )
                            {
                                break;
                            }
                            
                            int      value;
                            int      index;
                            TextView v    = targetViews.get( i );
                            String   text = tg[ i + i ];
                            
                            value = Integer.parseInt( text );
                            text = tg[ i + i + 1 ];
                            index = Integer.parseInt( text );
                            
                            if ( value < 0 )
                            {
                                v.setVisibility( View.GONE );
                                continue;
                            }
                            
                            //
                            v.setTag( new PointXYZ( value, index ) );
                            v.setText( String.format( Locale.getDefault(), "%2d", value ) );
                            v.setVisibility( View.VISIBLE );
                        }
                    }
                }
                else
                {
                    // Cards game info
                    CardsFragment.levelScore = prefs.getInt( "current_score", 0 );
                    CardsFragment.cardHintCount = prefs.getInt( "card_hints_left", 0 );
/*
                    gameBoard.maxColors = prefs.getInt( "coin_count", 0 );
                    gameBoard.maxJewels = prefs.getInt( "jewel_count", 0 );
*/
                    
                    // Load Board Tiles
                    if ( CardsFragment.boardTiles != null && CardsFragment.boardTiles.size() > 0 )
                    {
                        for ( int i = 0; i < bt.length; i++ )
                        {
                            BoardTile tile   = CardsFragment.boardTiles.get( i );
                            String    text   = bt[ i ];
                            int       decode = Integer.parseInt( text );
                            
                            // Inactive tile??
                            if ( (decode & 0xFF00) == 0xFF00 )
                            {
                                continue;
                            }
                            
                            // Read in the aggregate data and decode
                            tile.setState( decode & 0x00FF );
                            tile.specialTile = (decode & 0xFF00) >> 8;
                            //
                            tile.card[ 0 ] = gameBoard.cardSet[ 0 ];
                            tile.card[ 1 ] = gameBoard.cardSet[ tile.specialTile ];
                            //
                            switch ( tile.getState() )
                            {
                                case BoardTile.STATE_ACTIVE:
                                    tile.tileNum = gameBoard.cardSet[ 0 ];
                                    break;
                                case BoardTile.FLIP_CARD:
                                case BoardTile.STATE_FLIPPED:
                                    tile.tileNum = gameBoard.cardSet[ 1 ];
                                    break;
                                case BoardTile.STATE_INACTIVE:
                                default:
                                    tile.tileNum = -1;
                                    break;
                            }
                        }
                    }
                    
                    // Load Target Data
                    if ( CardsFragment.view_main != null )
                    {
                        ConstraintLayout    layout      = CardsFragment.view_main.findViewById( R.id.boardTargetHolder);
                        int                 children    = layout.getChildCount();
                        ArrayList<TextView> targetViews = new ArrayList<>();
                        
                        // Get those views
                        for ( int c = 0; c < children; c++ )
                        {
                            View view = layout.getChildAt( c );
                            
                            if ( view instanceof TextView && view.getId() != R.id.targetText )
                            {
                                targetViews.add( ( TextView ) view );
                            }
                        }
                        
                        
                        for ( int i = 0; i < targetViews.size(); i++ )
                        {
                            if ( i >= tg.length )
                            {
                                break;
                            }
                            
                            TextView v    = targetViews.get( i );
                            String   text = tg[ i ];
                            int      value;
                            
                            value = Integer.parseInt( text );
                            
                            if ( value < 0 )
                            {
                                v.setVisibility( View.GONE );
                                continue;
                            }
                            v.setTag( new PointXYZ( value, 0 ) );
                            v.setText( String.format( Locale.getDefault(), "%2d", value ) );
                            v.setVisibility( View.VISIBLE );
                        }
                    }
                }
            }
        }
    }
    
    
    /**
     * //###################################
     * <p>
     * Player did not want the saved game
     * <p>
     * //###################################
     */
    public static void eraseSavedGame( Context context )
    {
        SharedPreferences        prefs;
        SharedPreferences.Editor editor;
        
        //
        prefs = context.getSharedPreferences( "game_state", Context.MODE_PRIVATE );
        // Open the editor
        editor = prefs.edit();
        
        
        //################################
        //
        //
        //
        //################################
        /*        editor.putBoolean( "save_exist", false );*/
        editor.clear();
        //
        editor.commit();
    }
}
