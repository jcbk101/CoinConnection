package com.genesyseast.coinconnection.GameGraphics;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.genesyseast.coinconnection.Variables.PointXYZ;


public class GameBitmaps
{
    /**
     * Split an image into usable tile form
     *
     * @param resID       N/A
     * @param gridRows    N/A
     * @param gridColumns N/A
     *
     * @return N/A
     */
    public static Bitmap[] splitImage( Context context, int resID, int gridRows, int gridColumns )
    {
        Bitmap[] bitmaps;
        Bitmap   loadBmp;
        int      width;
        int      height;
        int      index = 0;
        
        // Try to split the image
        try
        {
            loadBmp = BitmapFactory.decodeResource( context.getResources(), resID );
            height = (loadBmp.getHeight() / gridRows);
            width = (loadBmp.getWidth() / gridColumns);
            
            
            // Allocate space for the image split
            bitmaps = new Bitmap[ (gridRows * gridColumns) ];
            
            // Split the image into tile sized sections if possible
            for ( int y = 0; y < gridRows; y++ )
            {
                for ( int x = 0; x < gridColumns; x++ )
                {
                    bitmaps[ index++ ] = Bitmap.createBitmap( loadBmp, (x * width), (y * height), width, height );
                }
            }
            return bitmaps;
        }
        catch ( Exception ex )
        {
            ex.printStackTrace();
        }
        
        // Failed
        return null;
    }
    
    
    /**
     * Split an image into usable tile form
     *
     * @param resID N/A
     *
     * @return N/A
     */
    public static Bitmap getImage( Context context, int resID )
    {
        Bitmap loadBmp;
        int    width;
        int    height;
        
        // Try to split the image
        try
        {
            loadBmp = BitmapFactory.decodeResource( context.getResources(), resID );
            height = loadBmp.getHeight();
            width = loadBmp.getWidth();
            
            return Bitmap.createBitmap( loadBmp, 0, 0, width, height );
        }
        catch ( Exception ex )
        {
            ex.printStackTrace();
        }
        
        // Failed
        return null;
    }
    
    
    public static PointXYZ getImageSize( Context context, int resId )
    {
        Bitmap loadBmp;
        int    width;
        int    height;
        int    index = 0;
        
        // Try to split the image
        try
        {
            loadBmp = BitmapFactory.decodeResource( context.getResources(), resId );
            height = loadBmp.getHeight();
            width = loadBmp.getWidth();
            
            return new PointXYZ( width, height, 0 );
        }
        catch ( Exception ex )
        {
            ex.printStackTrace();
        }
        
        // Failed
        return new PointXYZ( 0, 0, 0 );
    }
}
