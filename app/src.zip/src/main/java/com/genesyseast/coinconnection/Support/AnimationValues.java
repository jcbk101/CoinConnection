package com.genesyseast.coinconnection.Support;


public class AnimationValues
{
    public static final int  COIN_SPIN         = 500; // 350;
    public static final int  DROP_TIME         = 350;
    public static final long SWAP_SPEED        = 200;
    public static final int TRANSITION_TIME    = 350;
    public static       int  SLIDE_TIME        = 300;
    public static       int  SPRING_SLIDE_TIME = 600;
    public static       int  FADE_TIME         = 300;
    
    
    public static int getCenter( int big_number, int small_number )
    {
        int number;
        
        number = (big_number / 2) - (small_number / 2);
        if ( number < 0 )
        {
            number = 0;
        }
        
        return number;
    }
}
