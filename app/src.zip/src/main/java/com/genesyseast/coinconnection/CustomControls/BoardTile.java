package com.genesyseast.coinconnection.CustomControls;


import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnticipateOvershootInterpolator;
import android.view.animation.LinearInterpolator;
import android.widget.Toast;

import androidx.appcompat.widget.AppCompatImageView;

import com.genesyseast.coinconnection.GameEngine.GameEngine;
import com.genesyseast.coinconnection.PlaySound.PlaySound;
import com.genesyseast.coinconnection.Support.CustomBounceInterpolator;
import com.genesyseast.coinconnection.Support.CustomEvaluator;
import com.genesyseast.coinconnection.GameEngine.GameBoard;
import com.genesyseast.coinconnection.GameGraphics.ConnectionsGridLayout;
import com.genesyseast.coinconnection.Variables.PointXYZ;

import java.util.Locale;

import static com.genesyseast.coinconnection.GameEngine.GameBoard.coinSet;

public class BoardTile
        extends AppCompatImageView
        implements ValueAnimator.AnimatorListener
{
    public  ValueAnimator               valueAnimator;
    public  ValueAnimator               animator       = null;
    private ObjectAnimator              rot;
    private OnAnimationCompleteListener onAnimationCompleteListener;
    private boolean                     debugVisiblity = false;
    public  boolean                     cardFlipped    = false;
    
    
    public interface OnAnimationCompleteListener
    {
        void onAnimationComplete();
    }
    
    /**
     * Return the call to the calling image in
     *
     * @param onAnimationCompleteListener
     */
    public void setOnAnimationCompleteListener( OnAnimationCompleteListener onAnimationCompleteListener )
    {
        this.onAnimationCompleteListener = onAnimationCompleteListener;
    }
    
    
    //##################################
    // State Codes
    //##################################
    // Not active or usable on the board
    public static final int STATE_INACTIVE        = 0;
    // Active and movable
    public static final int STATE_ACTIVE          = 1;
    // Spawning an tag onto the board for the first time
    public static final int STATE_RESPAWN         = 2;
    // Start drop process
    public static final int STATE_DROP            = 3;
    // Spawning an tag onto the board after a math
    public static final int STATE_DROPPING        = 4;
    // Was matched, needs to be re-spawned
    public static final int STATE_MATCHED         = 5;
    // Gem was matched
    public static final int GEM_MATCHED           = 6;
    // Maintain the swap state
    public static final int STATE_SWAP            = 7;
    //
    public static final int STATE_UNSWAP          = 8;
    // For special item creation
    public static final int CREATE_ITEM           = 9;
    public static final int MASTER_ITEM           = 10;
    // Activate a special item
    public static final int USE_SPECIAL_ITEM      = 11;
    // Activate a special item after a current special
    public static final int USE_SPECIAL_ITEM_NEXT = 12;
    // Perform animation attached to setTag() after SPECIAL used
    public static final int SPECIAL_ANIMATE       = 13;
    //
    public static final int ANNOUNCE_PRESENCE     = 14;
    //
    public static final int FLIP_CARD             = 15;
    //
    public static final int STATE_FLIPPED         = 16;
    //
    public static final int MASTER_ITEM_TO_GIVE   = 17;
    
    
    //##################################
    // Special tiles
    //##################################
    final public static int MAX_COINS      = 7;
    // Paintbrush allows you to change any coin color
    // Adds more time to the game
    public static final int CLOCK          = MAX_COINS;
    // Explodes 3x3 grid of coins
    public static final int BOMB           = MAX_COINS + 1;
    // Clears all colors of a selected type
    public static final int STAR_GOLD      = MAX_COINS + 2;
    // Clears all colors in swipe direction
    public static final int BOLT           = MAX_COINS + 3;
    //
    public static final int SPARK          = MAX_COINS + 4;
    //
    public static final int CHARGE_BEAM    = MAX_COINS + 5;
    //
    public static final int RANDOM_SPECIAL = MAX_COINS + 6;
    //
    public static final int SHUFFLER       = MAX_COINS + 7;
    // GEMS
    public static final int RED_GEM        = MAX_COINS + 8;
    public static final int BLUE_GEM       = MAX_COINS + 9;
    public static final int PURLE_GEM      = MAX_COINS + 10;
    public static final int YELLOW_GEM     = MAX_COINS + 11;
    
    
    // For tile swapping statuses
    public  int      soundEfx       = 0;
    public  int      animDelay      = 0;
    public  int      swipeDirection = -1;
    public  int      specialTile    = -1;
    private int      state;
    private int      position;
    public  int      tileNum;
    public  int      specialItem;
    public  int[]    card           = { 0, 0 };
    public  PointXYZ swapTO;
    public  boolean  isCaught       = false;
    public  int      pointPosi;
    
    //
    private Context context;
    
    /**
     * Constructors
     *
     * @param context
     */
    public BoardTile( Context context )
    {
        super( context );
        this.context = context;
    }
    
    
    public BoardTile( Context context, AttributeSet attrs )
    {
        super( context, attrs );
        this.context = context;
    }
    
    public BoardTile( Context context, AttributeSet attrs, int defStyleAttr )
    {
        super( context, attrs, defStyleAttr );
        this.context = context;
    }
    
    
    /**
     * Constructor for map tile array
     *
     * @param context
     * @param state
     * @param position
     */
    public BoardTile( Context context, int state, int position )
    {
        super( context );
        this.state = state;
        this.position = position;
    }
    
    
    public int getTileX()
    {
        return position % ConnectionsGridLayout.getMapWidth();
    }
    
    public int getTileY()
    {
        return position / ConnectionsGridLayout.getMapHeight();
    }
    
    
    /**
     * Setter for Object's state
     *
     * @param state
     */
    public void setState( int state )
    {
        this.state = state;
    }
    
    /**
     * Getter for Object's state
     *
     * @return
     */
    public int getState()
    {
        return state;
    }
    
    /**
     * Position setter
     *
     * @param position
     */
    public void setPosition( int position )
    {
        this.position = position;
    }
    
    public int getPosition()
    {
        return position;
    }
    
    /**
     * Use a different sound efx for matching
     *
     * @param soundEfx
     */
    public void setSoundEfx( int soundEfx )
    {
        this.soundEfx = soundEfx;
    }
    
    /**
     * Use to get the sound effect
     *
     * @return
     */
    public int getSoundEfx()
    {
        return soundEfx;
    }
    
    
    /**
     * interface listener-- valueAnimator ONLY
     *
     * @param animation
     */
    @Override
    public void onAnimationStart( Animator animation )
    {
    }
    
    @Override
    public void onAnimationEnd( Animator animation )
    {
        valueAnimator = null;
    }
    
    /**
     * Handle cancels
     *
     * @param animation
     */
    @Override
    public void onAnimationCancel( Animator animation )
    {
    }
    
    @Override
    public void onAnimationRepeat( Animator animation )
    {
    
    }
    
    /**
     * Depending on animation type, cancel it
     */
    public void endAnimation()
    {
        if ( getTag() != null )
        {
            if ( getTag() instanceof ObjectAnimator )
            {
                // Clear it up
                (( ObjectAnimator ) getTag()).end();
                setTag( null );
            }
            else if ( getTag() instanceof ObjectAnimator[] || getTag() instanceof ValueAnimator[] )
            {
                ValueAnimator[] obj = ( ValueAnimator[] ) getTag();
                
                for ( int i = 0; i < obj.length; i++ )
                {
                    if ( obj[ i ] != null )
                    {
                        obj[ i ].end();
                    }
                    //
                    setTag( null );
                }
            }
            else if ( getTag() instanceof ValueAnimator )
            {
                // Clear it up
                (( ValueAnimator ) getTag()).end();
                setTag( null );
            }
        }
        
        //
        if ( valueAnimator != null && valueAnimator.isRunning() )
        {
            valueAnimator.end();
            specialItem = 0;
        }
        
        // Clear anything running
        clearAnimation();
        
        //
        
        // Fix scaling
        setScaleX( 1 );
        setScaleY( 1 );
    }
    
    
    /**
     * Depending on animation type, cancel it
     */
    public void cancelAnimation()
    {
        if ( getTag() != null )
        {
            if ( getTag() instanceof ObjectAnimator )
            {
                // Clear it up
                (( ObjectAnimator ) getTag()).cancel();
                setTag( null );
            }
            else if ( getTag() instanceof ObjectAnimator[] || getTag() instanceof ValueAnimator[] )
            {
                ValueAnimator[] obj = ( ValueAnimator[] ) getTag();
                
                for ( int i = 0; i < obj.length; i++ )
                {
                    if ( obj[ i ] != null )
                    {
                        obj[ i ].cancel();
                    }
                }
                //
                setTag( null );
            }
            else if ( getTag() instanceof ValueAnimator )
            {
                // Clear it up
                (( ValueAnimator ) getTag()).cancel();
                setTag( null );
            }
        }
        
        //
        if ( valueAnimator != null && valueAnimator.isRunning() )
        {
            valueAnimator.cancel();
            specialItem = 0;
        }
        
        // Clear anything running
        clearAnimation();
        
        // Fix scaling
        setScaleX( 1 );
        setScaleY( 1 );
    }
    
    
    /**
     * We want this tile to do and / or finish NO animations
     */
    public void cancelAnimationAndListeners()
    {
        if ( getTag() != null )
        {
            if ( getTag() instanceof ObjectAnimator )
            {
                // Clear it up
                (( ObjectAnimator ) getTag()).removeAllListeners();
                (( ObjectAnimator ) getTag()).cancel();
                setTag( null );
            }
            else if ( getTag() instanceof ObjectAnimator[] || getTag() instanceof ValueAnimator[] )
            {
                ValueAnimator[] obj = ( ValueAnimator[] ) getTag();
                
                for ( int i = 0; i < obj.length; i++ )
                {
                    if ( obj[ i ] != null )
                    {
                        obj[ i ].removeAllListeners();
                        obj[ i ].cancel();
                    }
                }
                //
                setTag( null );
            }
            else if ( getTag() instanceof ValueAnimator )
            {
                // Clear it up
                (( ValueAnimator ) getTag()).removeAllListeners();
                (( ValueAnimator ) getTag()).cancel();
                setTag( null );
            }
        }
        
        //
        if ( valueAnimator != null && valueAnimator.isRunning() )
        {
            valueAnimator.removeAllListeners();
            valueAnimator.cancel();
            specialItem = 0;
        }
        
        // Clear anything running
        clearAnimation();
        
        // Fix scaling
        setScaleX( 1 );
        setScaleY( 1 );
    }
    
    
    /**
     * Pause / unpause animation
     *
     * @param pauseStatus N/A
     */
    public void pauseAnimation( boolean pauseStatus )
    {
        if ( getTag() != null )
        {
            if ( getTag() instanceof ObjectAnimator )
            {
                ObjectAnimator obj = ( ObjectAnimator ) getTag();
                
                if ( pauseStatus )
                {
                    obj.pause();
                }
                else
                {
                    obj.resume();
                }
            }
            else if ( getTag() instanceof ObjectAnimator[] || getTag() instanceof ValueAnimator[] )
            {
                ValueAnimator[] obj = ( ValueAnimator[] ) getTag();
                
                for ( int i = 0; i < obj.length; i++ )
                {
                    if ( obj[ i ] != null )
                    {
                        if ( pauseStatus )
                        {
                            obj[ i ].pause();
                        }
                        else
                        {
                            obj[ i ].resume();
                        }
                    }
                }
            }
            else if ( getTag() instanceof ValueAnimator )
            {
                ValueAnimator obj = ( ValueAnimator ) getTag();
                
                if ( pauseStatus )
                {
                    obj.pause();
                }
                else
                {
                    obj.resume();
                }
            }
        }
        
        
        // Foreground animations for extra layer
        if ( valueAnimator != null )
        {
            if ( pauseStatus )
            {
                valueAnimator.pause();
            }
            else
            {
                valueAnimator.resume();
            }
        }
        
        // Board movements
        if ( animator != null )
        {
            if ( pauseStatus )
            {
                animator.pause();
            }
            else
            {
                animator.resume();
            }
        }
    }
    
    
    /**
     * //####################################
     * <p>
     * Animate the board icon when clicked
     * <p>
     * //####################################
     */
    public void spinCoin()
    {
        // End all currently running animations
        endAnimation();
        
        //
        ObjectAnimator[] img = new ObjectAnimator[ 2 ];
        img[ 0 ] = ObjectAnimator.ofFloat( this, "alpha", .99f, 1 );
        img[ 0 ].setDuration( 10 );
/*
        img[ 0 ] = ObjectAnimator.ofInt( this, "imageResource", coinSet[ tileNum ] );
        img[ 0 ].setEvaluator( new CustomEvaluator() );
        img[ 0 ].setDuration( (coinSet[ tileNum ].length - 1) * GameBoard.coinSpinSpeed[ tileNum ] );
        img[ 0 ].setRepeatCount( ValueAnimator.INFINITE );
        img[ 0 ].setInterpolator( new LinearInterpolator() );
        //

        if ( tileNum == BoardTile.SPARK )
        {
            setRotation( 0f );
            //
            img[ 1 ] = ObjectAnimator.ofFloat( this, "rotation", 360 );
            img[ 1 ].setDuration( 10000 ).setInterpolator( new LinearInterpolator() );
            img[ 1 ].setRepeatCount( ValueAnimator.INFINITE );
            img[ 1 ].start();
        }
*/
        
        //
        img[ 0 ].start();
        setTag( img );
    }
    
    
    /**
     * //####################################
     * <p>
     * Animate the board icon when clicked
     * <p>
     * //####################################
     */
    public void pulsateCoin()
    {
        // End all currently running animations
        endAnimation();
        
        //
        PropertyValuesHolder sx = PropertyValuesHolder.ofFloat( "scaleX", 0.9f, 1, 0.9f, 1, 1, 1, 1, 1, 1, 1 );
        PropertyValuesHolder sy = PropertyValuesHolder.ofFloat( "scaleY", 0.9f, 1, 0.9f, 1, 1, 1, 1, 1, 1, 1 );
        ObjectAnimator       img;
        
        img = ObjectAnimator.ofPropertyValuesHolder( this, sx, sy );
        img.setDuration( 1000 );
        img.setRepeatCount( ValueAnimator.INFINITE );
        img.setInterpolator( new AccelerateDecelerateInterpolator() );
        //
        img.start();
        setTag( img );
    }
    
    
    /**
     * //####################################
     * <p>
     * Simple image reset
     * <p>
     * //####################################
     */
    public void resetCoin()
    {
        setScaleX( 1f );
        setScaleY( 1f );
        setImageResource( coinSet[ tileNum % coinSet.length ] );
    }
    
    
    /**
     * //####################################
     * <p>
     * Animate the board icon when clicked
     * <p>
     * //####################################
     */
    public void growCoin()
    {
        // End all currently running animations
        endAnimation();
        
        setScaleX( .5f );
        setScaleY( .5f );
        animate().scaleX( 1f ).scaleY( 1f ).setDuration( 350 ).setInterpolator( new CustomBounceInterpolator( .2, 20 ) );
        ;
        animate().start();
    }
    
    
    /**
     * //####################################
     * <p>
     * Animate the board icon when clicked
     * <p>
     * //####################################
     */
    public ObjectAnimator shakeCoin( boolean shakeType )
    {
        return null;
    }
    
    
    /**
     * //##############################
     * <p>
     * Flip the coin slightly
     * <p>
     * //##############################
     */
    public ObjectAnimator flipCoin( boolean delay )
    {
        final int DURATION   = 250;
        int       startDelay = (delay ? DURATION / 2 : 0);
        BoardTile tile       = this;
        
        
        // End all currently running animations
        endAnimation();
        
        
        //
        setPivotX( getWidth() / 2f );
        setPivotY( getHeight() / 2f );
        
        //##################################
        //
        // Put the flip back to normal
        //
        //##################################
        if ( cardFlipped )
        {
            // Flip back to normaL
            // Show the image we want
            // Halfway through, the views will flip
            rot = ObjectAnimator.ofFloat( tile, "alpha", .99f, 1f );
            rot.setDuration( DURATION );
            
            setScaleX( 1 );
            setRotationY( 0 );
            animate().rotationY( -90 ).setStartDelay( startDelay );
            animate().setDuration( DURATION / 2 ).setInterpolator( new LinearInterpolator() );
            animate().withEndAction( new Runnable()
            {
                @Override
                public void run()
                {
                    // swap the views
                    cardFlipped = false;
                    tileNum = card[ 0 ];
                    // Reverse the image so it looks correct
                    setBackgroundResource( tileNum );
                    
                    //
                    setRotationY( -90 );
                    setScaleX( -1 );
                    animate().rotationY( -180 );
                    animate().setDuration( DURATION / 2 ).setInterpolator( new LinearInterpolator() );
                    animate().setUpdateListener( new ValueAnimator.AnimatorUpdateListener()
                    {
                        @Override
                        public void onAnimationUpdate( ValueAnimator animation )
                        {
                            if ( getScaleX() != -1 )
                            {
                                setScaleX( -1 );
                            }
                        }
                    } );
                    animate().withEndAction( new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            setScaleX( 1 );
                            setRotationY( 0 );
                            animate().setUpdateListener( null );
                        }
                    } ).start();
                }
            } ).start();
        }
        //##################################
        //
        // Show the image we want
        // Halfway through, the views
        // will flip
        //
        //##################################/
        else
        {
            rot = ObjectAnimator.ofFloat( tile, "alpha", .99f, 1f );
            rot.setDuration( DURATION );
            
            setScaleX( 1 );
            setRotationY( 0 );
            animate().rotationY( 90 ).setStartDelay( startDelay );
            animate().setDuration( DURATION / 2 ).setInterpolator( new LinearInterpolator() );
            animate().withEndAction( new Runnable()
            {
                @Override
                public void run()
                {
                    // swap the views
                    cardFlipped = true;
                    tileNum = card[ 1 ];
                    // Reverse the image so it looks correct
                    setBackgroundResource( tileNum );
                    
                    //
                    setRotationY( 90 );
                    setScaleX( -1 );
                    animate().rotationY( 180 );
                    animate().setDuration( DURATION / 2 ).setInterpolator( new LinearInterpolator() );
                    animate().setUpdateListener( new ValueAnimator.AnimatorUpdateListener()
                    {
                        @Override
                        public void onAnimationUpdate( ValueAnimator animation )
                        {
                            if ( getScaleX() != -1 )
                            {
                                setScaleX( -1 );
                            }
                        }
                    } );
                    animate().withEndAction( new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            setScaleX( 1 );
                            setRotationY( 0 );
                            animate().setUpdateListener( null );
                        }
                    } ).start();
                }
            } ).start();
        }
        
        //
        rot.start();
        
        return rot;
    }
    
    
    /**
     * //##############################
     * <p>
     * Flip the coin slightly
     * <p>
     * //##############################
     */
    public ObjectAnimator slideTo( float y, float x, int DURATION )
    {
        ObjectAnimator obj;
        float          transY;
        float          transX;
        
        //
        transX = x;
        transY = y;
        
        setPivotX( getWidth() / 2f );
        setPivotY( getHeight() / 2f );
        
        //
        obj = ObjectAnimator.ofFloat( this, "alpha", .99f, 1f );
        obj.setDuration( DURATION );
        
        
        // Animate the item going to where it is housed
        animate().translationX( transX ).scaleX( .1f );
        animate().translationY( transY ).scaleY( .1f );
        animate().setDuration( DURATION ).setInterpolator( new AccelerateInterpolator() );
        animate().start();
        
        obj.start();
        
        return obj;
    }
    
    @Override
    protected void onDetachedFromWindow()
    {
        context = null;
        valueAnimator = null;
        animator = null;
        onAnimationCompleteListener = null;
        
        super.onDetachedFromWindow();
    }
}
