package com.genesyseast.coinconnection.GameGraphics;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Shader;
import android.graphics.Xfermode;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.AnticipateInterpolator;
import android.view.animation.AnticipateOvershootInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;
import androidx.core.graphics.BlendModeColorFilterCompat;
import androidx.core.graphics.BlendModeCompat;
import androidx.gridlayout.widget.GridLayout;

import com.genesyseast.coinconnection.Support.AnimationValues;
import com.genesyseast.coinconnection.Support.CustomBounceInterpolator;
import com.genesyseast.coinconnection.Support.CustomEvaluator;
import com.genesyseast.coinconnection.CustomControls.BoardTile;
import com.genesyseast.coinconnection.CustomControls.CustomTimer;
import com.genesyseast.coinconnection.CustomControls.GradientTextView;
import com.genesyseast.coinconnection.CustomControls.ImageTextView;
import com.genesyseast.coinconnection.Fragments.ConnectionsFragment;
import com.genesyseast.coinconnection.GameEngine.GameBoard;
import com.genesyseast.coinconnection.GameEngine.GameEngine;
import com.genesyseast.coinconnection.GameEngine.LogicThread;
import com.genesyseast.coinconnection.MainActivity;
import com.genesyseast.coinconnection.PlaySound.PlaySound;
import com.genesyseast.coinconnection.R;
import com.genesyseast.coinconnection.Variables.Mapper;
import com.genesyseast.coinconnection.Variables.PointXYZ;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Locale;
import java.util.Random;

public class ConnectionsGridLayout
        extends GridLayout
        implements View.OnTouchListener
{
    
    private static class tileGroup
    {
        int                tileNum;
        int                count;
        ArrayList<Integer> position;
    }
    
    public static final int MIN_FOR_SPECIAL = 5;
    public static final int MAX_FOR_SPECIAL = 12;
    final public static int SCORE_UPDATE    = 0;
    final public static int BONUS_SPLASH    = 1;
    final public static int MOVES_UPDATE    = 2;
    
    
    private       Context              context;
    public static int                  gMapWidth;
    public static int                  gMapHeight;
    public        int                  mapWidth;
    public        int                  mapHeight;
    private       View                 mainView;
    private       GameBoard            gameBoard;
    private       GameEngine           gameEngine;
    private       LogicThread          logicThread;
    //
    private       ArrayList<BoardTile> boardTiles;
    public        ArrayList<View>      targetViews;
    public        ArrayList<Integer>   tilePoints;
    public        ArrayList<Integer>   gemsToMatch;
    //
    private       int[]                coinSet;
    private       int[]                coinGlow;
    private       int[]                coinBg;
    private         int[] glowColors;
    private       int                  maxColors;
    // Symbols mapping
    public        int[][]              boardMap;
    public        int[][]              matchList;
    // Used for hints AND to determine if any matches exist
    public        Point                hintTile;
    //
    public        ArrayList<Mapper>    specials;
    private       OnGridUpdateListener onGridUpdateListener;
    //
    private       OnBoosterListener    onBoosterListener;
    private       int                  boosterItem      = -1;
    //
    private       Random               r;
    public        int                  specialMerge     = 0;
    private       int                  boardMoves       = 0;
    private       int                  loopPosition     = 0;
    private       CustomTimer          timer;
    private       long                 SUPER_TIME_VALUE = 45000;
    public        boolean              noMatchesTrigger = false;
    // Should only be false when a game is completed!
    private       boolean              inHelper         = false;
    public        boolean              canSolveMatches  = true;
    private       int                  matchColor       = -1;
    private       int                  size;
    private       LinearGradient       linearGradient;
    private       Paint                paint;
    private       Paint                subPaint;
    private       boolean              levelCompleted   = false;
    private       boolean              canTouch         = true;
    //
    public        Bitmap               lineBuffer;
    public        Canvas               bufCanvas;
    private       int[]                tileTypes;
    private       int                  testTile         = 0;
    private       String[]             itemNames;//        = {
    //            "Clock", "Bomb", "Star", "Lightning", "Orb", "Beam", "Randomizer", "Shuffler", "Red Gem", "Blue Gem", "Purple Gem", "Yellow Gem"
    //    };
    
    private int              DIV_NUM   = 2;
    private int              TOUCH_NUM = 3;
    private LinearLayout     matchHintLayout;// = mainView.findViewById( R.id.matchHintLayout );
    private ImageView        matchHintIcon;//  = mainView.findViewById( R.id.matchHintIcon );
    private GradientTextView matchHintText;// = mainView.findViewById( R.id.matchHintText );
    private int[]            iconList  = {
            /*            R.drawable.clock_1, R.drawable.bomb_1, R.drawable.star_1,         //
                        R.drawable.bolt_1, R.drawable.spark_1, R.drawable.charge_beam_1,  //
                        R.drawable.question_mark_1,*/ R.drawable.shuffle
    };
    private float[]          cMatrix   = {
            .50f, 0, 0, 0, 0, //red
            0, .50f, 0, 0, 0, //green
            0, 0, .50f, 0, 0, //blue
            0, 0, 0, 1, 0     //alpha
    };
    
    
    private boolean wentback = false;
    
    public interface OnGridUpdateListener
    {
        void onGridUpdated( int gridFunction, int gridData );
        
        void onNoMoreMatches();
        
        void onLevelComplete();
    }
    
    public interface OnBoosterListener
    {
        void boosterLocationSet( int location );
    }
    
    
    /**
     * //###############################
     * <p>
     * Class constructor
     * <p>
     * //###############################
     *
     * @param context N/A
     */
    public ConnectionsGridLayout( Context context )
    {
        super( context );
        
        this.context = context;
        this.inHelper = false;
        this.boosterItem = -1;
        
        //###############################
        //
        // Items to be freed for GC
        //
        //###############################
        targetViews = new ArrayList<>();
        specials = new ArrayList<>();
        r = new Random( 10293846 );
        tileTypes = new int[ BoardTile.YELLOW_GEM ];
        
        // List of names for items
        gameBoard = GameBoard.getInstance( context );
        gameEngine = GameEngine.getInstance( context );
        
        // Get the distances we will use for testing
        size = getResources().getDimensionPixelSize( R.dimen.TILE_SIZE );
        tilePoints = new ArrayList<>();
        gemsToMatch = new ArrayList<>();
        //
        setOnTouchListener( this );
        
        // Shader
        int[] colorList;

        // Regular gradient
        String[] nums2str = getResources().getStringArray( R.array.white_on_white );
        colorList = new int[ nums2str.length ];
        
        for ( int i = 0; i < nums2str.length; i++ )
        {
            colorList[ i ] = ( int ) Long.parseLong( nums2str[ i ].substring( 2 ), 16 );
        }
        
        linearGradient = new LinearGradient( 0, 0, size, 0, colorList, null, Shader.TileMode.MIRROR );
        paint = new Paint();
        subPaint = new Paint();
        
        //        paint.setColor( 0xFFe36dd0 );
        //paint.setShader( linearGradient );
        paint.setStrokeWidth( 6 * getResources().getDimensionPixelSize( R.dimen._1sdp ) );
        //
        subPaint.setColor( Color.BLACK );
        subPaint.setStrokeWidth( 10 * getResources().getDimensionPixelSize( R.dimen._1sdp ) );
        
        setUseDefaultMargins( false );
    
// Glowing color beam
        glowColors = getResources().getIntArray( R.array.glow_colors );
        
        //        ColorMatrix matrix = new ColorMatrix();
        //        matrix.setSaturation( 0 );  //0 means grayscale
        //        ColorMatrixColorFilter cf = new ColorMatrixColorFilter( matrix );
    }
    
    public ConnectionsGridLayout( Context context, AttributeSet attrs )
    {
        super( context, attrs );
        
        this.context = context;
        this.inHelper = false;
        this.boosterItem = -1;
        
        //###############################
        //
        // Items to be freed for GC
        //
        //###############################
        targetViews = new ArrayList<>();
        specials = new ArrayList<>();
        r = new Random( 10293846 );
        tileTypes = new int[ BoardTile.YELLOW_GEM ];
        
        // List of names for items
        gameBoard = GameBoard.getInstance( context );
        gameEngine = GameEngine.getInstance( context );
        
        // Get the distances we will use for testing
        size = getResources().getDimensionPixelSize( R.dimen.TILE_SIZE );
        tilePoints = new ArrayList<>();
        gemsToMatch = new ArrayList<>();
        
        //
        setOnTouchListener( this );
        
        // Shader
        int[] colorList;
        // Regular gradient
        //        String[] nums2str = getResources().getStringArray( R.array.silver_reflection );
        String[] nums2str = getResources().getStringArray( R.array.white_on_white );
        colorList = new int[ nums2str.length ];
        
        for ( int i = 0; i < nums2str.length; i++ )
        {
            colorList[ i ] = ( int ) Long.parseLong( nums2str[ i ].substring( 2 ), 16 );
        }
        
        linearGradient = new LinearGradient( 0, 0, size, 0, colorList, null, Shader.TileMode.MIRROR );
        paint = new Paint();
        subPaint = new Paint();
        
        //        paint.setColor( 0xFFe36dd0 );
        //paint.setShader( linearGradient );
        paint.setStrokeWidth( 6 * getResources().getDimensionPixelSize( R.dimen._1sdp ) );
        //
        subPaint.setColor( Color.BLACK );
        subPaint.setStrokeWidth( 10 * getResources().getDimensionPixelSize( R.dimen._1sdp ) );
        
        setUseDefaultMargins( false );
    
        // Glowing color beam
        glowColors = getResources().getIntArray( R.array.glow_colors );
    }
    
    public ConnectionsGridLayout( Context context, AttributeSet attrs, int defStyle )
    {
        super( context, attrs, defStyle );
        
        this.context = context;
        this.inHelper = false;
        this.boosterItem = -1;
        
        //###############################
        //
        // Items to be freed for GC
        //
        //###############################
        targetViews = new ArrayList<>();
        specials = new ArrayList<>();
        r = new Random( 10293846 );
        tileTypes = new int[ BoardTile.YELLOW_GEM ];
        
        // List of names for items
        gameBoard = GameBoard.getInstance( context );
        gameEngine = GameEngine.getInstance( context );
        
        // Get the distances we will use for testing
        size = getResources().getDimensionPixelSize( R.dimen.TILE_SIZE );
        tilePoints = new ArrayList<>();
        gemsToMatch = new ArrayList<>();
        
        //
        setOnTouchListener( this );
        
        // Shader
        int[] colorList;
        // Regular gradient
        //        String[] nums2str = getResources().getStringArray( R.array.silver_reflection );
        String[] nums2str = getResources().getStringArray( R.array.white_on_white );
        colorList = new int[ nums2str.length ];
        
        for ( int i = 0; i < nums2str.length; i++ )
        {
            colorList[ i ] = ( int ) Long.parseLong( nums2str[ i ].substring( 2 ), 16 );
        }
        
        linearGradient = new LinearGradient( 0, 0, size, 0, colorList, null, Shader.TileMode.MIRROR );
        paint = new Paint();
        subPaint = new Paint();
        
        //        paint.setColor( 0xFFe36dd0 );
        //paint.setShader( linearGradient );
        paint.setStrokeWidth( 6 * getResources().getDimensionPixelSize( R.dimen._1sdp ) );
        //
        subPaint.setColor( Color.BLACK );
        subPaint.setStrokeWidth( 10 * getResources().getDimensionPixelSize( R.dimen._1sdp ) );
        
        setUseDefaultMargins( false );
    
        // Glowing color beam
        glowColors = getResources().getIntArray( R.array.glow_colors );
    }
    
    
    public void setBoardTiles( ArrayList<BoardTile> boardTiles )
    {
        this.boardTiles = boardTiles;
    }
    
    
    /**
     * //###############################
     * <p>
     * <p>
     * //###############################
     *
     * @param logicThread
     */
    public void setLogicThread( LogicThread logicThread )
    {
        this.logicThread = logicThread;
    }
    
    
    public static int getMapWidth()
    {
        return gMapWidth;
    }
    
    public static int getMapHeight()
    {
        return gMapHeight;
    }
    
    
    /**
     * //###############################
     * <p>
     * Setters for map sizes
     * <p>
     * //###############################
     *
     * @param mapWidth N/A
     */
    public void setMapWidth( int mapWidth )
    {
        this.inHelper = false;
        this.mapWidth = mapWidth;
        setRowCount( mapWidth );
        
        if ( this.mapWidth > 0 && this.mapHeight > 0 )
        {
            matchList = new int[ this.mapHeight ][ this.mapWidth ];
            //
            boardTiles = gameBoard.getBoardTiles();
            boardMap = gameBoard.getBoardMap();
            coinSet = gameBoard.getCoinSet();
            coinBg = gameBoard.getCoinBg();
            coinGlow = gameBoard.getCoinGlow();
            maxColors = gameBoard.getMaxColors();
            //
            gMapHeight = mapHeight;
            gMapWidth = mapWidth;
            
            if ( lineBuffer == null )
            {
                lineBuffer = Bitmap.createBitmap( getWidth(), getHeight(), Bitmap.Config.ARGB_8888 );
                bufCanvas = new Canvas( lineBuffer );
            }
        }
    }
    
    public void setMapHeight( int mapHeight )
    {
        this.inHelper = false;
        this.mapHeight = mapHeight;
        setColumnCount( mapHeight );
        
        if ( this.mapWidth > 0 && this.mapHeight > 0 )
        {
            matchList = new int[ this.mapHeight ][ this.mapWidth ];
            //
            boardTiles = gameBoard.getBoardTiles();
            boardMap = gameBoard.getBoardMap();
            coinSet = gameBoard.getCoinSet();
            coinGlow = gameBoard.getCoinGlow();
            coinBg = gameBoard.getCoinBg();
            maxColors = gameBoard.getMaxColors();
            //
            gMapHeight = mapHeight;
            gMapWidth = mapWidth;
            
            if ( lineBuffer == null )
            {
                lineBuffer = Bitmap.createBitmap( getWidth(), getHeight(), Bitmap.Config.ARGB_8888 );
                bufCanvas = new Canvas( lineBuffer );
            }
        }
    }
    
    public void setMainView( View mainView )
    {
        this.mainView = mainView;
        
        // Need to get the target views and do it ONCE!!!
        ConstraintLayout layout = mainView.findViewById( R.id.boardTargetHolder );
        
        if ( layout != null )
        {
            this.inHelper = false;
            int children = layout.getChildCount();
            
            // Clear crap to be safe
            targetViews.clear();
            
            // Get those views
            for ( int c = 0; c < children; c++ )
            {
                View view = layout.getChildAt( c );
                
                if ( view instanceof TextView && view.getId() != R.id.targetText )
                {
                    targetViews.add( ( TextView ) view );
                }
            }
        }
        
        //
        // Stop reloading this in onTouch
        //
/*
        matchHintLayout = mainView.findViewById( R.id.matchHintLayout );
        matchHintIcon = mainView.findViewById( R.id.matchHintIcon );
*/
        //        matchHintText = mainView.findViewById( R.id.matchHintText );
    }
    
    public void setBoardMoves( int boardMoves )
    {
        this.boardMoves = boardMoves;
    }
    
    public void setTimer( CustomTimer timer )
    {
        this.timer = timer;
    }
    
    public void setLevelCompleted( boolean levelCompleted )
    {
        this.levelCompleted = levelCompleted;
    }
    
    public boolean isLevelCompleted()
    {
        return levelCompleted;
    }
    
    
    /**
     * //###############################
     * <p>
     * Setters for map sizes
     * <p>
     * //###############################
     */
    public void setHelperGrid( ArrayList<BoardTile> boardTiles, int mapWidth, int mapHeight, boolean inHelper )
    {
        this.mapWidth = mapWidth;
        this.mapHeight = mapHeight;
        this.inHelper = inHelper;
        
        if ( this.mapWidth > 0 && this.mapHeight > 0 )
        {
            this.boardTiles = boardTiles;
            coinSet = gameBoard.getCoinSet();
            coinBg = gameBoard.getCoinBg();
            coinGlow = gameBoard.getCoinGlow();
            maxColors = BoardTile.MAX_COINS;
            //
            gMapHeight = mapHeight;
            gMapWidth = mapWidth;
            
            matchList = new int[ this.mapHeight ][ this.mapWidth ];
            boardMap = new int[ mapHeight ][ mapWidth ];
            
            setColumnCount( gMapWidth );
            setRowCount( gMapHeight );
            
            if ( lineBuffer == null && getWidth() > 0 && getHeight() > 0 )
            {
                lineBuffer = Bitmap.createBitmap( getWidth(), getHeight(), Bitmap.Config.ARGB_8888 );
                bufCanvas = new Canvas( lineBuffer );
            }
        }
    }
    
    
    /**
     * ########################################
     * <p>
     * Attach a listener
     * <p>
     * ########################################
     *
     * @param onGridUpdateListener N/A
     */
    public void setOnGridUpdateListener( OnGridUpdateListener onGridUpdateListener )
    {
        this.onGridUpdateListener = onGridUpdateListener;
    }
    
    
    /**
     * //###############################
     * <p>
     * Draw the connecting line
     * <p>
     * //###############################
     *
     * @param canvas
     */
    @Override
    protected void onDraw( Canvas canvas )
    {
        if ( lineBuffer != null )
        {
            canvas.drawBitmap( lineBuffer, 0, 0, paint );
        }
    }
    
    
    /**
     * //###############################
     * <p>
     * Default caller
     * <p>
     * //###############################
     */
    public void onDrawGrid()
    {
        onDrawGrid( inHelper );
    }
    
    
    /**
     * //###############################
     * <p>
     * My adapter, custom made
     * <p>
     * //###############################
     *
     * @param isHelper
     */
    public void onDrawGrid( boolean isHelper )
    {
        int                   size    = context.getResources().getDimensionPixelSize( R.dimen.TILE_SIZE );
        int                   padding = 0;//context.getResources().getDimensionPixelSize( R.dimen._1sdp );
        GridView.LayoutParams params;
        
        //##############################
        // Some times the user pauses
        // the game exit. Leave if exit
        // was too early!
        //##############################
        if ( boardTiles == null )
        {
            //            GameEngine.gamePaused = false;
            //            MainActivity.getActivity().getFragmentManager().popBackStack();
            return;
        }
        
        
        // Assist help function by NOT crashing!
        inHelper = isHelper;
        if ( !isHelper )
        {
            // Original board mapping
            Arrays.fill( tileTypes, 0 );
            
            // Clear gem count
            gemsToMatch.clear();
            
            //
            GameEngine.arrayCopy( boardMap, matchList, mapHeight, mapWidth );
            // No hints
            logicThread.setHintTimer( CustomTimer.currentTime );
        }
        else
        {
            size = context.getResources().getDimensionPixelSize( R.dimen._32sdp );
        }
        
        
        // Set parameters
        params = new GridView.LayoutParams( size, size );
        //
        tilePoints.clear();
        
        
        //####################################
        //
        // Draw each image
        //
        //####################################
        removeAllViews();
        
        // No need to continue if animations are disabled
        if ( MainActivity.checkSystemAnimationsDuration( getContext() ) == 0 )
        {
            AlertDialog.Builder dialog = new AlertDialog.Builder( getContext() );
            
            dialog.setMessage( getContext().getString( R.string.anims_disabled ) );
            dialog.setPositiveButton( "Exit", new DialogInterface.OnClickListener()
            {
                @Override
                public void onClick( DialogInterface dialog, int which )
                {
                    System.exit( 1 );
                }
            } );
            
            //
            dialog.create().show();
            return;
        }
        
        //
        //###########################
        //
        for ( int position = 0; position < boardTiles.size() && !GameEngine.isKilled; position++ )
        {
            final BoardTile image;
            
            // Is the game completed already??
            if ( levelCompleted )
            {
                return;
            }
            
            //
            image = boardTiles.get( position );
            
            image.cancelAnimationAndListeners();
            //            image.setOnTouchListener( this );
            //            image.setOnClickListener( this );
            //            image.setOnLongClickListener( this );
            
            // Anything swapped, fix it here
            image.setTranslationX( 0 );
            image.setTranslationY( 0 );
            image.setSoundEfx( -1 );
            
            
            //###################################
            //
            // Find and record all active gems
            //
            //###################################
            if ( image.tileNum >= BoardTile.RED_GEM )
            {
                gemsToMatch.add( image.getPosition() );
            }
            
            //
            // Handle the initial board spawning
            //
            if ( image.getState() == BoardTile.STATE_INACTIVE && image.tileNum == -1 )
            {
                // Blank image requested
                image.setImageResource( 0 );
                image.setBackgroundResource( 0 );
                image.clearAnimation();
                image.setTag( null );
                image.setVisibility( INVISIBLE );
            }
            else
            {   // Helper data for Error checks also
                image.setScaleY( 1 );
                image.setScaleX( 1 );
                image.setRotation( 0 );
                image.setAlpha( 1f );
                image.clearAnimation();
                
                //
                image.setTag( null );
                image.setVisibility( VISIBLE );
                imageHelper( position );
                image.setState( BoardTile.STATE_ACTIVE );
                
                // Keep count of standard coins
                if ( image.tileNum > -1 && image.tileNum < BoardTile.MAX_COINS )
                {
                    tileTypes[ image.tileNum ]++;
                }
            }
            
            // Now add the image to the GridLayout
            image.setId( position );
            image.setPosition( position );
            image.pointPosi = -1;
            
            // Padding to Image view to keep BG image
            // Visible behind Foreground image
            image.setPadding( padding, padding, padding, padding );
            addView( image, params );
            
            // Add padding to Grid slot to show
            // Dimmed square behind tiles
            setPadding( padding, padding, padding, padding );
            
            if ( position == 0 )
            {
                image.requestLayout();
            }
        }
        
        
        //################################
        //
        // Did we solve gems and NOT
        // replenish the board with a gem?
        //
        //################################
        if ( gemsToMatch.size() == 0 && gameBoard.maxGems > 0 )
        {
            int c = 0;
            
            //
            for ( View view : targetViews )
            {
                final PointXYZ temp = ( PointXYZ ) view.getTag();
                
                // Do we need to place a gem?
                if ( view.getVisibility() == VISIBLE && temp.getTag() == null && temp.y >= BoardTile.RED_GEM && temp.x > 0 )
                {
                    int loop = 0;
                    int i    = r.nextInt( boardTiles.size() );
                    
                    while ( i == -1 || boardTiles.get( i ).tileNum == -1 || boardTiles.get( i ).tileNum >= BoardTile.CLOCK )
                    {
                        if ( loop >= 500 )
                        {
                            i = -1;
                            break;
                        }
                        
                        i = r.nextInt( boardTiles.size() );
                        loop++;
                    }
                    
                    
                    //#######################################
                    //
                    // Gem creation
                    //
                    //#######################################
                    if ( i != -1 )
                    {
                        // Create a projectile to shoot over to
                        // the tile, then transform it
                        final ConstraintLayout frame    = mainView.findViewById( R.id.game_container );
                        ImageView              master   = new ImageView( getContext() );
                        BoardTile              image    = boardTiles.get( i );
                        int[]                  masterXY = new int[ 2 ];
                        int[]                  imageXY  = new int[ 2 ];
                        float                  transX, transY;
                        
                        // Place the projectile where the Gem is
                        master.setLayoutParams( new ConstraintLayout.LayoutParams( view.getWidth(), view.getHeight() ) );
                        master.setImageResource( GameBoard.coinSet[ temp.y ] );
                        frame.addView( master );
                        
                        
                        // Set the final location where the tile is
                        view.getLocationOnScreen( masterXY );
                        // Get the tile's info
                        image.getLocationOnScreen( imageXY );
                        
                        master.setId( view.getId() + c );
                        master.setPivotY( view.getHeight() / 2f );
                        master.setPivotX( view.getWidth() / 2f );
                        
                        // Animate it back onto the board
                        ObjectAnimator       obj;
                        PropertyValuesHolder sx, sy, xMove, yMove;
                        sx = PropertyValuesHolder.ofFloat( "scaleX", 1, 2.5f, 1 );
                        sy = PropertyValuesHolder.ofFloat( "scaleY", 1, 2.5f, 1 );
                        xMove = PropertyValuesHolder.ofFloat( "x", masterXY[ 0 ], imageXY[ 0 ] );
                        yMove = PropertyValuesHolder.ofFloat( "y", masterXY[ 1 ], imageXY[ 1 ] );
                        
                        
                        //
                        obj = ObjectAnimator.ofPropertyValuesHolder( master, sx, sy, xMove, yMove );
                        obj.setInterpolator( new AccelerateInterpolator( 1f ) );
                        obj.setDuration( 350 );
                        obj.addListener( new AnimatorListenerAdapter()
                        {
                            @Override
                            public void onAnimationEnd( Animator animation )
                            {
                                frame.removeView( master );
                                image.tileNum = temp.y;
                                image.setImageResource( GameBoard.coinSet[ temp.y ] );
                                image.specialItem = 3;
                                gemsToMatch.add( image.getPosition() );
                                super.onAnimationEnd( animation );
                            }
                        } );
                        obj.start();
                        
                        // Deactivate this tile from Gem generation
                        image.specialItem = 3;
                    }
                }
                
                //
                c++;
            }
        }
    }
    
    
    /**
     * //###############################
     * <p>
     * Default caller
     * <p>
     * //###############################
     */
    public void onUpdateGrid()
    {
        onUpdateGrid( inHelper );
    }
    
    
    /**
     * //###############################
     * <p>
     * Update the grid
     * <p>
     * //###############################
     */
    public void onUpdateGrid( boolean isHelper )
    {
        // No need to continue if animations are disabled
        if ( MainActivity.checkSystemAnimationsDuration( getContext() ) == 0 )
        {
            AlertDialog.Builder dialog = new AlertDialog.Builder( getContext() );
            
            dialog.setMessage( context.getString( R.string.anims_disabled ) );
            dialog.setPositiveButton( "Exit", new DialogInterface.OnClickListener()
            {
                @Override
                public void onClick( DialogInterface dialog, int which )
                {
                    System.exit( 1 );
                }
            } );
            
            //
            dialog.create().show();
            return;
        }
        
        int     runningScore = 0;
        boolean matchMade    = false;
        int[]   targets      = new int[ coinSet.length ];
        
        
        // Will crash if helper displaying
        if ( !isHelper )
        {
            // Calculate the score to send to the parent view group
            for ( int i = 0; i < coinSet.length; i++ )
            {
                targets[ i ] = 0;
            }
            
            // No hints
            logicThread.setHintTimer( CustomTimer.currentTime );
        }
        
        
        //####################################
        //
        // Draw each image
        //
        //####################################
        for ( int position = 0; position < boardTiles.size() && !GameEngine.isKilled; position++ )
        {
            final BoardTile image;
            final int       index = position;
            Animation       anim;
            
            
            // Is the game completed already??
            if ( levelCompleted )
            {
                return;
            }
            
            //
            image = boardTiles.get( position );
            
            //######################################
            //
            // Handle the board re-spawning
            //
            //######################################
            if ( image.getState() == BoardTile.CREATE_ITEM || image.getState() == BoardTile.MASTER_ITEM )
            {   //
                image.animate().setInterpolator( new LinearInterpolator() );
                image.animate().setUpdateListener( new ValueAnimator.AnimatorUpdateListener()
                {
                    @Override
                    public void onAnimationUpdate( ValueAnimator animation )
                    {
                        if ( image.animator == null )
                        {
                            image.animator = animation;
                        }
                    }
                } );
                
                image.endAnimation();
                image.animate().withLayer().setInterpolator( new LinearInterpolator() );
                image.animate().translationX( image.swapTO.x ).translationY( image.swapTO.y ).setDuration( AnimationValues.SWAP_SPEED );
                image.animate().withEndAction( new Runnable()
                {
                    @Override
                    public void run()
                    {
                        if ( GameEngine.isKilled )
                        {
                            return;
                        }
                        
                        //                        Log.d( "Grid Update", "ITEM CREATED: " + image.getPosition() );
                        if ( image.getState() == BoardTile.CREATE_ITEM )
                        {
                            image.specialItem = -1;
                            image.specialTile = -1;
                            // Child: Still needs to drop
                            image.setVisibility( INVISIBLE );
                            image.setState( BoardTile.STATE_INACTIVE );
                        }
                        else
                        {
                            // Master: Still needs to drop
                            image.setVisibility( VISIBLE );
                            image.setState( BoardTile.STATE_ACTIVE );
                            
                            // Announce its arrival!
                            //                            image.specialTile = image.swapTO.data;
                            imageHelper( image.getPosition() );
                            image.setScaleX( 0f );
                            image.setScaleY( 0f );
                            image.animate().scaleY( 1f ).scaleX( 1f ).setInterpolator( new CustomBounceInterpolator( .2, 20 ) );
                            image.animate().setDuration( 500 ).start();
                            //                            image.setTag( anim );
                            // Create Special Sound
                            if ( gameEngine.soundPlayer != null && !isHelper )
                            {
                                gameEngine.soundPlayer.playBgSfx( PlaySound.SPECIAL_CREATED );
                            }
                        }
                        //
                        image.swapTO.x = 0;
                        image.swapTO.y = 0;
                        image.setTranslationX( 0 );
                        image.setTranslationY( 0 );
                        image.setPivotX( image.getWidth() / 2f );
                        image.setPivotY( image.getHeight() / 2f );
                        //
                        image.animator = null;
                        //image.clearAnimation();
                        //
                        
                        if ( logicThread != null )
                        {
                            logicThread.animationsRunning--;
                            
                            if ( logicThread.animationsRunning <= 0 )
                            {   // ALWAYS create special items OR process matches after REAL SWAP
                                logicThread.animationsRunning = 0;
                                
                                // This can be called from STATE_MATCHED also
                                // but not together. One or the other
                                logicThread.addToStack( LogicThread.CMD_DROP );
                            }
                        }
                    }
                } ).start();
                //
                
                logicThread.animationsRunning++;
                //
                if ( !isHelper )
                {
                    // Add to the score
                    runningScore += (GameEngine.POINTS_PER_TILE * GameEngine.pointsMultiplier);
                    
                    if ( image.tileNum >= BoardTile.CLOCK && image.specialTile > -1 )
                    {
                        adjustTargetCounts( targets, image.specialTile );
                    }
                    else
                    {
                        adjustTargetCounts( targets, image.tileNum );
                    }
                    //
                    matchMade = true;
                }
            }
            else if ( image.getState() == BoardTile.MASTER_ITEM_TO_GIVE )
            {   //
                image.animate().setInterpolator( new LinearInterpolator() );
                image.animate().setUpdateListener( new ValueAnimator.AnimatorUpdateListener()
                {
                    @Override
                    public void onAnimationUpdate( ValueAnimator animation )
                    {
                        if ( image.animator == null )
                        {
                            image.animator = animation;
                        }
                    }
                } );
                
                image.endAnimation();
                image.animate().withLayer().setInterpolator( new LinearInterpolator() );
                image.animate().translationX( image.swapTO.x ).translationY( image.swapTO.y ).setDuration( AnimationValues.SWAP_SPEED );
                image.animate().withEndAction( new Runnable()
                {
                    @Override
                    public void run()
                    {
                        if ( GameEngine.isKilled )
                        {
                            return;
                        }
                        
/*
                        ViewGroup       group         = mainView.findViewById( R.id.specialParent );
                        int             index         = (image.tileNum - BoardTile.BOMB);
                        float           transY;
                        float           transX;
                        int             count         = group.getChildCount();
                        int             currentView   = 0;
                        ImageTextView[] imageTextView = new ImageTextView[ count ];
                        
                        
                        // Get all the special item views
                        for ( int i = 0; i < count; i++ )
                        {
                            View v = group.getChildAt( i );
                            
                            if ( v instanceof ImageTextView )
                            {
                                imageTextView[ currentView ] = ( ImageTextView ) v;
                                currentView++;
                            }
                        }
                        
                        //
                        final ImageTextView temp = imageTextView[ index ];
                        image.setPivotX( image.getWidth() / 2f );
                        image.setPivotY( image.getHeight() / 2f );
                        
                        // Animate the item going to where it is housed
                        int[] vLoc     = new int[ 2 ];
                        int[] imageLoc = new int[ 2 ];
                        
                        temp.getLocationOnScreen( vLoc );
                        image.getLocationOnScreen( imageLoc );
                        
                        transX = vLoc[ 0 ] - imageLoc[ 0 ];
                        transY = vLoc[ 1 ] - imageLoc[ 1 ];
                        
                        // Show the special's symbol
                        imageHelper( image.getPosition() );
                        
                        //#################################
                        //
                        // Move the item to the player
                        //
                        //#################################
                        image.animate().translationX( transX ).scaleX( .5f );
                        image.animate().translationY( transY ).scaleY( .5f );
                        image.animate().setDuration( 350 ).setInterpolator( new AccelerateInterpolator( 1f ) );
                        image.animate().withEndAction( new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                image.setImageResource( 0 );
                                
                                //@@@@@@@@@@@@@@@@@@@ Add to the stash
                                if ( gameEngine.soundPlayer != null )
                                {
                                    gameEngine.soundPlayer.play( PlaySound.POINTS_ADD );
                                }
                                
                                
                                //#################################
                                //
                                // Master: Still needs to drop
                                //
                                //#################################
                                image.setVisibility( VISIBLE );
                                image.setState( BoardTile.STATE_ACTIVE );
                                
                                
                                //
                                int i = r.nextInt( maxColors );
                                image.tileNum = i;
                                image.specialItem = 0;
                                image.specialTile = -1;
                                
                                image.swapTO.x = 0;
                                image.swapTO.y = 0;
                                image.setTranslationX( 0 );
                                image.setTranslationY( 0 );
                                image.setPivotX( image.getWidth() / 2f );
                                image.setPivotY( image.getHeight() / 2f );
                                //
                                image.animator = null;
                                //image.clearAnimation();
                                //
                                
                                if ( logicThread != null )
                                {
                                    logicThread.animationsRunning--;
                                    
                                    if ( logicThread.animationsRunning <= 0 )
                                    {   // ALWAYS create special items OR process matches after REAL SWAP
                                        logicThread.animationsRunning = 0;
                                        
                                        // This can be called from STATE_MATCHED also
                                        // but not together. One or the other
                                        logicThread.addToStack( LogicThread.CMD_DROP );
                                    }
                                }
                                
                                //
                                gameEngine.Boosters[ index ]++;
                                
                                // Add the numbers to the special and make it respond
                                temp.setText( String.format( Locale.getDefault(), "%d", gameEngine.Boosters[ index ] ) );
                                temp.setScaleX( 0 );
                                temp.setScaleY( 0 );
                                temp.setAlpha( 0f );
                                temp.animate().alpha( 1 ).scaleX( 1 ).scaleY( 1 );
                                temp.animate().setInterpolator( new CustomBounceInterpolator( 0.2, 20 ) );
                                temp.animate().setDuration( 250 ).start();
                            }
                        } ).start();
*/

    
/*
                        //#################################
                        // Master: Still needs to drop
                        //#################################
                        image.setVisibility( VISIBLE );
                        image.setState( BoardTile.STATE_ACTIVE );
                        
                        // Announce its arrival!
                        imageHelper( image.getPosition() );
                        //
                        image.swapTO.x = 0;
                        image.swapTO.y = 0;
                        image.setTranslationX( 0 );
                        image.setTranslationY( 0 );
                        image.setPivotX( image.getWidth() / 2f );
                        image.setPivotY( image.getHeight() / 2f );
                        //
                        image.animator = null;
                        //image.clearAnimation();
                        //
                        
                        if ( logicThread != null )
                        {
                            logicThread.animationsRunning--;
                            
                            if ( logicThread.animationsRunning <= 0 )
                            {   // ALWAYS create special items OR process matches after REAL SWAP
                                logicThread.animationsRunning = 0;
                                
                                // This can be called from STATE_MATCHED also
                                // but not together. One or the other
                                logicThread.addToStack( LogicThread.CMD_DROP );
                            }
                        }
*/
                    }
                } ).start();
                //
                
                logicThread.animationsRunning++;
                //
                if ( !isHelper )
                {
                    // Add to the score
                    runningScore += (GameEngine.POINTS_PER_TILE * GameEngine.pointsMultiplier);
                    
                    if ( image.tileNum >= BoardTile.CLOCK && image.specialTile > -1 )
                    {
                        adjustTargetCounts( targets, image.specialTile );
                    }
                    else
                    {
                        adjustTargetCounts( targets, image.tileNum );
                    }
                    //
                    matchMade = true;
                }
            }
            else if ( image.getState() == BoardTile.ANNOUNCE_PRESENCE )
            {
                if ( image.getSoundEfx() == -1 && !isHelper )
                {
                    //@@@@@@@@@@@@@@@@@ Create Special Sound
                    if ( gameEngine.soundPlayer != null )
                    {
                        gameEngine.soundPlayer.playBgSfx( PlaySound.SPECIAL_CREATED );
                    }
                }
                //
                image.setSoundEfx( -1 );
                
                //
                image.setState( BoardTile.STATE_ACTIVE );
                // Announce its arrival!
                imageHelper( image.getPosition() );
                //
                image.setScaleX( .5f );
                image.setScaleY( .5f );
                image.setAlpha( 0.5f );
                image.animate().alpha( 1f ).scaleX( 1f ).scaleY( 1f ).setInterpolator( new CustomBounceInterpolator( 0.2, 20 ) );
                image.animate().setDuration( 500 ).withEndAction( new Runnable()
                {
                    @Override
                    public void run()
                    {
                        if ( GameEngine.isKilled )
                        {
                            return;
                        }
                        
                        image.setScaleY( 1 );
                        image.setScaleX( 1 );
                    }
                } ).start();
            }
            else if ( image.getState() == BoardTile.USE_SPECIAL_ITEM )
            {
                boolean canMatch = true;
                
                // If this is reached, this is the only view that is
                // set to anything other than IN/ACTIVE
                // The called method should build a NEW 'matchList'
                switch ( image.tileNum )
                {
                    case BoardTile.CLOCK:
                        if ( !isHelper )
                        {
                            adjustTargetCounts( targets, image.specialTile );
                        }
                        //
                        useAClock( image );
                        break;
                    case BoardTile.BOMB:
                        useABomb( image, 0 );
                        break;
                    case BoardTile.BOLT:
                        useABolt( image );
                        break;
                    case BoardTile.STAR_GOLD:
                        useAStar( image );
                        break;
                    case BoardTile.SPARK:
                        useSpark( image );
                        break;
                    case BoardTile.CHARGE_BEAM:
                        useChargeBeam( image );
                        break;
                    case BoardTile.RANDOM_SPECIAL:
                        useRandom( image );
                        break;
                    case BoardTile.SHUFFLER:
                        useShuffler( image );
                        break;
                    default:
                        Toast.makeText( getContext(), "Special not supported: " + image.tileNum, Toast.LENGTH_SHORT ).show();
                        canMatch = false;
                        break;
                }
                
                // Animate the 'SIGNAL_MATCHES' with whatever the special did
                if ( canMatch )
                {
                    // Remove special item status so the loop can break!
                    // All statuses should now be 'SPECIAL_ANIMATE'
                    // Reset old specials to normal
                    image.specialItem = -1;
                    image.specialTile = -1;
                    
                    //
                    if ( image.getTag() != null )
                    {
                        animatorHelper( position );
                    }
                    
                    
                    // MUST RESTART THIS METHOD NOW OR ALL TILES AFTER
                    // INITIATOR TILE WILL FIRE OUT OF SYNC; IE: multiple specials
                    //
                    // DOES NOT APPLY TO CLOCK Because it is auto activated
                    // And matched on drop is possible which messes up
                    // logicThread.animationRunning
                    // Reset to start messes with coins awaiting DROP
                    if ( image.tileNum != BoardTile.CLOCK )
                    {
                        position = -1;
                        continue;
                    }
                }
            }
            else if ( image.getState() == BoardTile.USE_SPECIAL_ITEM_NEXT )
            {
                image.setState( BoardTile.STATE_ACTIVE );
            }
            else if ( image.getState() == BoardTile.STATE_RESPAWN )
            {
                // Drop from the top
                // Now in dropping state
                image.setState( BoardTile.STATE_DROPPING );
                
                int maxLoops = 0;
                int i        = r.nextInt( maxColors );
                int x        = image.getPosition() % mapWidth;
                int y        = image.getPosition() / mapHeight;
                
                
                //##################################
                //
                // Need to favor the tiles that need
                // to be solved the most
                //
                //##################################
                boolean found = false;
                Point   high  = new Point( 0, 0 );
                
                //#############################
                //
                // Don't do every time down.
                // keep some randomness
                //
                //#############################
                if ( r.nextInt( 3 ) == 1 )
                    /*if ( r.nextBoolean() )*/
                {
                    int c = 0;
                    
                    for ( View v : targetViews )
                    {
                        //
                        if ( v.getVisibility() == VISIBLE && c < BoardTile.MAX_COINS && v.getTag() != null )
                        {
                            final PointXYZ target = ( PointXYZ ) v.getTag();
                            
                            int difference = (target.x - tileTypes[ c ]);
                            
                            // MUST be a color that has a high target range
                            // MUST be a color with a high range, but less
                            // colors on board
                            //                        if ( target.x > high.x &&  tileTypes[ c ] < onBoardLow )
                            if ( high.x < difference )
                            {
                                high.x = target.x;
                                high.y = c;
                                found = true;
                            }
                        }
                        
                        //
                        c++;
                    }
                }
                // Do we have a target that needs attention?
                
                
                // Fixed duplicate color issue
                if ( found )
                {
                    i = high.y;
                }
                
                //#####################################
                //
                // Must add this color to the stack
                //
                //#####################################
                if ( image.tileNum < BoardTile.MAX_COINS )
                {
                    tileTypes[ i ]++;
                }
                
                image.tileNum = i;
                image.specialItem = 0;
                image.specialTile = -1;
                
                //
                imageHelper( image.getPosition() );
                image.setVisibility( VISIBLE );
                //
                image.animate().withLayer().setInterpolator( new LinearInterpolator() );
                image.animate().setUpdateListener( new ValueAnimator.AnimatorUpdateListener()
                {
                    @Override
                    public void onAnimationUpdate( ValueAnimator animation )
                    {
                        if ( image.animator == null )
                        {
                            image.animator = animation;
                        }
                    }
                } );
                //
                //                                image.setTranslationY( -image.getBottom() );
                image.setTranslationY( -getHeight() );
                image.animate().setDuration( AnimationValues.DROP_TIME );//.setStartDelay( image.getDelayTime() );
                image.animate().translationY( 0 ).withEndAction( new Runnable()
                {
                    @Override
                    public void run()
                    {
                        if ( GameEngine.isKilled )
                        {
                            return;
                        }
                        
                        image.setVisibility( VISIBLE );
                        image.setState( BoardTile.STATE_ACTIVE );
                        image.animator = null;
                        //
                        //                        Log.d( "Grid Update", "SPAWNED: " + image.getPosition() );
                        
                        if ( logicThread != null )
                        {
                            logicThread.animationsRunning--;
                            
                            if ( logicThread.animationsRunning <= 0 )
                            {   // ALWAYS test again after DROP / RESPAWN complete
                                logicThread.animationsRunning = 0;
                                //                            logicThread.addToStack( LogicThread.CMD_TEST_AGAIN );
                                logicThread.addToStack( LogicThread.CMD_IDLE );
                            }
                        }
                    }
                } ).start();
                
                //                Log.d( "Grid Update", "SPAWNING: " + image.getPosition() );
                // Add to the animation counter
                logicThread.animationsRunning++;
            }
            else if ( image.getState() == BoardTile.STATE_DROP )
            {
                // Drop from the current spot
                // Items with extra BG effect start them NOW
                imageHelper( image.getPosition() );
                
                // Offsets tile will animate TO
                final float toX = (image.getX() - image.swapTO.x);
                final float toY = (image.getY() - image.swapTO.y);
                
                // The offsets tile will animate FROM
                image.setTranslationX( -toX );
                image.setTranslationY( -toY );
                image.endAnimation();
                
                // Now in dropping state
                image.setState( BoardTile.STATE_DROPPING );
                image.setVisibility( VISIBLE );
                //
                image.animate().setUpdateListener( new ValueAnimator.AnimatorUpdateListener()
                {
                    @Override
                    public void onAnimationUpdate( ValueAnimator animation )
                    {
                        if ( image.animator == null )
                        {
                            image.animator = animation;
                        }
                    }
                } );
                //
                //                image.animate().withLayer();//.setStartDelay( image.getDelayTime() );
                image.animate().translationX( 0 ).translationY( 0 ).setInterpolator( new LinearInterpolator() );
                image.animate().setDuration( AnimationValues.DROP_TIME / 2 ).withEndAction( new Runnable()
                {
                    @Override
                    public void run()
                    {
                        if ( GameEngine.isKilled )
                        {
                            return;
                        }
                        
                        image.setState( BoardTile.STATE_ACTIVE );
                        image.setVisibility( VISIBLE );
                        //
                        //Log.d( "Grid Update", "DROPPED: " + image.getPosition() );
                        
                        if ( logicThread != null )
                        {
                            
                            logicThread.animationsRunning--;
                            
                            if ( logicThread.animationsRunning <= 0 )
                            {   // ALWAYS test again after DROP / RESPAWN complete
                                logicThread.animationsRunning = 0;
                                //                            logicThread.addToStack( LogicThread.CMD_TEST_AGAIN );
                                logicThread.addToStack( LogicThread.CMD_IDLE );
                            }
                        }
                    }
                } ).start();
                
                logicThread.animationsRunning++;
                //Log.d( "Grid Update", "DROPPING: " + image.getPosition() );
            }
            // Draw standard board symbol
            else if ( image.getState() == BoardTile.STATE_ACTIVE )
            {
                image.endAnimation();
                imageHelper( image.getPosition() );
            }
            else if ( image.getState() == BoardTile.STATE_MATCHED )
            {
                View     v;
                PointXYZ p;
                
                //
                image.animate().setUpdateListener( new ValueAnimator.AnimatorUpdateListener()
                {
                    @Override
                    public void onAnimationUpdate( ValueAnimator animation )
                    {
                        if ( image.animator == null )
                        {
                            image.animator = animation;
                        }
                    }
                } );
                
                //
                // Do not run this in Help mode
                //
                if ( !isHelper )
                {
                    v = targetViews.get( image.tileNum );
                    p = ( PointXYZ ) v.getTag();
                }
                else
                {
                    v = null;
                    p = null;
                }
                
                
                // Slide to the coin??
                if ( p != null && p.x > 0 )
                {
                    int[] vLoc     = new int[ 2 ];
                    int[] imageLoc = new int[ 2 ];
                    
                    v.getLocationOnScreen( vLoc );
                    image.getLocationOnScreen( imageLoc );
                    
                    //##################################
                    //
                    // Slide to the target
                    //
                    //##################################
                    //                    image.animate().setStartDelay( image.getTileY() * 100 );
                    image.slideTo( vLoc[ 1 ] - imageLoc[ 1 ], vLoc[ 0 ] - imageLoc[ 0 ], 350 ).addListener( new AnimatorListenerAdapter()
                    {
                        @Override
                        public void onAnimationEnd( Animator animation )
                        {
                            super.onAnimationEnd( animation );
                            
                            if ( GameEngine.isKilled )
                            {
                                return;
                            }
                            
                            image.setVisibility( INVISIBLE );
                            image.setState( BoardTile.STATE_INACTIVE );
                            image.animator = null;
                            image.specialItem = -1;
                            image.specialTile = -1;
                            //
                            image.setTranslationX( 0 );
                            image.setTranslationY( 0 );
                            image.endAnimation();
                            
                            //                Log.d( "Grid Update", "MATCHED: " + image.getPosition() );
                            //
                            if ( logicThread != null )
                            {
                                logicThread.animationsRunning--;
                                
                                if ( logicThread.animationsRunning <= 0 )
                                {
                                    // ALWAYS call DROP / RESPAWN after MATCHES CLEARED complete
                                    //@@@@@@@@@@@@ Tile Matched Sound
                                    if ( gameEngine.soundPlayer != null && !isHelper )
                                    {
                                        gameEngine.soundPlayer.playBgSfx( PlaySound.COIN_MATCH );
                                    }
                                    
                                    //
                                    // Announce merger
                                    //
                                    v.setScaleY( 1.5f );
                                    v.setScaleX( 1.5f );
                                    v.animate().setDuration( 200 );
                                    v.animate().scaleX( 1f ).scaleY( 1f ).setInterpolator( new CustomBounceInterpolator( .2, 20 ) ).start();
                                    
                                    logicThread.animationsRunning = 0;
                                    logicThread.addToStack( LogicThread.CMD_DROP );
                                }
                            }
                        }
                    } );
                }
                else
                {
                    //
                    image.animate().withLayer().setDuration( AnimationValues.DROP_TIME ).scaleY( 0 ).scaleX( 0 );
                    image.animate().setInterpolator( new AnticipateOvershootInterpolator( 1f ) ).withEndAction( new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            if ( GameEngine.isKilled )
                            {
                                return;
                            }
                            
                            image.setScaleX( 1 );
                            image.setScaleY( 1 );
                            //
                            image.setVisibility( INVISIBLE );
                            image.setState( BoardTile.STATE_INACTIVE );
                            image.animator = null;
                            image.specialItem = -1;
                            image.specialTile = -1;
                            image.endAnimation();
                            
                            //                Log.d( "Grid Update", "MATCHED: " + image.getPosition() );
                            //
                            if ( logicThread != null )
                            {
                                logicThread.animationsRunning--;
                                
                                if ( logicThread.animationsRunning <= 0 )
                                {
                                    // ALWAYS call DROP / RESPAWN after MATCHES CLEARED complete
                                    //@@@@@@@@@@@@ Tile Matched Sound
                                    if ( gameEngine.soundPlayer != null && !isHelper )
                                    {
                                        gameEngine.soundPlayer.playBgSfx( PlaySound.COIN_MATCH );
                                    }
                                    
                                    logicThread.animationsRunning = 0;
                                    logicThread.addToStack( LogicThread.CMD_DROP );
                                }
                            }
                        }
                    } ).start();
                }
                
                //##################################
                //
                // Add to the animation counter
                //
                //##################################
                logicThread.animationsRunning++;
                
                if ( !isHelper )
                {
                    // Add to the score
                    runningScore += (GameEngine.POINTS_PER_TILE * GameEngine.pointsMultiplier);
                    
                    // Adjust targets
                    adjustTargetCounts( targets, image.tileNum );
                    matchMade = true;
                }
            }
            else if ( image.getState() == BoardTile.GEM_MATCHED )
            {
                View     v;
                PointXYZ p;
                
                //
                image.animate().setUpdateListener( new ValueAnimator.AnimatorUpdateListener()
                {
                    @Override
                    public void onAnimationUpdate( ValueAnimator animation )
                    {
                        if ( image.animator == null )
                        {
                            image.animator = animation;
                        }
                    }
                } );
                
                // Animate the gem matching
                // Setup the Bomb animation for this tile
                image.setPivotX( image.getWidth() / 2f );
                image.setPivotY( image.getHeight() / 2f );
                
                // This will be replaced with
                // New Gem match animations / particles
/*
                int[] gem_breakers = { 0, 0, 0*/
                /*R.array.red_gem_break, R.array.blue_gem_break, R.array.purple_gem_break, R.array.yellow_gem_break*//*
 };
                int[] resIds       = gameEngine.arrayFromResource( gem_breakers[ image.tileNum - BoardTile.RED_GEM ] );
*/
                
                // ALWAYS call DROP / RESPAWN after MATCHES CLEARED complete
                //@@@@@@@@@@@@ Tile Matched Sound
                if ( gameEngine.soundPlayer != null && !isHelper )
                {
                    gameEngine.soundPlayer.playBgSfx( PlaySound.SPECIAL_MATCHED );
                }
                
                // TODO change this animation for jewels
                ObjectAnimator obj = ObjectAnimator.ofFloat( image, "rotation", 0, 360 );
                
                obj.setDuration( 300 );
                obj.setStartDelay( image.animDelay );
                obj.setInterpolator( new LinearInterpolator() );
                obj.addListener( new AnimatorListenerAdapter()
                {
                    @Override
                    public void onAnimationEnd( Animator animation )
                    {
                        if ( GameEngine.isKilled )
                        {
                            return;
                        }
                        
                        image.setScaleX( 1 );
                        image.setScaleY( 1 );
                        //
                        image.setVisibility( INVISIBLE );
                        image.setState( BoardTile.STATE_INACTIVE );
                        image.animator = null;
                        image.specialItem = -1;
                        image.specialTile = -1;
                        image.endAnimation();
                        image.animDelay = 0;
                        //
                        
                        
                        if ( logicThread != null )
                        {
                            logicThread.animationsRunning--;
                            
                            if ( logicThread.animationsRunning <= 0 )
                            {
                                logicThread.animationsRunning = 0;
                                logicThread.addToStack( LogicThread.CMD_DROP );
                            }
                        }
                        
                        obj.removeAllListeners();
                        
                        super.onAnimationEnd( animation );
                    }
                } );
                
                obj.start();
                
                //##################################
                //
                // Add to the animation counter
                //
                //##################################
                logicThread.animationsRunning++;
                
                if ( !isHelper )
                {
                    // Add to the score
                    runningScore += (GameEngine.POINTS_PER_GEM * GameEngine.pointsMultiplier);
                    
                    // Adjust targets
                    adjustTargetCounts( targets, image.tileNum );
                    matchMade = true;
                }
            }
            else if ( image.getState() == BoardTile.SPECIAL_ANIMATE )
            {
                if ( image.getTag() != null )
                {
                    animatorHelper( position );
                    
                    if ( !isHelper )
                    {
                        // Add to the score
                        runningScore += (GameEngine.POINTS_PER_TILE * GameEngine.pointsMultiplier);
                        
                        // Adjust targets
                        adjustTargetCounts( targets, image.tileNum );
                        matchMade = true;
                    }
                }
            }
            // Blank image requested
            else if ( image.getState() == BoardTile.STATE_INACTIVE && image.tileNum == -1 )
            {
                image.setImageResource( 0 );
                image.setBackgroundResource( 0 );
                image.specialItem = -1;
                image.specialTile = -1;
            }
            
            //
            // Now add the image to the GridLayout
            //
            if ( position == 0 )
            {
                image.requestLayout();
            }
        }
        
        // Update score and make sounds!
        if ( runningScore > 0 && onGridUpdateListener != null && !isHelper )
        {
            GameEngine.pointsMultiplier = tilePoints.size();
            
            onGridUpdateListener.onGridUpdated( SCORE_UPDATE, runningScore );
            //            onGridUpdateListener.onGridUpdated( BONUS_SPLASH, GameEngine.pointsMultiplier );
            onGridUpdateListener.onGridUpdated( MOVES_UPDATE, boardMoves );
        }
        
        // To use for "target reached" checking
        if ( matchMade && !isHelper )
        {
            adjustTargets( targets );
        }
        //        this.setTag( targets );
    }
    
    
    /**
     * //###############################
     * <p>
     * Help all target adjustments NOT
     * fail due to negative value index
     * <p>
     * //###############################
     *
     * @param targets
     * @param tileNum
     */
    private void adjustTargetCounts( int[] targets, int tileNum )
    {
        if ( tileNum > -1 && tileNum < targets.length )
        {
            targets[ tileNum ]++;
        }
    }
    
    
    /**
     * //###############################
     * <p>
     * Helper for image changing with
     * specials attached
     * <p>
     * //###############################
     *
     * @param position N/A
     */
    public void imageHelper( int position )
    {
        BoardTile image = boardTiles.get( position );
        int       padding;
        
        if ( image.tileNum < 0 )
        {
            // Tends to happen after a level is completed, but
            // the game is still matching tiles
            return;
        }
        
        
        //
        // Items with extra BG effect start them NOW
        image.setBackgroundResource( 0 );
        //        padding = context.getResources().getDimensionPixelSize( R.dimen._1sdp );
        //        image.setPadding( padding, padding, padding, padding );
        
        //
        if ( image.specialItem > 0 )
        {
            //            if ( image.tileNum == BoardTile.CLOCK && image.specialTile != -1 )
            if ( image.specialTile != -1 )
            {
                image.setBackgroundResource( (coinBg[ image.tileNum ] > 0) ? coinSet[ image.specialTile ] : 0 );
                //                image.setImageLayers( coinSet[ image.specialTile ][ 0 ], R.drawable.clock_face,)
            }
        }
        
        // Standard tiles
        image.setImageResource( coinSet[ image.tileNum % coinSet.length ] );
    }
    
    
    /**
     * //###############################
     * <p>
     * <p>
     * Helper for special animator calls
     * <p>
     * //###############################
     */
    public void animatorHelper( int position )
    {
        final BoardTile image = boardTiles.get( position );
        
        // Special case animation that is different from the child animations
        //      Star: Star rotates 360 a few times them shoots off other stars
        //      Bomb: Expand then explode
        //      Bolt: Lighting Vertically or Horizontally
        //      Spark: Branching bolt, affected coins jump and spin
        //      Question Mark: Either of the above...Randomly
        if ( image.getTag() instanceof ObjectAnimator[] )
        {
            // Can hold array of animations
            ObjectAnimator[] bg = ( ObjectAnimator[] ) image.getTag();
            
            //
            for ( int i = 0; i < bg.length; i++ )
            {
                if ( bg[ i ] != null )
                {
                    //                    gameEngine.animatorList.add( bg[ i ] );
                    if ( bg[ i ].getListeners() == null )
                    {
                        final ObjectAnimator obj = bg[ i ];
                        
                        bg[ i ].addListener( new Animator.AnimatorListener()
                        {
                            @Override
                            public void onAnimationStart( Animator animation )
                            {
/*
                                // Stored sound
                                if ( image.getSoundEfx() != -1 )
                                {
                                    gameEngine.soundPlayer.play( image.getSoundEfx() );
                                }
                                else
                                {
                                    //
                                    gameEngine.soundPlayer.play( PlaySound.SPECIAL_MATCHED );
                                }
                                //
                                image.setSoundEfx( -1 );
*/
                            }
                            
                            @Override
                            public void onAnimationEnd( Animator animation )
                            {
                                if ( GameEngine.isKilled )
                                {
                                    return;
                                }
                                
                                // Only play the sound once!
                                if ( logicThread != null && logicThread.animationsRunning > 1 )
                                {
                                    image.setSoundEfx( -1 );
                                }
                                
                                if ( logicThread != null )
                                {
                                    logicThread.animationsRunning--;
                                }
                                
                                if ( obj != null )
                                {
                                    gameEngine.animatorList.remove( obj );
                                }
                                
                                image.setScaleY( 1 );
                                image.setScaleX( 1 );
                                image.setRotation( 0 );
                                image.setVisibility( INVISIBLE );
                                image.setState( BoardTile.STATE_INACTIVE );
                                //
                                image.clearAnimation();
                                image.setTag( null );
                                image.animator = null;
                                image.specialItem = -1;
                                image.specialTile = -1;
                                
                                // Undo caught status
                                image.isCaught = false;
                                
                                //
                                if ( logicThread != null && logicThread.animationsRunning <= 0 )
                                {   // ALWAYS call DROP / RESPAWN after MATCHES CLEARED complete
                                    // Stored sound
                                    if ( image.getSoundEfx() != -1 )
                                    {
                                        if ( gameEngine.soundPlayer != null && !inHelper )
                                        {
                                            gameEngine.soundPlayer.playBgSfx( image.getSoundEfx() );
                                        }
                                    }
/*
                                    else
                                    {
                                        //
                                        gameEngine.soundPlayer.playBgSfx( PlaySound.SPECIAL_MATCHED );
                                    }
*/
                                    //
                                    logicThread.animationsRunning = 0;
                                    logicThread.addToStack( LogicThread.CMD_DROP );
                                }
                            }
                            
                            @Override
                            public void onAnimationCancel( Animator animation )
                            {
                            
                            }
                            
                            @Override
                            public void onAnimationRepeat( Animator animation )
                            {
                            
                            }
                        } );
                        
                        // Inform thread that we are animating
                        logicThread.animationsRunning++;
                        
                        // Enable pausing
                        gameEngine.animatorList.add( bg[ i ] );
                    }
                    
                    bg[ i ].start();
                }
                else
                {
                    bg[ i ] = null;
                }
            }
            //
            image.setTag( null );
        }
        else
        {
            // Single ObjectAnimator call
            final ObjectAnimator bg = ( ObjectAnimator ) image.getTag();
            
            //
            if ( bg.getListeners() == null )
            {
                bg.addListener( new Animator.AnimatorListener()
                {
                    @Override
                    public void onAnimationStart( Animator animation )
                    {
/*
                        // Stored sound
                        if ( image.getSoundEfx() != -1 )
                        {
                            gameEngine.soundPlayer.play( image.getSoundEfx() );
                        }
                        else
                        {
                            gameEngine.soundPlayer.play( PlaySound.SPECIAL_MATCHED );
                        }
                        //
                        image.setSoundEfx( -1 );
*/
                    }
                    
                    @Override
                    public void onAnimationEnd( Animator animation )
                    {
                        if ( GameEngine.isKilled )
                        {
                            return;
                        }
                        
                        // Only play the sound once!
                        if ( logicThread.animationsRunning > 1 )
                        {
                            image.setSoundEfx( -1 );
                        }
                        //
                        logicThread.animationsRunning--;
                        
                        gameEngine.animatorList.remove( bg );
                        
                        //
                        image.setScaleY( 1 );
                        image.setScaleX( 1 );
                        image.setRotation( 0 );
                        image.setVisibility( INVISIBLE );
                        image.setState( BoardTile.STATE_INACTIVE );
                        //
                        image.clearAnimation();
                        image.setTag( null );
                        image.animator = null;
                        image.specialItem = -1;
                        image.specialTile = -1;
                        // Undo caught status
                        image.isCaught = false;
                        //
                        if ( logicThread.animationsRunning <= 0 )
                        {   // ALWAYS call DROP / RESPAWN after MATCHES CLEARED complete
                            // Stored sound
                            if ( image.getSoundEfx() != -1 )
                            {
                                if ( gameEngine.soundPlayer != null && !inHelper )
                                {
                                    gameEngine.soundPlayer.playBgSfx( image.getSoundEfx() );
                                }
                            }
/*
                            else
                            {
                                gameEngine.soundPlayer.playBgSfx( PlaySound.SPECIAL_MATCHED );
                            }
*/
                            //
                            image.setSoundEfx( -1 );
                            //
                            logicThread.animationsRunning = 0;
                            logicThread.addToStack( LogicThread.CMD_DROP );
                        }
                    }
                    
                    @Override
                    public void onAnimationCancel( Animator animation )
                    {
                    
                    }
                    
                    @Override
                    public void onAnimationRepeat( Animator animation )
                    {
                    
                    }
                } );
                
                // Inform thread that we are animating
                logicThread.animationsRunning++;
            }
            
            bg.start();
            gameEngine.animatorList.add( bg );
            image.setTag( null );
        }
    }
    
    
    /**
     * //###############################
     * <p>
     * Communication between the thread
     * and this allows for a hint system
     * when the player is IDLE / stuck
     * <p>
     * //###############################
     */
    public void showHint()
    {
/*
        if ( (GameEngine.systemFlags & GameEngine.HINT_OFF) == GameEngine.HINT_OFF || inHelper )
        {
            logicThread.setHintTimer( CustomTimer.currentTime );
            return;
        }
        
        //
        if ( !GameEngine.isKilled && hintTile != null && tilePoints.size() == 0 )
        {
            final SecureRandom          r           = new SecureRandom();
            final ImageView[]           hintPointer = new ImageView[ 4 ];
            final ConnectionsGridLayout grid        = mainView.findViewById( R.id.boardGridLayout );
            final ConstraintLayout      layout      = mainView.findViewById( R.id.boardSpecials );
            int                         padding     = -layout.getPaddingTop();
            
            
            if ( hintTile.x >= 0 && hintTile.y == -1 )
            {
                // Display arrows for matches or specials under a hint
                BoardTile tile = boardTiles.get( hintTile.x );
                
                float hBias      = ( float ) tile.getPosition();
                float vBias      = hBias;
                int   size       = getResources().getDimensionPixelSize( R.dimen.TILE_SIZE );
                float moveAmount = (size / 4f);
                int   adjust;
                
                vBias = ( int ) (vBias / grid.mapHeight);
                hBias = ( int ) (hBias % grid.mapWidth);
                
                hBias /= (grid.mapWidth - 1);
                vBias /= (grid.mapHeight - 1);
                
                
                for ( int i = 0; i < 4; i++ )
                {
                    ObjectAnimator mover;
                    hintPointer[ i ] = new ImageView( getContext() );
                    hintPointer[ i ].setPivotY( size / 2f );
                    hintPointer[ i ].setPivotX( size / 2f );
                    hintPointer[ i ].setId( 3000 + i );
                    hintPointer[ i ].setVisibility( VISIBLE );
                    hintPointer[ i ].setBackgroundResource( R.drawable.hint_arrow );
                    
                    //
                    hintPointer[ i ].setLayoutParams( new ConstraintLayout.LayoutParams( size, size ) );
                    ConnectionsFragment.makeConnection( hintPointer[ i ], layout, vBias, hBias );
                    
                    //
                    switch ( i )
                    {   // Right
                        case 1:
                            hintPointer[ i ].setRotation( 90 );
                            hintPointer[ i ].setTranslationX( size );
                            hintPointer[ i ].setTranslationY( padding );
                            //
                            mover = ObjectAnimator.ofFloat( hintPointer[ i ], "translationX", size, size - moveAmount, size, size - moveAmount );
                            break;
                        // Down
                        case 2:
                            adjust = size + padding;
                            
                            hintPointer[ i ].setRotation( 180 );
                            hintPointer[ i ].setTranslationX( 0 );
                            hintPointer[ i ].setTranslationY( adjust );
                            //
                            mover = ObjectAnimator.ofFloat( hintPointer[ i ], "translationY", adjust, adjust - moveAmount, adjust, adjust - moveAmount );
                            break;
                        // Left
                        case 3:
                            hintPointer[ i ].setRotation( -90 );
                            hintPointer[ i ].setTranslationX( -size );
                            hintPointer[ i ].setTranslationY( padding );
                            //
                            mover = ObjectAnimator.ofFloat( hintPointer[ i ], "translationX", -size, -size + moveAmount, -size, -size + moveAmount );
                            break;
                        // Up
                        case 0:
                        default:
                            adjust = -size + padding;
                            
                            hintPointer[ i ].setRotation( 0 );
                            hintPointer[ i ].setTranslationX( 0 );
                            hintPointer[ i ].setTranslationY( size );
                            //
                            mover = ObjectAnimator.ofFloat( hintPointer[ i ], "translationY", adjust, adjust + moveAmount, adjust, adjust + moveAmount );
                            break;
                    }
                    
                    final int index = i;
                    mover.setDuration( 1000 ).setRepeatMode( ValueAnimator.REVERSE );
                    //                mover.setRepeatCount( 2 );
                    mover.addListener( new AnimatorListenerAdapter()
                    {
                        @Override
                        public void onAnimationEnd( Animator animation )
                        {
                            super.onAnimationEnd( animation );
                            layout.removeView( hintPointer[ index ] );
                            hintPointer[ index ].setTranslationX( 0 );
                            hintPointer[ index ].setTranslationY( 0 );
                            if ( index == 3 )
                            {
                                logicThread.setHintTimer( CustomTimer.currentTime );
                            }
                        }
                    } );
                    mover.start();
                }
            }
            else if ( hintTile.y == -2 && hintTile.x == -2 )
            {
                //##################################
                //
                // Check the specials
                //
                //##################################
                ViewGroup group = mainView.findViewById( R.id.specialParent );
                int       count = group.getChildCount();
                
                for ( int i = 0; i < count; i++ )
                {
                    View v = group.getChildAt( i );
                    
                    if ( v instanceof ImageTextView )
                    {
                        //                        int items = Integer.valueOf( v.getTag().toString() );
                        
                        if ( gameEngine.Boosters[ i ] <= 0 )
                        {
                            continue;
                        }
                        
                        // Use a shuffle / Random, fool!
                        ObjectAnimator mover;
                        mover = ObjectAnimator.ofFloat( v, "translationX", 0, 6, -6, 6, -6, 3.5f, -3.5f, 1.5f, -1.5f, 0 );
                        mover.setDuration( 1000 ).setRepeatMode( ValueAnimator.REVERSE );
                        mover.setInterpolator( new AccelerateInterpolator() );
                        mover.addListener( new AnimatorListenerAdapter()
                        {
                            @Override
                            public void onAnimationEnd( Animator animation )
                            {
                                super.onAnimationEnd( animation );
                                logicThread.setHintTimer( CustomTimer.currentTime );
                            }
                        } );
                        //
                        mover.start();
                        
                        // Can leave now
                        break;
                    }
                }
            }
        }
*/
    }
    
    
    /**
     * ########################################
     * <p>
     * Swiping
     * <p>
     * ########################################
     *
     * @param v     N/A
     * @param event N/A
     *
     * @return N/A
     */
    @Override
    public boolean onTouch( View v, MotionEvent event )
    {
        int       x        = ( int ) event.getX() / size;
        int       y        = ( int ) event.getY() / size;
        int       position = (y * getColumnCount() + x);
        BoardTile tile;
        //        final ColorMatrix            colorMatrix = new ColorMatrix( cMatrix );
        //        final ColorMatrixColorFilter cmcf        = new ColorMatrixColorFilter( colorMatrix );
        
        PointXYZ start    = new PointXYZ();
        PointXYZ end      = new PointXYZ();
        boolean  canMatch = false;
        
        
        //
        // Exit until We can touch again
        // Don't even bother if in helper mode
        //
        if ( inHelper || !canTouch )
        
        {
            return false;
        }
        
        
        //####################################
        //
        //
        //
        //####################################
        if ( event.getActionMasked() == MotionEvent.ACTION_UP )
        
        {
            // Only cases where we can match coins
            if ( tilePoints.size() > 2 || (tilePoints.size() == 2 && matchColor > BoardTile.MAX_COINS) )
            {
                canMatch = true;
            }
            
            //
            // Create the match list
            //
            for ( int i = 0; i < tilePoints.size(); i++ )
            {
                BoardTile t = boardTiles.get( tilePoints.get( i ) );
                
                if ( canMatch )
                {
                    matchList[ t.getTileY() ][ t.getTileX() ] = 0;
                }
            }
            
            
            //#################################
            //
            // Reset coins to normal state
            //
            //#################################
            for ( BoardTile t : boardTiles )
            {
                //                t.clearColorFilter();
                t.pointPosi = -1;
                
                // Show the proper image
                if ( t.tileNum > -1 )
                {
                    t.resetCoin();
                    //                    t.setImageResource( coinSet[ t.tileNum ] );
                }
            }
            
            
            //#################################
            //
            // Any matches?
            //
            //#################################
            if ( canMatch )
            {
                boardMoves++;
                
                // If we have a special, create it!
                if ( tilePoints.size() >= MIN_FOR_SPECIAL )
                {
                    if ( (CustomTimer.currentTime / 1000) > 45 && tilePoints.size() == MIN_FOR_SPECIAL )
                    {
                        // Clock isn't enabled yet
                        logicThread.addToStack( LogicThread.CMD_PROCESS_MATCHES );
                    }
                    else
                    {
                        // Add to the correct booster's meter for creation
/*
                        int index = Math.min( (tilePoints.size() - MIN_FOR_SPECIAL), (MAX_FOR_SPECIAL - MIN_FOR_SPECIAL) );
//                        int type  = handleSpecialAllow( index );
                        
                        if ( type == 0 )
                        {
                            logicThread.addToStack( LogicThread.CMD_CREATE_SPECIALS );
                        }
                        else if ( type == 1 )
                        {
                            // Give to the player
                            logicThread.addToStack( LogicThread.CMD_GIVE_SPECIAL );
                        }
                        else
*/
                        {
                            // Do not create
                            logicThread.addToStack( LogicThread.CMD_PROCESS_MATCHES );
                        }
                    }
                }
                else
                {
                    logicThread.addToStack( LogicThread.CMD_PROCESS_MATCHES );
                }
                
                //
                canTouch = false;
            }
            else
            {
                tilePoints.clear();
            }
            
/*
            // Hide the coin counter bubble
            matchHintLayout.setVisibility( INVISIBLE );
            //            matchHintIcon.setVisibility( GONE );
            matchHintIcon.setImageResource( 0 );
*/
            
            // Erase the lines
            lineBuffer.eraseColor( Color.TRANSPARENT );
            invalidate();
            
            return false;
        }
        
        
        //###################################
        //
        // We do not allow touches out
        // of bounds
        //
        //###################################
        if ( position < 0 || position >= boardTiles.size() )
        
        {
            return true;
        }
        
        
        //####################################
        //
        // Player setting a booster??
        //
        //####################################
        if ( boosterItem != -1 )
        
        {
            // Do not touch outside of the grid
            // Must be a valid tile
            tile = boardTiles.get( position );
            
            if ( tile.tileNum < 0 || tile.specialItem == 3 )
            {
                if ( gameEngine.soundPlayer != null )
                {
                    //@@@@@@@@@@@@@@@@@@@@
                    gameEngine.soundPlayer.play( PlaySound.INVALID );
                }
                
                return false;
            }
            
            // Reset it
            boosterItem = -1;
            
            // We have a good one
            onBoosterListener.boosterLocationSet( position );
            
            return false;
        }
        
        
        //
        // Valid tile to test against
        //
        tile = boardTiles.get( position );
        
        if ( tile.tileNum < 0 )
        
        {
            return false;
        }
        
        //##################################
        //
        // Make sure this is valid
        //
        //##################################
        if ( tilePoints.size() > 0 )
        
        {
            // We have this selected already and we wish
            // to remove the tile after this one from the list
            if ( tile.pointPosi != -1 && tile.pointPosi == tilePoints.size() - 2 )
            {
                // Tile to remove
                int       index = tilePoints.get( tilePoints.size() - 1 );
                BoardTile tile2;
                
                // Reset state info
                tile = boardTiles.get( index );
                tile.pointPosi = -1;
                //                tile.setImageResource( coinSet[ tile.tileNum] );
                tile.resetCoin();
                
                
                // Remove the line from the screen
                // Get the line we wish to erase
                tile = boardTiles.get( tilePoints.get( tilePoints.size() - 2 ) );
                start.y = (tile.getTileY() * size) + (size / DIV_NUM);
                start.x = (tile.getTileX() * size) + (size / DIV_NUM);
                
                // Do we show the Specials?
                //                handleSpecialDisplay( tilePoints.size() - 1, tile );
                
                //
                tile2 = boardTiles.get( tilePoints.get( tilePoints.size() - 1 ) );
                end.y = (tile2.getTileY() * size) + (size / DIV_NUM);
                end.x = (tile2.getTileX() * size) + (size / DIV_NUM);
                
                // Set paint to draw transparent line
                Xfermode mode = subPaint.getXfermode();
                subPaint.setXfermode( new PorterDuffXfermode( PorterDuff.Mode.CLEAR ) );
                
                // clear the line
                bufCanvas.drawLine( start.x, start.y, end.x, end.y, subPaint );
                
                // Restore normal drawing
                subPaint.setXfermode( mode );
                
                //
                // Remove it
                //
                tilePoints.remove( tilePoints.size() - 1 );
                
                return false;
            }
            
            // Is this already in the list??
            if ( tile.pointPosi != -1 )
            {
                return false;
            }
        }
        
        
        //####################################
        //
        //
        //
        //####################################
        if ( event.getActionMasked() == MotionEvent.ACTION_DOWN )
        
        {
            // Specials or standard icons
            matchColor = boardTiles.get( position ).tileNum;
            
            // Set Pressed state
            if ( matchColor >= BoardTile.MAX_COINS )
            {
                // Keep the name of the special displayed
                //                matchHintText.setText( itemNames[ matchColor ] );
                
                // Specials sound
                if ( gameEngine.soundPlayer != null )
                {
                    gameEngine.soundPlayer.play( PlaySound.SPECIAL_TOUCH );
                }
            }
            else
            {
                // Coin sound
                if ( gameEngine.soundPlayer != null )
                {
                    gameEngine.soundPlayer.play( PlaySound.COIN );
                }
            }
            
            
            //#################################
            //
            // Dim all coins now. Leave like
            // coins as is. IE: Matching red
            // coins only!
            //
            //#################################
/*
            for ( BoardTile t : boardTiles )
            {
                if ( t.getState() != BoardTile.STATE_INACTIVE )
                {
                    if ( t.tileNum != tile.tileNum )
                    {
                        t.setColorFilter( cmcf );
                    }
                }
            }
*/
            
            // Main selected coin
            //            tile.clearColorFilter();
            tile.setImageResource( coinGlow[ tile.tileNum ] );
            tile.growCoin();
            // First in the list
            tile.pointPosi = 0;
            // Add to list for lines
            tilePoints.add( tile.getPosition() );
            
            return true;
        }
        //####################################
        //
        //
        //
        //####################################
        else if ( event.getActionMasked() == MotionEvent.ACTION_MOVE )
        
        {
            int     test_value;
            boolean isValid   = false;
            int     last_posi = tilePoints.get( tilePoints.size() - 1 );
            
            //
            // Can only be 4 values!
            //
            test_value = Math.abs( last_posi - position );
            
            // Is this  avalid tile selection?
            if ( (test_value == 1 || test_value == 7 || test_value == 6 || test_value == 8) && tile.tileNum == matchColor )
            {
                isValid = true;
            }
            
            
            //################################
            //
            // We have a match!
            //
            //################################
            if ( isValid && !tilePoints.contains( position ) )
            {
                // Next up in the list
                tile.pointPosi = tilePoints.size();
                
                // Add to the buffer
                tilePoints.add( tile.getPosition() );
                
                
                if ( tilePoints.size() > 1 )
                {
                    // Do we show the Specials?
                    //handleSpecialDisplay( tilePoints.size(), tile );
                    
                    // Remove the line from the screen
                    // Get the line we wish to erase
                    tile = boardTiles.get( tilePoints.get( tilePoints.size() - 2 ) );
                    start.y = (tile.getTileY() * size) + (size / DIV_NUM);
                    start.x = (tile.getTileX() * size) + (size / DIV_NUM);
                    
                    //
                    tile = boardTiles.get( tilePoints.get( tilePoints.size() - 1 ) );
                    end.y = (tile.getTileY() * size) + (size / DIV_NUM);
                    end.x = (tile.getTileX() * size) + (size / DIV_NUM);
                    
                    //
/*
                    subPaint.setColor( 0x7F000000 );
                    bufCanvas.drawLine( start.x, start.y, end.x, end.y, subPaint );
*/
                    
                    paint.setColor( glowColors[ tile.tileNum % glowColors.length ] );
                    //                    paint.setMaskFilter( new BlurMaskFilter( 1, BlurMaskFilter.Blur.SOLID ) );
                    bufCanvas.drawLine( start.x, start.y, end.x, end.y, paint );
                    
                    // Show the lines
                    invalidate();
                }
                
                // Play SFX
                if ( gameEngine.soundPlayer != null )
                {
                    gameEngine.soundPlayer.play( PlaySound.COIN );
                }
                
                // Un-Dim it
                tile.setImageResource( coinGlow[ tile.tileNum ] );
                tile.growCoin();
                
                //                tile.clearColorFilter();
                
                return true;
            }
        }
        
        return false;
    }
    
    
    /**
     * //######################################
     * <p>
     * Place a booster where the player wants
     * <p>
     * //######################################
     *
     * @param onBoosterLitener
     * @param boosterItem
     */
    public void setBoosterListener( OnBoosterListener onBoosterLitener, int boosterItem )
    {
        this.onBoosterListener = onBoosterLitener;
        this.boosterItem = boosterItem;
    }
    
    
    /**
     * //#######################################
     * <p>
     * Used to place a gem in the highest spot
     * possible, and with minimum spaces below
     * it to maximum difficulty dropping the gem
     * <p>
     * //#######################################
     *
     * @param gemCount N/A
     */
    public ArrayList<Integer> findGemSlot( int gemCount )
    {
        ArrayList<Integer> list     = new ArrayList<>();
        int                i;
        boolean            invalid;
        int                maxCount = boardTiles.size();
        
        
        //################################
        //
        // MUST be able to drop. It's the
        // only way to break the gems
        //
        //################################
        for ( int c = 0; c < gemCount; c++ )
        {
            i = r.nextInt( boardTiles.size() );
            
            while ( i == -1 || boardTiles.get( i ).tileNum == -1 || boardTiles.get( i ).tileNum >= BoardTile.CLOCK )
            {
                i = r.nextInt( boardTiles.size() );
            }
            
            // Transform the coin into a Gem
            if ( gemCount < 4 )
            {
/*
                int index = r.nextInt( 4 ) + BoardTile.RED_GEM;
                
                while ( list.contains( (index - BoardTile.RED_GEM) + BoardTile.MAX_COINS ) )
                {
                    index = r.nextInt( 4 ) + BoardTile.RED_GEM;
                }
*/
                int index = r.nextInt( 4 );
                
                while ( list.contains( index ) )
                {
                    index = r.nextInt( 4 );
                }
                
                //
                boardTiles.get( i ).tileNum = index + BoardTile.RED_GEM;
                list.add( index );
            }
            else
            {
                boardTiles.get( i ).tileNum = BoardTile.RED_GEM + c;
                //                list.add( BoardTile.MAX_COINS + c );
                list.add( c );
            }
            
            boardTiles.get( i ).specialItem = 3;
            boardTiles.get( i ).specialTile = -1;
            
            PointXYZ p = new PointXYZ( 1, 0 );
            boardTiles.get( i ).setTag( p );
        }
        
        return list;
    }
    
    
    /**
     * //##############################
     * <p>
     * Used for help system
     * <p>
     * //##############################
     */
    public void drawBufferLineHelper( int size )
    {
        PointXYZ  start = new PointXYZ();
        PointXYZ  end   = new PointXYZ();
        BoardTile tile;
        
        
        for ( int i = 0; i < (tilePoints.size() - 1); i++ )
        {
            tile = boardTiles.get( tilePoints.get( i ) );
            start.y = (tile.getTileY() * size) + (size / DIV_NUM);
            start.x = (tile.getTileX() * size) + (size / DIV_NUM);
            
            //
            tile = boardTiles.get( tilePoints.get( i + 1 ) );
            end.y = (tile.getTileY() * size) + (size / DIV_NUM);
            end.x = (tile.getTileX() * size) + (size / DIV_NUM);
            
            //
            bufCanvas.drawLine( start.x, start.y, end.x, end.y, subPaint );
            bufCanvas.drawLine( start.x, start.y, end.x, end.y, paint );
        }
    }
    
    
    /**
     * //###############################
     * <p>
     * Get the direction of the swipe
     * <p>
     * //###############################
     *
     * @param pressed
     * @param next
     *
     * @return
     */
    private int getDirection( PointXYZ pressed, PointXYZ next )
    {
        return pressed.z - next.z;
    }
    
    
    /**
     * ########################################
     * <p>
     * Return the position of a board tile
     * coordinates are NOT centered-- Left and
     * Top
     * <p>
     * ########################################
     *
     * @param toView N/A
     *
     * @return N/A
     */
    public int[] getTileXY( View toView )
    {
        // Move to the new location
        //        ConstraintLayout parent = mainView.findViewById( R.id.boardSpecials );
        float hBias = ( float ) toView.getId();
        float vBias = hBias;
        int[] xy    = { 0, 0 };
        int   size  = toView.getWidth();
        
        vBias = ( int ) (vBias / mapHeight);
        hBias = ( int ) (hBias % mapWidth);
        
        xy[ 0 ] = ( int ) (hBias * size);// + (size / 2);
        //        xy[ 1 ] = ( int ) (vBias * size) + parent.getPaddingTop();
        
        return xy;
    }
    
    
    /**
     * ########################################
     * <p>
     * Process move calls for the cursor
     * <p>
     * ########################################
     *
     * @param cursor   N/A
     * @param moveView N/A
     */
    private void moveTheCursor( View view, final View cursor, boolean moveView )
    {
/*
        ConstraintLayout screen           = mainView.findViewById( R.id.game_container );
        ConstraintLayout constraintLayout = mainView.findViewById( R.id.boardGridFrame );
        float            center           = (view.getWidth() / 2f) - (cursor.getWidth() / 2f);
        
        // Move to the new location
        if ( moveView )
        {
            cursor.animate().x( view.getX() + center );
            cursor.animate().y( (constraintLayout.getPaddingTop() / 1f) + view.getY() - cursor.getHeight() );
            cursor.animate().setDuration( 25 ).setInterpolator( new LinearInterpolator() );
            cursor.animate().start();
        }
        else
        {
            cursor.setX( view.getX() + center );
            cursor.setY( (constraintLayout.getPaddingTop() / 1f) + view.getY() - cursor.getHeight() );
            cursor.requestLayout();
            //            cursor.invalidate();
        }
*/
    }
    
    
    //########################################
    //
    // Match making methods: User initiated
    //
    //########################################
    
    /**
     * ########################################
     * <p>
     * Solve any matches
     * This is where most of the magic happens
     * <p>
     * ########################################
     */
    public void signalMatchesFound()
    {
        BoardTile tile;
        
        //###########################################
        //
        // Matches found
        //
        //###########################################
        for ( int i = 0; i < boardTiles.size(); i++ )
        {
            tile = boardTiles.get( i );
            
            // Cancel any spinning, etc
            tile.endAnimation();
            
            
            // Did we match a special tile?
            // If a special tile is found, then itwas matched and takes
            // priority over all other forms of match solving!
            // method 'SWAP' placed it in STATE_ACTIVE
            if ( matchList[ tile.getTileY() ][ tile.getTileX() ] == 0 && tile.specialItem > 1 )
            {
                // Clear all previous finds for all specials over CLOCK only!
                GameEngine.arrayCopy( boardMap, matchList, mapHeight, mapWidth );
                
                // Just leave, forget the other tiles
                tile.setState( BoardTile.USE_SPECIAL_ITEM );
                
                // Allow for other matches that might solve more tiles
                // to process
                return;
            }
        }
        
        
        //###############################
        //
        // Normal matches
        //
        //###############################
        for ( int i = 0; i < tilePoints.size(); i++ )
        {
            tile = boardTiles.get( tilePoints.get( i ) );
            
            // Did we match a special tile?
            // ONLY test here for a CLOCK
            if ( tile.tileNum >= BoardTile.CLOCK && tile.getState() == BoardTile.STATE_ACTIVE )
            {
                tile.setState( BoardTile.USE_SPECIAL_ITEM );
            }
            else if ( tile.getState() != BoardTile.CREATE_ITEM && tile.getState() != BoardTile.MASTER_ITEM && tile.getState() != BoardTile.SPECIAL_ANIMATE )
            {
                tile.setState( BoardTile.STATE_MATCHED );
            }
        }
        
        //
        // Check for Gems
        //
        for ( int i = 0; i < gemsToMatch.size(); i++ )
        {
            // Get the Gem
            tile = boardTiles.get( gemsToMatch.get( i ) );
            
            int x = tile.getTileX();
            int y = tile.getTileY();
            // U, UR, R, DR, D, DL, L, UL
            int[][] dirc = {
                    { 0, -1 },  // U
                    //                    { 1, -1 },  // UR
                    { 1, 0 },   // R
                    //                    { 1, 1 },   // DR
                    { 0, 1 },   // D
                    //                    { -1, 1 },  // DL
                    { -1, 0 },  // L
                    //                    { -1, -1 }, // UL
            };
            
            // Did we match a special tile?
            // ONLY test here for a CLOCK
            for ( int d = 0; d < dirc.length; d++ )
            {
                int xx = x + dirc[ d ][ 0 ];
                int yy = y + dirc[ d ][ 1 ];
                
                if ( tile.getState() != BoardTile.GEM_MATCHED && xx > -1 && xx < mapWidth && yy > -1 && yy < mapHeight )
                {
                    BoardTile test = boardTiles.get( yy * mapWidth + xx );
                    
                    if ( test.getState() == BoardTile.STATE_MATCHED )
                    {
                        tile.setState( BoardTile.GEM_MATCHED );
                        break;
                    }
                }
            }
        }
    }
    
    
    /**
     * ########################################
     * <p>
     * After all tiles have disappeared,
     * handle dropping old tiles
     * handle re-spawning tiles with no
     * replacements
     * <p>
     * ########################################
     */
    public void signalDroppingTiles()
    {
        int       index     = 0;
        int       delayTime = 0;
        int       baseY     = -1;
        BoardTile image;
        
        
        // Scan from bottom up
        for ( int x = (mapWidth - 1); x > -1; x-- )
        {
            delayTime = 0;
            
            for ( int y = (mapHeight - 1); y > -1; y-- )
            {
                index = (y * mapWidth) + x;
                image = boardTiles.get( index );
                //
                if ( image.getState() == BoardTile.STATE_INACTIVE && image.tileNum != -1 )
                {
                    checkForReplacement( index, delayTime );
                    
                    // We can start delaying now
                    if ( baseY == -1 )
                    {
                        baseY = y;
                    }
                }
                
                //
                if ( y <= baseY )
                {
                    delayTime = 50;
                }
            }
        }
    }
    
    
    /**
     * ########################################
     * <p>
     * After all tiles have disappeared,
     * handle dropping old tiles
     * handle re-spawning tiles with no
     * replacements
     * <p>
     * ########################################
     */
    public void signalDroppingGems()
    {
/*
        int       index     = 0;
        int       delayTime = 0;
        int       baseY     = -1;
        BoardTile image;
        
        
        // Scan from bottom up
        for ( int x = (mapWidth - 1); x > -1; x-- )
        {
            delayTime = 0;
            
            for ( int y = (mapHeight - 1); y > -1; y-- )
            {
                index = (y * mapWidth) + x;
                image = boardTiles.get( index );
                //
                if ( image.getState() == BoardTile.STATE_INACTIVE && image.tileNum != -1 )
                {
                    checkForReplacement( index, delayTime );
                    
                    // We can start delaying now
                    if ( baseY == -1 )
                    {
                        baseY = y;
                    }
                }
                
                //
                if ( y <= baseY )
                {
                    delayTime = 50;
                }
            }
        }
*/
    }
    
    
    /**
     * ########################################
     * <p>
     * Find the lowest available tile to drop
     * down
     * <p>
     * ########################################
     *
     * @param matchedPosi N/A
     *
     * @return N/A
     */
    private void checkForReplacement( int matchedPosi, int delayTime )
    {
        int       replacedPosi = matchedPosi;
        boolean   valid        = false;
        BoardTile matched;
        BoardTile replaced;
        int       x, y;
        
        //#################################
        //
        // If the tiles are already at the
        // top, then respawn
        //
        //#################################
        if ( (matchedPosi - mapWidth) < 0 )
        {
            // Just needs to respawn. View already
            // invisible and as high as it is going to be
            replaced = boardTiles.get( replacedPosi );
            replaced.setState( BoardTile.STATE_RESPAWN );
            replaced.specialItem = -1;
            replaced.specialTile = -1;
        }
        else
        {
            // Get to the next tile
            replacedPosi -= mapWidth;
            
            while ( replacedPosi > -1 && !valid )
            {
                //
                // Is there a replacement??
                //
                if ( boardTiles.get( replacedPosi ).getState() == BoardTile.STATE_ACTIVE )
                {   // Found a new home
                    replaced = boardTiles.get( replacedPosi ); // Replacement tile
                    matched = boardTiles.get( matchedPosi );  // Matched tile
                    
                    // Go to the same location as replacement tile and take its color
                    // and take its location for now
                    // These are the values to animate from
                    //
                    // Make this old tile drop from
                    // replacement tile's position
                    // Make sure the matched tile is visible
                    matched.setVisibility( VISIBLE );
                    matched.swapTO = new PointXYZ( ( int ) replaced.getX(), ( int ) replaced.getY(), boardTiles.get( replacedPosi ).tileNum );
                    
                    //
                    matched.tileNum = replaced.tileNum;
                    matched.specialItem = replaced.specialItem;
                    matched.specialTile = replaced.specialTile;
                    matched.setState( BoardTile.STATE_DROP );
                    matched.endAnimation();
                    matched.setBackgroundResource( 0 );
                    matched.setImageResource( 0 );
                    //
                    // Certain Objects in Tag need to transfer also
                    matched.setTag( replaced.getTag() );
                    
                    
                    // Make replaced tile require a replacement now
                    replaced.setVisibility( INVISIBLE );
                    // Save replacement's position
                    replaced.setState( BoardTile.STATE_INACTIVE );
                    
                    // Reset immediately for effect that the dropping
                    // tile is now the floating tile
                    // erase this completely to be respawn or to find a replacement
                    //                    replaced.setImageResource( 0 );
                    //                    replaced.setBackgroundResource( 0 );
                    replaced.specialItem = -1;
                    replaced.specialTile = -1;
                    //                    replaced.specialItem = 0;
                    // In case of special animations
                    replaced.endAnimation();
                    replaced.setTag( null );
                    //
                    valid = true;
                }
                
                // Check the next one up
                replacedPosi -= mapWidth;
            }
            
            //
            // No replacement was found
            // Guess it needs to respawn instead
            //
            if ( !valid )
            {
                matched = ( BoardTile ) getChildAt( matchedPosi );
                matched.setState( BoardTile.STATE_RESPAWN );
                matched.specialItem = -1;
                matched.specialTile = -1;
                //                matched.specialItem = 0;
            }
        }
    }
    
    
    /**
     * ########################################
     * <p>
     * Create a special item for the board
     * <p>
     * ########################################
     */
    public BoardTile createSpecialItems()
    {
        BoardTile tile;
        BoardTile master = null;
        int       toX;
        int       toY;
        
        //##################################
        //
        // Determine if we have a special
        // item spawning
        //
        //##################################
        // Depending on the count, MAKE A SPECIAL!!
        int count = 0;
        int index;
        
/*
        
        //#####################################
        //
        // Set the master tile
        //
        //#####################################
        for ( int y = 0; y < tilePoints.size(); y++ )
        {
            tile = boardTiles.get( tilePoints.get( y ).z );
            // Check to see if we matched a SPECIAL tile
            if ( tile.specialItem > 0 )
            {
                continue;
            }
            //
            count++;
        }
        
        // Set the master
        int y = r.nextInt( tilePoints.size() );
        while ( boardTiles.get( tilePoints.get( y ).z ).specialItem == -1 || boardTiles.get( tilePoints.get( y ).z ).specialItem > 0 )
        {
            y = r.nextInt( tilePoints.size() );
        }
        //
        master = boardTiles.get( tilePoints.get( y ).z );
        
        
        //#################################
        //
        // Coins: Bomb, Bolt, Star, Spark,
        // Charge Beam, Question mark,
        // Shuffler
        //
        //#################################
        //        index = (count - 6) + BoardTile.BOMB;
        index = (count - MIN_FOR_SPECIAL) + BoardTile.CLOCK;
        
        if ( index > BoardTile.SHUFFLER )
        {
            index = BoardTile.SHUFFLER;
        }
        
        if ( master != null )
        {
            master.setState( BoardTile.MASTER_ITEM );
            master.specialItem = 2;
            master.specialTile = master.tileNum;
            master.tileNum = index;
            master.swapTO = new PointXYZ( 0, 0, master.tileNum, master.specialItem );
            
            //
            //##################################
            //
            for ( int c = 0; c < tilePoints.size(); c++ )
            {
                tile = boardTiles.get( tilePoints.get( c ).z );
                
                //
                if ( tile.tileNum < 0 )
                {
                    continue;
                }
                else if ( tile.tileNum == BoardTile.CLOCK )
                {
                    if ( !inHelper )
                    {
                        tile.setState( BoardTile.USE_SPECIAL_ITEM );
                    }
                    else
                    {
                        tile.setState( BoardTile.STATE_ACTIVE );
                    }
                    continue;
                }
                
                // Animate all tiles to master tile
                if ( tile.getPosition() != master.getPosition() && tile.specialItem < 1 )
                {
                    matchList[ tile.getTileY() ][ tile.getTileX() ] = 0;
                    //
                    tile.setState( BoardTile.CREATE_ITEM );
                    toX = ( int ) (master.getX() - tile.getX());
                    toY = ( int ) (master.getY() - tile.getY());
                    //
                    tile.swapTO = new PointXYZ( toX, toY, tile.tileNum, master.getPosition() );
                    //                    tile.setPivotX( toX / 2f );
                }
            }
        }
        
        
        //#################################
        //
        // Check for Gems
        //
        //#################################
        for ( int i = 0; i < gemsToMatch.size(); i++ )
        {
            // Get the Gem
            tile = boardTiles.get( gemsToMatch.get( i ) );
            
            int x = tile.getTileX();
            y = tile.getTileY();
            
            // U, UR, R, DR, D, DL, L, UL
            int[][] dirc = {
                    { 0, -1 },  // U
                    //                    { 1, -1 },  // UR
                    { 1, 0 },   // R
                    //                    { 1, 1 },   // DR
                    { 0, 1 },   // D
                    //                    { -1, 1 },  // DL
                    { -1, 0 },  // L
                    //                    { -1, -1 }, // UL
            };
            
            //
            // Did we match a special tile?
            //
            for ( int d = 0; d < dirc.length; d++ )
            {
                int xx = x + dirc[ d ][ 0 ];
                int yy = y + dirc[ d ][ 1 ];
                
                if ( tile.getState() != BoardTile.GEM_MATCHED && xx > -1 && xx < mapWidth && yy > -1 && yy < mapHeight )
                {
                    BoardTile test = boardTiles.get( yy * mapWidth + xx );
                    
                    if ( test.getState() == BoardTile.CREATE_ITEM || test.getState() == BoardTile.MASTER_ITEM )
                    {
                        tile.setState( BoardTile.GEM_MATCHED );
                        break;
                    }
                }
            }
        }
        
*/
        // For use by whatever wants it!
        return master;
    }
    
    
    /**
     * ########################################
     * <p>
     * Create a special item for the board
     * <p>
     * ########################################
     */
    public void createSpecialItemToGive()
    {
        BoardTile master = createSpecialItems();
        
        master.setState( BoardTile.MASTER_ITEM_TO_GIVE );
    }
    
    /**
     * ########################################
     * <p>
     * Check for Display errors, like Tiles not
     * displayed although status is IDLE
     * <p>
     * ########################################
     */
    public void checkForErrors()
    {
        // No more bonus points
        GameEngine.pointsMultiplier = 1;
        
        // Stop Hint system just in case it will trigger before thread reset
        logicThread.setHintTimer( 0 );
        
        // Restore original board mapping
        GameEngine.arrayCopy( boardMap, matchList, mapHeight, mapWidth );
        
        // No specials
        specials.clear();
        
        //
        tilePoints.clear();
        invalidate();
        
        // Refresh screen tiles
        onDrawGrid();
        
        // Fill the hint system
        checkIfMatchesExist( false, true );
        
        // Save the player some time
        if ( timer != null )
        {
            timer.resume();
            if ( (CustomTimer.currentTime / 1000) < timer.savedTime / 1000 )
            {
                timer.updateTime( (timer.savedTime - CustomTimer.currentTime) / 1000f );
            }
        }
        
        // Enabl touching again
        canTouch = true;
    }
    
    
    /**
     * ########################################
     * <p>
     * Check to see if any or all of the
     * targets have been reached. If so, update
     * the player on current status
     * <p>
     * ########################################
     */
    public boolean checkTargetsReached()
    {
        int total_targets = 0;
        
        //
        for ( View view : targetViews )
        {
            final PointXYZ temp = ( PointXYZ ) view.getTag();
            
            if ( view.getVisibility() == VISIBLE && temp.getTag() == null )
            {
                // Get the amounts remaining
                total_targets += temp.x;
            }
        }
        
        // Test for the score reached
        if ( ConnectionsFragment.levelScore < gameBoard.neededPoints )
        {
            total_targets = 1;
        }
        
        return total_targets == 0;
        
    }
    
    
    /**
     * //###############################
     * <p>
     * <p>
     * Adjust target numbers
     * <p>
     * //###############################
     *
     * @param targets
     */
    private void adjustTargets( int[] targets )
    {
        for ( int i = 0; i < targetViews.size(); i++ )
        {
            final ImageTextView view = ( ImageTextView ) targetViews.get( i );
            final PointXYZ      temp = ( PointXYZ ) view.getTag();
            
            if ( temp != null && view.getVisibility() == VISIBLE && temp.getTag() == null )
            {
                if ( targets[ temp.y % targets.length ] > 0 )
                {
                    PropertyValuesHolder sx  = PropertyValuesHolder.ofFloat( "scaleX", 1, 1.5f, 1 );
                    PropertyValuesHolder sy  = PropertyValuesHolder.ofFloat( "scaleY", 1, 1.5f, 1 );
                    ObjectAnimator       obj = ObjectAnimator.ofPropertyValuesHolder( view, sx, sy );
                    //                    final int            number = (temp.x - targets[ i ]) < 0 ? 0 : (temp.x - targets[ i ]);
                    //                    final int number = Math.max( (temp.x - targets[ i ]), 0 );
                    
                    final int number = Math.max( (temp.x - targets[ temp.y ]), 0 );
                    
                    // If target has some thing left, subtract it
                    // But...If the player solves a target with nothing left
                    // penalize them!
                    if ( temp.x > 0 )
                    {
                        temp.x = number;
                        //
                        view.setText( String.format( Locale.getDefault(), "%d", number ) );
                        view.setImageResource( 0 );
                        obj.setDuration( 500 ).setInterpolator( new AnticipateOvershootInterpolator( 1f ) );
                        obj.addListener( new AnimatorListenerAdapter()
                        {
                            @Override
                            public void onAnimationEnd( Animator animation )
                            {
                                super.onAnimationEnd( animation );
                                temp.setTag( null );
                            }
                        } );
                        obj.start();
                        temp.setTag( obj );
                    }
                    else
                    {
                        view.setText( "" );
                        view.setImageResource( R.drawable.white_checkmark );
                    }
/*
                    else if ( GameEngine.penaltyMode )
                    {
                        // Penalized the player for solving a finished target
                        // Possible Adjustment: Last level only!
                        temp.x = 1;
                        //
                        view.setText( String.format( Locale.getDefault(), "%d", temp.x ) );
                        obj.setDuration( 500 ).setInterpolator( new AnticipateOvershootInterpolator( 1f ) );
                        obj.addListener( new AnimatorListenerAdapter()
                        {
                            @Override
                            public void onAnimationEnd( Animator animation )
                            {
                                super.onAnimationEnd( animation );
                                temp.setTag( null );
                            }
                        } );
                        obj.start();
                        temp.setTag( obj );
                    }
*/
                }
            }
        }
    }
    
    
    /**
     * //###############################
     * <p>
     * The level is complete!
     * <p>
     * //###############################
     */
    public void signalLevelComplete()
    {
        if ( mainView != null && !inHelper )
        {
            final View view = mainView.findViewById( R.id.boardGridLayout );
            
            // Kill the TIMER!!!!!!!!!!!!
            if ( timer != null )
            {
                timer.pause();
            }
            
            
            //###############################
            //
            // Clear all tile statuses
            //
            //###############################
            for ( BoardTile tile : boardTiles )
            {
                tile.cardFlipped = false;
                tile.endAnimation();
                tile.setBackgroundColor( 0 );
            }
            
            
            // Clear all lines
            tilePoints.clear();
            lineBuffer.eraseColor( Color.TRANSPARENT );
            invalidate();
            
            
            // Any specials need saving??
            gameEngine.savedSpecials.clear();
            
            // This gets called twice sometimes
            if ( gameEngine.specialRunning )
            {
                gameEngine.specialRunning = false;
                return;
            }
            
            //###################################
            //
            //
            //
            //###################################
            specialMerge = 0;
            levelCompleted = true;
            logicThread.clearData();
            
            // Need this
            gameEngine.specialRunning = true;
            
            
/*
            // Get all the special item views
            for ( int i = 0; i < count; i++ )
            {
                View v = group.getChildAt( i );
                
                if ( v instanceof ImageTextView )
                {
                    imageTextView[ currentView ] = ( ImageTextView ) v;
                    currentView++;
                }
            }
*/
            
            // Only call this if we did not give player
            // back any specials
            onSignalCompleteHelper( view );
        }
    }
    
    
    /**
     * //###############################
     * <p>
     * <p>
     * //###############################
     */
    public void onSignalCompleteHelper( final View view )
    {
        //@@@@@@@@@@@@@@@@@@@@@ Level complete: 2 seconds
        if ( gameEngine.soundPlayer != null )
        {
            gameEngine.soundPlayer.playBgSfx( PlaySound.STAR_SHOOT );
        }
        
        //############################
        //
        // Hide all the targets
        //
        //############################
        for ( int i = 0; i < targetViews.size(); i++ )
        {
            View v = targetViews.get( i );
            
            if ( v.getVisibility() == VISIBLE )
            {
                int width = mainView.getWidth();
                
                v.animate().translationX( width + v.getWidth() ).rotation( 360 ).setDuration( 1000 );
                v.animate().setInterpolator( new AnticipateInterpolator( 1f ) );
                v.animate().withEndAction( new Runnable()
                {
                    @Override
                    public void run()
                    {
                        v.setTranslationX( 0 );
                        v.setVisibility( GONE );
                    }
                } ).start();
            }
            else
            {
                v.setTranslationX( 0 );
            }
        }
        
        
        //############################
        //
        // Hide all the tiles
        //
        //############################
        for ( int i = 0; i < boardTiles.size(); i++ )
        {
            final BoardTile tile = boardTiles.get( i );
            
            if ( tile.tileNum != -1 )
            {
/*
                //
                tile.cancelAnimationAndListeners();
                tile.animate().scaleY( 0 ).scaleX( 0 ).setInterpolator( new AnticipateOvershootInterpolator() );
                tile.animate().setDuration( AnimationValues.DROP_TIME );
                tile.animate().withEndAction( new Runnable()
                {
                    @Override
                    public void run()
                    {
                        tile.setScaleX( 1 );
                        tile.setScaleY( 1 );
                        tile.setBackgroundResource( 0 );
                        tile.setImageResource( 0 );
                        
                        loopPosition--;
                        if ( loopPosition <= 0 )
                        {
                            //
                            mainView.findViewById( R.id.boardGridSlots ).setVisibility( INVISIBLE );
                            
                            //
                            if ( r.nextBoolean() )
                            {
                                view.animate().scaleY( 0 ).setDuration( 750 );
                            }
                            else
                            {
                                view.animate().scaleX( 0 ).setDuration( 750 );
                            }
                            //
                            //#########################
                            //
                            view.animate().withEndAction( new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    onGridUpdateListener.onLevelComplete();
                                }
                            } ).start();
                        }
                    }
                } ).start();
                
                // Only count the row just before the last row so some burst
                // play with the "Level Complete" text
                loopPosition++;
                tile.tileNum = -1;
*/
            }
        }
        
        // TODO: add this back on an animation end IF animating game end again
        if ( onGridUpdateListener != null )
        {
            onGridUpdateListener.onLevelComplete();
        }
    }
    
    
    /**
     * //###############################
     * <p>
     * <p>
     * //###############################
     */
    public void signalLevelFailed()
    {
    }
    
    
    /**
     * ########################################
     * <p>
     * Check to see if any matches remain. Also
     * fills the list for hints. Should be called
     * after board is created and when the board
     * goes IDLE in the thread
     * <p>
     * For hints, specials get the dancing arrows
     * For matches, each tile rocks back and forth
     * <p>
     * ########################################
     */
    public boolean checkIfMatchesExist( boolean isShuffling, boolean useSpecials )
    {
        // Make sure no shuffling during help!
        if ( inHelper )
        {
            return true;
        }
        
        
        // Save the player some time
        if ( timer != null && !timer.isPaused() && !isShuffling )
        {
            timer.pause();
        }
        
        // All checks resets the counter
        logicThread.setHintTimer( CustomTimer.currentTime );
        
        hintTile = null;
        
        //#####################################
        //
        // No specials, keep testing
        //
        //#####################################
        ArrayList<tileGroup> groups = new ArrayList<>();
        
        //
        //        for ( int y = 0; y < maxColors; y++ )
        for ( int y = 0; y < BoardTile.MAX_COINS; y++ )
        {
            groups.add( new tileGroup() );
            groups.get( y ).count = 0;
            groups.get( y ).position = new ArrayList<>();
        }
        
        //####################################
        //
        // Find the coins with counts greater
        // than 3
        //
        //####################################
        int holder;
        //
        for ( BoardTile tile : boardTiles )
        {
            holder = tile.tileNum;
            if ( tile.tileNum == BoardTile.CLOCK )
            {
                // Must use special color for clock
                holder = tile.specialTile;
            }
            //
            if ( holder == -1 || holder > BoardTile.MAX_COINS )
            {
                continue;
            }
            
            // Build a color list for optimal efficiency
            //
            groups.get( holder ).count++;
            groups.get( holder ).tileNum = holder;
            // Add to group pointer list for easier access in testing
            groups.get( holder ).position.add( tile.getPosition() );
        }
        
        // Eliminate any small count tiles
        for ( int i = 0; i < maxColors; i++ )
        {
            if ( groups.get( i ).count < 3 )
            {
                // Not used for testing
                groups.get( i ).tileNum = -1;
                groups.get( i ).count = -1;
            }
        }
        
        // Sort the list according to count. High count first
        // Must create comparator.
        Collections.sort( groups, new Comparator<tileGroup>()
        {
            @Override
            public int compare( tileGroup o1, tileGroup o2 )
            {
                return ( int ) (o2.count - o1.count);
            }
        } );
        
        
        // Search using the list element with the most colors first!
        for ( int i = 0; i < groups.size(); i++ )
        {
            // Testing color
            int color = groups.get( i ).tileNum;
            
            for ( int c = 0; c < groups.get( i ).position.size(); c++ )
            {
                // Test each valid color in this group at their position
                int yPosi = groups.get( i ).position.get( c ) / getRowCount();
                int xPosi = (groups.get( i ).position.get( c ) % getColumnCount());
                
                //################################
                //
                // Recursive loop test
                //
                //################################
                if ( testForMatch( xPosi, yPosi, 1, new int[]{ 0, 0 }, color ) >= 3 )
                {
                    // Set a tile to highlight
                    hintTile = new Point( (yPosi * getRowCount() + xPosi), -1 );
                    break;
                }
            }
            
            // We are done searching
            if ( hintTile != null )
            {
                break;
            }
            
            // Debugging: No more matches
/*
        if ( !noMatchesTrigger  )
        {
            noMatchesTrigger = true;
            onGridUpdateListener.onNoMoreMatches();
            return false;
        }
*/
        }
        
        
        //#################################
        //
        // Test each tile
        //
        // ################################
        if ( hintTile == null )
        {
            for ( BoardTile tile : boardTiles )
            {
                // Test to see if anything is a special
                // If so, just leave, we are good!
                if ( tile.tileNum > BoardTile.CLOCK && tile.specialItem == 2 )
                {
                    hintTile = new Point( tile.getPosition(), -1 );
                }
            }
        }
        
        //
        // Any Held specials?
        //
        if ( hintTile == null && useSpecials )
        {
            for ( int i = 0; i < gameEngine.Boosters.length; i++ )
            {
                if ( gameEngine.Boosters[ i ] > 0 )
                {
                    hintTile = new Point( -2, -2 );
                    break;
                }
            }
        }
        
        
        //###############################
        // All failed!
        // No matches AND no shuffle or
        // random power bomb
        //
        //###############################
        if ( hintTile == null )
        {
            // Board has no matches available, give the player
            // the bad news with possible options
            // Only if more than 15 moves made
            if ( !noMatchesTrigger && !isShuffling && boardMoves > 15 )
            {
                // You get ONE video Ad only!
                noMatchesTrigger = true;
                onGridUpdateListener.onNoMoreMatches();
            }
            else if ( !isShuffling && boardMoves < 16 )
            {
                // Give the player a free shuffle
                // Shuffle the board
                Toast.makeText( getContext(), "Game locked. Reshuffling", Toast.LENGTH_SHORT ).show();
                useShuffler( null );
            }
            
            return false;
        }
        
        //
        // Save the player some time
        //
        if ( timer != null && timer.isPaused() && !isShuffling )
        {
            timer.resume();
        }
        
        
        if ( logicThread != null )
        {
            // Reset hint timer
            logicThread.setHintTimer( CustomTimer.currentTime );
        }
        
        return true;
    }
    
    
    /**
     * //###############################
     * <p>
     * search for potential matches
     * <p>
     * //###############################
     *
     * @return
     */
    private int testForMatch( int startX, int startY, int count, int[] skipDirection, int color )
    {
        // Each direction set is an X, Y offset
        final int[][] moveDirection = {
                { 0, -1 }, // Up
                { -1, -1 }, // Up / Left
                { -1, 0 }, // Left
                { -1, 1 }, // Left / Down
                { 0, 1 }, // Down
                { 1, 1 }, // Right / Down
                { 1, 0 }, //Right
                { 1, -1 }, // Up / Right
        };
        
        //
        int       result = 0;
        BoardTile tile;
        
        
        // Test the current tile in each direction
        // A match count of 2 is all that is needed because
        // the test tile is one already
        for ( int[] moves : moveDirection )
        {
            int x = moves[ 0 ];
            int y = moves[ 1 ];
            
            //
            // Need to skip testing this direction
            //
            if ( skipDirection[ 0 ] == x && skipDirection[ 1 ] == y )
            {
                continue;
            }
            
            // Only valid directions
            if ( (startX + x) < 0 || (startY + y) < 0 || (startX + x) >= getColumnCount() || (startY + y) >= getRowCount() )
            {
                continue;
            }
            
            //
            // Does this tested tile match?
            tile = boardTiles.get( (startY + y) * getColumnCount() + (startX + x) );
            //
            if ( tile.tileNum == color )
            {
                count++;
                
                // Have three matches yet?
                if ( count > 2 )
                {
                    result = 3;
                    break;
                }
                else
                {
                    result = testForMatch( startX + x, startY + y, count, new int[]{ -x, -y }, color );
                    if ( result >= 2 )
                    {
                        result = 3;
                        break;
                    }
                    else
                    {
                        // Keep checking!
                        count--;
                    }
                }
            }
        }
        
        //
        return result;
    }
    
    
    //########################################################################
    //
    // Specials processing formula:
    //      Swap initiates the matching process. Should either of the swapped
    //      tiles be a 'special' tile, match making is canceled and ONLY the
    //      special tile is matched. If two specials are swapped together then
    //      the special with the highest value takes precedence.
    //
    //      Next: USE_SPECIAL_ITEM is called, and if it is NOT a clock, then
    //      handle creating matches inside the SPECIAL_CALL.
    //      If possible, attach an 'AnimateBG' call to the affected BoardTile's
    //      'animator' property and play that animation instead of normal one
    //      if a special exit is requested
    //
    //      Consider adding buttons for special again. Instead of stacking the
    //      board, add duplicates to the players stack for later use.
    //########################################################################
    
    /**
     * ########################################
     * <p>
     * Clock special use method
     * <p>
     * ########################################
     *
     * @param image N/A
     */
    private void useAClock( final BoardTile image )
    {
/*
        // If it is > 45 seconds, don't bother!
*/
/*        if ( (CustomTimer.currentTime / 1000) > 45 )
        {
            return;
        }
        else*//*

        if ( timer != null )
        {   // Add 30 or more seconds!
            timer.pause();
            timer.updateTime( 30f );
            
            final TextView tv           = mainView.findViewById( R.id.boardTimeTextAnimated );
            int[]          xyPosi;
            final int      toX;
            final int      toY;
            int            center       = 0;
            final int      mainDuration = AnimationValues.DROP_TIME;
            
            // Clock tile's grid position
            xyPosi = getTileXY( image );
            
            toX = ( int ) tv.getX();
            toY = ( int ) tv.getY();
            
            // Set it to move
            tv.setX( xyPosi[ 0 ] );
            center = AnimationValues.getCenter( image.getHeight(), (tv.getHeight() / 2) );
            tv.setY( xyPosi[ 1 ] + center );
            tv.setRotation( 0 );
            
            
            //###############################
            //
            //
            //
            //###############################
            ObjectAnimator[]     clock  = new ObjectAnimator[ 3 ];
            PropertyValuesHolder rotate = PropertyValuesHolder.ofFloat( "rotation", 360 );
            PropertyValuesHolder sx     = PropertyValuesHolder.ofFloat( "scaleX", 1f, 0 );
            PropertyValuesHolder sy     = PropertyValuesHolder.ofFloat( "scaleY", 1f, 0 );
            
            clock[ 0 ] = ObjectAnimator.ofPropertyValuesHolder( image, rotate, sx, sy );
            clock[ 0 ].setDuration( mainDuration );
            clock[ 0 ].setInterpolator( new AnticipateOvershootInterpolator( 1f ) );
            
            //
            PropertyValuesHolder px      = PropertyValuesHolder.ofFloat( "x", toX );
            PropertyValuesHolder py      = PropertyValuesHolder.ofFloat( "y", toY );
            PropertyValuesHolder rotate2 = PropertyValuesHolder.ofFloat( "rotation", -720 );
            PropertyValuesHolder color   = PropertyValuesHolder.ofInt( "textColor", 0xFFFFFFFF, 0xFFFF0000 );
            
            // Move the "+30" text, change color
            clock[ 1 ] = ObjectAnimator.ofPropertyValuesHolder( tv, px, py, rotate2, color ).setDuration( mainDuration );
            clock[ 1 ].setInterpolator( new AccelerateInterpolator() );
            clock[ 1 ].setStartDelay( mainDuration );
            clock[ 1 ].addListener( new Animator.AnimatorListener()
            {
                @Override
                public void onAnimationStart( Animator animation )
                {
                    //@@@@@@@@@@@@@@@@@@ Star landing sound
                    if ( gameEngine.soundPlayer != null )
                    {
                        gameEngine.soundPlayer.playBgSfx( PlaySound.STAR_LEVEL_UP );
                    }
                    
                    tv.setTextColor( Color.WHITE );
                    tv.setVisibility( View.VISIBLE );
                    tv.setText( "+30" );
                    // Setup the moving text
                    tv.setPivotX( tv.getWidth() / 2f );
                    tv.setPivotY( tv.getHeight() / 2f );
                    tv.setScaleX( 1 );
                    tv.setScaleY( 1 );
                    tv.setX( toX );
                    tv.setY( toY );
                }
                
                @Override
                public void onAnimationEnd( Animator animation )
                {
                
                }
                
                @Override
                public void onAnimationCancel( Animator animation )
                {
                
                }
                
                @Override
                public void onAnimationRepeat( Animator animation )
                {
                
                }
            } );
            
            
            //##################################
            //
            // Set up the final scale animation
            //
            //##################################s
            PropertyValuesHolder sx2 = PropertyValuesHolder.ofFloat( "scaleX", 1f, 2f );
            PropertyValuesHolder sy2 = PropertyValuesHolder.ofFloat( "scaleY", 1f, 2f );
            
            clock[ 2 ] = ObjectAnimator.ofPropertyValuesHolder( tv, sx2, sy2 );
            clock[ 2 ].setDuration( mainDuration );
            clock[ 2 ].setStartDelay( mainDuration * 2 );
            clock[ 2 ].setInterpolator( new CustomBounceInterpolator( 0.2f, 20 ) );
            clock[ 2 ].addListener( new AnimatorListenerAdapter()
            {
                @Override
                public void onAnimationEnd( Animator animation )
                {
                    super.onAnimationEnd( animation );
                    
                    tv.setText( "" );
                    
                    //@@@@@@@@@@@@@@@@@@ Star shoot sound for landing
                    if ( gameEngine.soundPlayer != null )
                    {
                        gameEngine.soundPlayer.playBgSfx( PlaySound.STAR_SHOOT );
                    }
                    
                    int[] resArray = gameEngine.arrayFromResource( R.array.star_burst );
                    
                    ObjectAnimator bg = ObjectAnimator.ofInt( tv, "backgroundResource", resArray );
                    bg.setEvaluator( new CustomEvaluator() );
                    bg.setInterpolator( new LinearInterpolator() );
                    bg.setDuration( (resArray.length - 1) * 25 );
                    bg.addListener( new AnimatorListenerAdapter()
                    {
                        @Override
                        public void onAnimationEnd( Animator animation )
                        {
                            super.onAnimationEnd( animation );
                            tv.setVisibility( INVISIBLE );
                            tv.setBackgroundResource( 0 );
                        }
                    } );
                    bg.start();
                }
            } );
            
            // Eliminate any infinite loops caused by solving
            // special tiles withing a special call
            image.setTag( clock );
            image.specialItem = -1;
            image.setState( BoardTile.SPECIAL_ANIMATE );
            
        }
        else
        {
            matchList[ image.getTileY() ][ image.getTileX() ] = 0;
            image.setState( BoardTile.STATE_MATCHED );
        }
*/
    }
    
    
    /**
     * ########################################
     * <p>
     * Allows the player to shuffle the board
     * with a bomb affect.
     * Coins near explosision shake a little
     * Master bomb expands then explodes
     * <p>
     * ########################################
     */
    private void useABomb( final BoardTile image, int startDelay )
    {
/*
        // Save the player some time
        if ( timer != null )
        {
            timer.pause();
        }
        
        // For recursive special calls
        final ArrayList<Integer> specials = new ArrayList<>();
        
        
        //#######################################
        //
        // Master bomb grows then explodes
        //
        //#######################################
        final ConstraintLayout frame     = mainView.findViewById( R.id.boardSpecials );
        int                    baseDelay = 350;
        int[]                  resIds;
        final BoardTile        master    = new BoardTile( getContext() );
        ObjectAnimator[]       bomb      = new ObjectAnimator[ 2 ];
        PropertyValuesHolder   sx        = PropertyValuesHolder.ofFloat( "scaleX", 1, 3 );
        PropertyValuesHolder   sy        = PropertyValuesHolder.ofFloat( "scaleY", 1, 3 );
        
        
        // I want the master bomb to be above all other coins
        master.setVisibility( VISIBLE );
        master.setId( image.getId() );
        master.setPivotX( image.getWidth() / 2f );
        master.setPivotY( image.getHeight() / 2f );
        //
        //        GameBoardFragment.makeConnection( master, frame, .5f, .5f );
        frame.addView( master, image.getWidth(), image.getHeight() );
        master.setX( image.getX() );
        master.setY( image.getY() );
        master.setScaleType( ImageView.ScaleType.FIT_CENTER );
        master.setImageResource( GameBoard.coinSet[ image.tileNum ] );
        
        
        bomb[ 0 ] = ObjectAnimator.ofPropertyValuesHolder( master, sx, sy );
        bomb[ 0 ].setInterpolator( new CustomBounceInterpolator( 0.2f, 20 ) );
        bomb[ 0 ].setDuration( baseDelay );
        bomb[ 0 ].setStartDelay( startDelay );
        bomb[ 0 ].addListener( new Animator.AnimatorListener()
        {
            @Override
            public void onAnimationStart( Animator animation )
            {
                //@@@@@@@@@@@@@@@@@@ Bomb sound
                if ( gameEngine.soundPlayer != null && !inHelper )
                {
                    gameEngine.soundPlayer.playBgSfx( PlaySound.BOMB_EXPAND );
                }
            }
            
            @Override
            public void onAnimationEnd( Animator animation )
            {
                //@@@@@@@@@@@@@@@@@@ Explode Sound
                if ( gameEngine.soundPlayer != null && !inHelper )
                {
                    gameEngine.soundPlayer.playBgSfx( PlaySound.BOMB_SPECIAL );
                }
                
                int[]         resIds = gameEngine.arrayFromResource( R.array.bomb_explode );
                ValueAnimator dummy  = ValueAnimator.ofInt( 0, 1 );
                dummy.setDuration( resIds.length * 50 ).addListener( new AnimatorListenerAdapter()
                {
                    @Override
                    public void onAnimationEnd( Animator animation )
                    {
                        super.onAnimationEnd( animation );
                        frame.removeView( master );
                    }
                } );
                dummy.start();
            }
            
            @Override
            public void onAnimationCancel( Animator animation )
            {
            
            }
            
            @Override
            public void onAnimationRepeat( Animator animation )
            {
            
            }
        } );
        
        
        //##########################################
        //
        // Extra delay time from "special Capture"
        //
        //##########################################
        baseDelay += startDelay;
        
        resIds = gameEngine.arrayFromResource( R.array.bomb_explode );
        //
        bomb[ 1 ] = ObjectAnimator.ofInt( master, "imageResource", resIds );
        bomb[ 1 ].setEvaluator( new CustomEvaluator() );
        bomb[ 1 ].setDuration( resIds.length * 50 );
        bomb[ 1 ].setStartDelay( baseDelay );
        bomb[ 1 ].setInterpolator( new LinearInterpolator() );
        //
        image.setImageResource( 0 );
        
        // Eliminate any infinite loops caused by solving
        // special tiles withing a special call
        image.setState( BoardTile.SPECIAL_ANIMATE );
        image.setTag( bomb );
        image.specialItem = -1;
        image.isCaught = true;
        
        
        //##################################
        //
        // All other bomb coins
        //
        //##################################
        // Start the proceeding animation AFTER the
        // master tile's initial animation
        int     tileX;
        int     tileY;
        int[]   grid  = { -1, 0, 1 };
        int[][] shake = new int[ mapHeight ][ mapWidth ];
        
        
        //########################################
        //
        // Make a super bomb when time running out
        //
        //########################################
        if ( timer != null && CustomTimer.currentTime < SUPER_TIME_VALUE && !inHelper )
        {
            grid = new int[]{ -2, -1, 0, 1, 2 };
        }
        
        //##############################
        // Match affected tiles, and
        // Attach a special animation
        // to exit
        //##############################
        for ( int value : grid )
        {
            tileY = image.getTileY() + value;
            
            //
            if ( tileY > -1 && tileY < getRowCount() )
            {
                for ( int i : grid )
                {
                    tileX = image.getTileX() + i;
                    if ( tileX > -1 && tileX < getColumnCount() )
                    {
                        final BoardTile tile = boardTiles.get( tileY * mapWidth + tileX );
                        ObjectAnimator  anim;
                        
                        if ( tile.tileNum == -1 || matchList[ tileY ][ tileX ] == 0 || tile.getPosition() == image.getPosition() || tile.isCaught )
                        {
                            continue;
                        }
                        
                        // If we are affecting another special
                        // item, then run that item's special code
                        if ( tile.specialItem > 0 )
                        {
                            if ( tile.tileNum == BoardTile.BOMB )
                            {
                                specials.add( tile.getPosition() );
                            }
                            else if ( tile.tileNum == BoardTile.CLOCK )
                            {
                                tile.setState( BoardTile.USE_SPECIAL_ITEM );
                                // Clear tile in Match List
                                matchList[ tile.getTileY() ][ tile.getTileX() ] = 2;
                            }
                            else if ( tile.tileNum >= BoardTile.RED_GEM )
                            {
                                tile.setState( BoardTile.GEM_MATCHED );
                                tile.animDelay = baseDelay;
                                // Clear tile in Match List
                                matchList[ tile.getTileY() ][ tile.getTileX() ] = 2;
                            }
                        }
                        else
                        {
                            // Setup the Bomb animation for this tile
                            tile.setPivotX( tile.getWidth() / 2f );
                            tile.setPivotY( tile.getHeight() / 2f );
                            //
                            resIds = gameEngine.arrayFromResource( R.array.bomb_explode );
                            //
                            anim = ObjectAnimator.ofInt( tile, "imageResource", resIds );
                            anim.setEvaluator( new CustomEvaluator() );
                            anim.setDuration( resIds.length * 50 );
                            anim.setInterpolator( new LinearInterpolator() );
                            anim.setStartDelay( baseDelay );
                            
                            // Clear tile in Match List
                            matchList[ tile.getTileY() ][ tile.getTileX() ] = 2;
                            
                            // Attach it to the view
                            //                            tile.endAnimation();
                            tile.setTag( anim );
                            tile.setState( BoardTile.SPECIAL_ANIMATE );
                            //                            tile.setSoundEfx( PlaySound.BOMB_SPECIAL );
                        }
                    }
                }
            }
        }
        
        
        //#################################
        //
        // Prepare the shake-ables grid
        //
        //#################################
        GameEngine.arrayCopy( matchList, shake, mapHeight, mapWidth );
        
        int[][]             direction = { { 0, -1 }, { 1, 0 }, { 0, 1 }, { -1, 0 } };
        ArrayList<PointXYZ> shakeList = new ArrayList<>();
        
        
        // Find the tiles that can shake
        for ( int y = 0; y < mapHeight; y++ )
        {
            for ( int x = 0; x < mapWidth; x++ )
            {
                if ( shake[ y ][ x ] == 2 )
                {
                    matchList[ y ][ x ] = 0;
                    
                    for ( int i = 0; i < 4; i++ )
                    {
                        int baseX = x + direction[ i ][ 0 ];
                        int baseY = y + direction[ i ][ 1 ];
                        
                        
                        if ( baseX < mapWidth && baseX > -1 && baseY < mapHeight && baseY > -1 && (shake[ baseY ][ baseX ] != 2 && shake[ baseY ][ baseX ] != -1 && shake[ baseY ][ baseX ] != 0) )
                        {
                            BoardTile tile    = boardTiles.get( baseY * mapWidth + baseX );
                            int       offsetX = image.getTileX() - tile.getTileX();
                            int       offsetY = image.getTileY() - tile.getTileY();
                            
                            if ( tile.getPosition() == image.getPosition() || tile.isCaught )
                            {
                                continue;
                            }
                            
                            // If X is negative, shake favors the right, else the left
                            // If Y is positive, shake favors the top, else the bottom
                            shakeList.add( new PointXYZ( (offsetX < 0) ? 1 : -1, (offsetY < 0) ? 1 : -1, (baseY * mapWidth + baseX) ) );
                        }
                    }
                    
                }
            }
        }
        
        //
        // Activate the shaker!
        //
        for ( int i = 0; i < shakeList.size(); i++ )
        {
            PointXYZ             index = shakeList.get( i );
            final BoardTile      tile  = boardTiles.get( index.z );
            ObjectAnimator       shaker;
            PropertyValuesHolder px    = PropertyValuesHolder.ofFloat( "translationX", index.x * 4 );
            PropertyValuesHolder py    = PropertyValuesHolder.ofFloat( "translationY", index.y * 4 );
            //
            sx = PropertyValuesHolder.ofFloat( "scaleX", 1, 1.25f, 0.75f, 1.15f, 1 );
            sy = PropertyValuesHolder.ofFloat( "scaleY", 1, 0.75f, 1.25f, 0.85f, 1 );
            
            shaker = ObjectAnimator.ofPropertyValuesHolder( tile, px, py, sx, sy );
            shaker.setInterpolator( new LinearInterpolator() );
            shaker.setDuration( 6 * 50 );
            shaker.setStartDelay( baseDelay );
            shaker.addListener( new AnimatorListenerAdapter()
            {
                @Override
                public void onAnimationEnd( Animator animation )
                {
                    super.onAnimationEnd( animation );
                    
                    // Dummy listener so one is not added
                    tile.setTranslationY( 0 );
                    tile.setTranslationX( 0 );
                    tile.setState( BoardTile.STATE_ACTIVE );
                    tile.setTag( null );
                }
            } );
            //
            tile.setState( BoardTile.SPECIAL_ANIMATE );
            tile.setTag( shaker );
        }
        
        
        // Capture more specials if found
        if ( specials.size() > 0 )
        {
            captureMoreBombs( specials, startDelay );
        }
        
        
        // Save the player some time
        if ( timer != null )
        {
            timer.resume();
        }
*/
    }
    
    
    /**
     * //###############################
     * <p>
     * Vertical AND Horizontal bolt
     * clears coins
     * <p>
     * //###############################
     */
    private void useABolt( final BoardTile image )
    {
/*
        // Save the player some time
        if ( timer != null )
        
        {
            timer.pause();
        }
        
        //#######################################
        //
        // Master bomb grows then explodes
        //
        //#######################################
        ConnectionsGridLayout  layout      = mainView.findViewById( R.id.boardGridLayout );
        final ConstraintLayout frame       = mainView.findViewById( R.id.boardSpecials );
        int                    half_width  = image.getWidth() / 2;
        int                    half_height = image.getHeight() / 2;
        int                    width       = image.getWidth();
        int                    height      = image.getHeight();
        int                    xx;
        int                    yy;
        int[]                  resId;
        
        //        frame.addView( spark );
        final int          DURATION      = 0;
        int                DIRECTION;
        int                colorToMatch;
        ArrayList<Integer> affectedTiles = new ArrayList<>();
        
        // For recursive special calls
        final ArrayList<Integer> specials = new ArrayList<>();
        
        
        // Center-of-it-all tile
        Point[] start = new Point[ 2 ];
        Point[] end   = new Point[ 2 ];
        int[][] bolts = new int[ 2 ][];
        
        
        // Get the ACTIVE height and width for the current board
        // from where the initiator tile is
        int startX = -1, endX = -1;
        int startY = -1, endY = -1;
        int incX, incY;
        
        if ( Math.abs( image.swipeDirection ) == (mapHeight + 1) || Math.abs( image.swipeDirection ) == (mapHeight - 1) )
        {
            int     realX, realY;
            int[][] grid = new int[ 2 ][ 4 ];
            int[][] search = {
                    { -1, -1, -1, -1 }, // "\"
                    { 1, -1, mapWidth, -1 }   // "/"
            };
            
            //
            if ( Math.abs( image.swipeDirection ) == (mapHeight + 1) )
            {
                // Leaning left
                DIRECTION = 1;
            }
            else
            {
                DIRECTION = 2;
            }
            
            // Build a testing grid for diagonal
            // Bolts. Search for the starting points
            for ( int c = 0; c < 2; c++ )
            {
                realX = startX = image.getTileX();
                realY = startY = image.getTileY();
                //
                while ( startX != search[ c ][ 2 ] && startY != search[ c ][ 3 ] )
                {
                    // Null tile
                    if ( boardMap[ startY ][ startX ] != -1 )
                    {
                        realY = startY;
                        realX = startX;
                    }
                    //
                    startX += search[ c ][ 0 ];
                    startY += search[ c ][ 1 ];
                }
                
                grid[ c ][ 0 ] = -search[ c ][ 0 ]; // Opposite of search increment value
                grid[ c ][ 1 ] = -search[ c ][ 1 ];
                grid[ c ][ 2 ] = realX; // Starting X
                grid[ c ][ 3 ] = realY; // Starting Y
            }
            
            //
            // Find the ending points
            //
            for ( int i = 0; i < grid.length; i++ )
            {
                int[] index = grid[ i ];
                
                // Choose the shortest tile count in
                // each direction as a starting point
                // First is for "|" bolt pattern
                // Second is for "-" bolt pattern
                incX = index[ 0 ];
                incY = index[ 1 ];
                startX = index[ 2 ];
                startY = index[ 3 ];
                
                // Get the end
                realY = startY;
                realX = startX;
                endY = startY;
                endX = startX;
                
                while ( endY < mapHeight && ((endX > -1 && incX == -1) || (endX < mapWidth && incX == 1)) )
                {
                    // Null tile
                    if ( boardMap[ endY ][ endX ] != -1 )
                    {
                        affectedTiles.add( endY * mapWidth + endX );
                        realY = endY;
                        realX = endX;
                    }
                    //
                    endX += incX;
                    endY += incY;
                }
                
                // Use the REAL values
                endX = realX;
                endY = realY;
                
                
                // Transfer over bolt match info
                bolts[ i ] = new int[ affectedTiles.size() ];
                for ( int c = 0; c < affectedTiles.size(); c++ )
                {
                    bolts[ i ][ c ] = affectedTiles.get( c );
                }
                
                // Clear for the next round
                affectedTiles.clear();
                
                
                // Finish off the "\" Bolt pattern
                BoardTile startTile = boardTiles.get( startY * mapWidth + startX );
                BoardTile endTile   = boardTiles.get( endY * mapWidth + endX );
                
                start[ i ] = new Point( ((( int ) startTile.getX() / width) * width), ((( int ) startTile.getY() / height) * height) );
                end[ i ] = new Point( ((( int ) endTile.getX() / width) * width), ((( int ) endTile.getY() / height) * height) );
            }
        }
        else
        {
            int[][] grid = {
                    // incX, incY, xStart, yStart
                    { 1, 0, 0, image.getTileY() }, // Left to Right:
                    { 0, 1, image.getTileX(), 0 }  // Up to Down
            };
            
            for ( int i = 0; i < grid.length; i++ )
            {
                int[] index = grid[ i ];
                
                // Choose the shortest tile count in
                // each direction as a starting point
                // First is for "|" bolt pattern
                // Second is for "-" bolt pattern
                incX = index[ 0 ];
                incY = index[ 1 ];
                startX = index[ 2 ];
                startY = index[ 3 ];
                
                
                // 0 and 90 degree
                // Get the start
                while ( boardMap[ startY ][ startX ] == -1 )
                {
                    startX += incX;
                    startY += incY;
                }
                
                // Get the end
                int realY = startY, realX = startX;
                endY = startY;
                endX = startX;
                
                while ( endY < mapHeight && endX < mapWidth )
                {
                    // Null tile
                    if ( boardMap[ endY ][ endX ] != -1 )
                    {
                        affectedTiles.add( endY * mapWidth + endX );
                        realY = endY;
                        realX = endX;
                    }
                    //
                    endX += incX;
                    endY += incY;
                }
                
                // Use the REAL values
                endX = realX;
                endY = realY;
                
                
                // Transfer over bolt match info
                bolts[ i ] = new int[ affectedTiles.size() ];
                for ( int c = 0; c < affectedTiles.size(); c++ )
                {
                    bolts[ i ][ c ] = affectedTiles.get( c );
                }
                
                // Clear for the next round
                affectedTiles.clear();
                
                
                // Finish off the "\" Bolt pattern
                BoardTile startTile = boardTiles.get( startY * mapWidth + startX );
                BoardTile endTile   = boardTiles.get( endY * mapWidth + endX );
                
                start[ i ] = new Point( ((( int ) startTile.getX() / width) * width), ((( int ) startTile.getY() / height) * height) );
                end[ i ] = new Point( ((( int ) endTile.getX() / width) * width), ((( int ) endTile.getY() / height) * height) );
            }
            
            // Get the direction
            if ( Math.abs( image.swipeDirection ) == 1 )
            {
                DIRECTION = 1;
            }
            else
            {
                DIRECTION = 2;
            }
        }
        
        
        // Loop variables
        int loopStart = 0, loopMax = bolts.length;
        
        if ( (timer != null && CustomTimer.currentTime > SUPER_TIME_VALUE) || inHelper )
        {
            // Left / Right
            if ( DIRECTION == 1 )
            {
                loopMax = 1;
            }
            else
            {
                loopStart = 1;
            }
        }
        
        
        //##################################
        //
        //
        //
        //##################################
        for ( int i = loopStart; i < loopMax; i++ )
        {
            // Loop through affected tiles
            for ( int c = 0; c < bolts[ i ].length; c++ )
            {
                BoardTile nextTile = boardTiles.get( bolts[ i ][ c ] );
                
                if ( nextTile.specialItem == 2 && nextTile.getPosition() != image.getPosition() )
                {
                    // Capture more specials if found
                    if ( nextTile.tileNum == BoardTile.BOMB )
                    {
                        specials.add( nextTile.getPosition() );
                    }
                    
                    continue;
                }
                
                
                //
                //---------------------------------
                //
                if ( nextTile.getTag() == null )
                {
                    // Must do the first tile as well
                    // Burst the tile at the end
                    //
                    ObjectAnimator coinAnim;
                    resId = gameEngine.arrayFromResource( R.array.beam_explode );
                    
                    coinAnim = ObjectAnimator.ofInt( nextTile, "imageResource", resId );
                    coinAnim.setEvaluator( new CustomEvaluator() );
                    coinAnim.setInterpolator( new LinearInterpolator() );
                    coinAnim.setDuration( resId.length * 25 );
                    coinAnim.setStartDelay( DURATION + 500 );
                    // Will receive a listener
                    coinAnim.removeAllListeners();
                    
                    // Change to the flash coin
//                    nextTile.setImageResource( R.drawable.flash_coin );
                    
                    // Clear this tile
                    matchList[ nextTile.getTileY() ][ nextTile.getTileX() ] = 0;
                    
                    // Attach it to the view
                    nextTile.setTag( coinAnim );
                    
                    //##############################
                    // We can solve for a clock
                    //##############################
                    if ( nextTile.tileNum == BoardTile.CLOCK )
                    {
                        nextTile.setState( BoardTile.USE_SPECIAL_ITEM );
                    }
                    else if ( nextTile.tileNum >= BoardTile.RED_GEM )
                    {
                        nextTile.setState( BoardTile.GEM_MATCHED );
                        nextTile.animDelay = DURATION + 500;
                    }
                    else
                    {
                        nextTile.setState( BoardTile.SPECIAL_ANIMATE );
                    }
                }
            }
            
            
            // Don't even bother if a length is a single match
            if ( bolts[ i ].length <= 1 )
            {
                continue;
            }
            
            //####################################
            // Match affected tiles, and Attach a
            // special animation to exit
            // Only the start and end tiles get
            // bolt contact
            //####################################
            float                xDist;
            float                yDist;
            double               length;
            double               angle;
            int                  center;
            final ImageView      lightning;
            ObjectAnimator       coinAnim;
            final ObjectAnimator flasher;
            
            // Get the length
            xDist = (end[ i ].x - start[ i ].x);
            yDist = (end[ i ].y - start[ i ].y);
            length = Math.sqrt( (xDist * xDist) + (yDist * yDist) );
            angle = PointXYZ.angleOfTwoPoints( start[ i ], end[ i ] ) - 180;
            
            // Create the linked lightning
            lightning = new ImageView( getContext() );
            lightning.setId( 1000 + 1 );
            lightning.setVisibility( VISIBLE );
            lightning.setScaleType( ImageView.ScaleType.FIT_XY );
            
            frame.addView( lightning, width, ( int ) length );
            
            lightning.setPivotX( width / 2f );
            lightning.setPivotY( 0 );
            
            //
            // Adjust the offsets on a grid to center on the tiles
            //
            center = half_width;
            //
            xx = start[ i ].x - center + half_width;
            yy = start[ i ].y + layout.getPaddingTop() + half_height;
            
            // Lightning centered with the tile
            lightning.setX( xx );
            lightning.setY( yy );
            lightning.setRotation( ( int ) angle );
            
            
            //####################################
            //
            // Animate each lighting bolt
            //
            //####################################
            resId = gameEngine.arrayFromResource( R.array.lightning );
            flasher = ObjectAnimator.ofInt( lightning, "imageResource", resId );
            flasher.setEvaluator( new CustomEvaluator() );
            flasher.setInterpolator( new LinearInterpolator() );
            flasher.setDuration( */
        /*DURATION + *//*
resId.length * 25 );
            
            // Start these flashes now!
            flasher.addListener( new Animator.AnimatorListener()
            {
                @Override
                public void onAnimationStart( Animator animation )
                {
                    //@@@@@@@@@@@@@@@@@@ Spark sound
                    if ( gameEngine.soundPlayer != null && !inHelper )
                    {
                        gameEngine.soundPlayer.playBgSfx( PlaySound.LIGHTNING_SPECIAL );
                    }
                }
                
                @Override
                public void onAnimationEnd( Animator animation )
                {
                    gameEngine.animatorList.remove( flasher );
                    frame.removeView( lightning );
                    
                    //@@@@@@@@@@@@@@@@@@ Spark sound
                    if ( gameEngine.soundPlayer != null && !inHelper )
                    {
                        gameEngine.soundPlayer.playBgSfx( PlaySound.SPECIAL_MATCHED );
                    }
                }
                
                @Override
                public void onAnimationCancel( Animator animation )
                {
                
                }
                
                @Override
                public void onAnimationRepeat( Animator animation )
                {
                
                }
            } );
            //
            gameEngine.animatorList.add( flasher );
            flasher.start();
        }
        
        
        // If bombs caught in the crossfire
        if ( specials.size() > 0 )
        {
            captureMoreBombs( specials, 0 );
        }
        
        
        // Eliminate any infinite loops caused by solving
        // special tiles within a special call
        image.specialItem = -1;
        image.setSoundEfx( PlaySound.SPECIAL_MATCHED );
        
        // Save the player some time
        if ( timer != null )
        {
            timer.resume();
        }
*/
    }
    
    
    /**
     * //###############################
     * <p>
     * Use the star booster
     * <p>
     * //###############################
     */
    private void useAStar( final BoardTile image )
    {
/*
        // Save the player some time
        if ( timer != null )
        {
            timer.pause();
        }
        
        // Init the rotating star animation and play until it is ready to shoot!
        final ConstraintLayout   cl        = mainView.findViewById( R.id.boardGridFrame );
        final int                size      = image.getWidth();
        final BoardTile[]        tv        = new BoardTile[ 5 ];
        final int                baseDelay = 750;
        final ArrayList<Integer> specials  = new ArrayList<>();         // For recursive special calls
        
        
        //#######################################
        //
        // Now, set the projectiles to shoot off
        // when the master tile's initial
        // animation ends!
        //
        //#######################################
        // Spark sound; 2 seconds
        if ( gameEngine.soundPlayer != null && !inHelper )
        {
            gameEngine.soundPlayer.playBgSfx( PlaySound.CHARGE_BEAM_SPECIAL );
        }
        
        ObjectAnimator[] star = new ObjectAnimator[ 2 ];
        star[ 0 ] = ObjectAnimator.ofFloat( image, "rotation", 720 );
        
        image.setPivotX( image.getWidth() / 2f );
        image.setPivotY( image.getHeight() / 2f );
        star[ 0 ].setInterpolator( new AnticipateOvershootInterpolator() );
        star[ 0 ].setDuration( baseDelay );
        
        // Finish the MASTER tile off with a BIG star burst
        star[ 1 ] = ObjectAnimator.ofInt( image, "imageResource", gameEngine.arrayFromResource( R.array.bolt_burst ) );
        star[ 1 ].setEvaluator( new CustomEvaluator() );
        star[ 1 ].setInterpolator( new AccelerateInterpolator() );
        star[ 1 ].setDuration( 17 * 25 );
        star[ 1 ].setStartDelay( baseDelay );
        star[ 1 ].removeAllListeners();
        star[ 1 ].addListener( new Animator.AnimatorListener()
        {
            @Override
            public void onAnimationStart( Animator animation )
            {
                image.setScaleY( 2 );
                image.setScaleX( 2 );
                image.specialTile = -1;
                image.setRotation( 0 );
                
                // Spark sound; 2 seconds
                if ( gameEngine.soundPlayer != null && !inHelper )
                {
                    gameEngine.soundPlayer.playBgSfx( PlaySound.STAR_SHOOT );
                }
            }
            
            @Override
            public void onAnimationEnd( Animator animation )
            {
                image.setScaleX( 1f );
                image.setScaleY( 1f );
            }
            
            @Override
            public void onAnimationCancel( Animator animation )
            {
            
            }
            
            @Override
            public void onAnimationRepeat( Animator animation )
            {
            
            }
        } );
        
        
        //############################
        //
        //
        //
        //############################
        // Up, Right, Down-right, Down-left, left
        final int bounds = 3;
        int[][] destination = {
                //  Up
                */
/*
                                { 0, -size * 2 },
                                // Right
                                { size * 2, 0 },
                                // Down Right,
                                { size * 2, size * 2 },
                                // Down Left
                                { -size * 2, size * 2 },
                                // Left
                                { -size * 2, 0 }
                *//*

                { 0, -size * bounds },
                // Right
                { size * bounds, 0 },
                // Down Right,
                { size * bounds, size * bounds },
                // Down Left
                { -size * bounds, size * bounds },
                // Left
                { -size * bounds, 0 }
            
        };
        
        // Get boundaries
        int maxWidth  = (Math.min( (image.getTileX() + bounds + 1), mapWidth ));
        int maxHeight = (Math.min( (image.getTileY() + bounds + 1), mapHeight ));
        int minWidth  = ((image.getTileX() - (bounds + 1)) < 0 ? -1 : (image.getTileX() - (bounds + 1)));
        int minHeight = ((image.getTileY() - (bounds + 1)) < 0 ? -1 : (image.getTileY() - (bounds + 1)));
        
        
        // Super star when time running out
        if ( timer != null && CustomTimer.currentTime < SUPER_TIME_VALUE && !inHelper )
        {
            // Up, Right, Down-right, Down-left, left
            destination = new int[][]{
                    //  Up
                    { 0, -(cl.getHeight() + size) },
                    // Right
                    { cl.getWidth() + size, 0 },
                    // Down Right,
                    { cl.getHeight() + size, cl.getWidth() + size },
                    // Down Left
                    { -(cl.getWidth() + size), cl.getHeight() + size },
                    // Left
                    { -(cl.getWidth() + size), 0 }
            };
            
            //
            maxWidth = mapWidth;
            maxHeight = mapHeight;
            minHeight = -1;
            minWidth = -1;
        }
        
        
        //##################################
        // Shoot off the stars after MASTER
        // star spin.
        // Create 5 empty views to hold star
        // beams for shooting animation
        //##################################
        for ( int v = 0; v < 5; v++ )
        {
            ConstraintSet constraintSet = new ConstraintSet();
            final int     index         = v;
            tv[ v ] = new BoardTile( getContext() );
            //
            tv[ v ].setId( 1000 + v );
            tv[ v ].setVisibility( INVISIBLE );
            tv[ v ].setBackgroundResource( R.drawable.star_1 );
            tv[ v ].setPivotX( size / 2f );
            tv[ v ].setPivotY( size / 2f );
            //
            cl.addView( tv[ v ], new GridView.LayoutParams( size, size ) );
            
            // Process
            constraintSet.clone( cl );
            constraintSet.connect( tv[ v ].getId(), ConstraintSet.TOP, getId(), ConstraintSet.TOP );
            constraintSet.connect( tv[ v ].getId(), ConstraintSet.BOTTOM, getId(), ConstraintSet.BOTTOM );
            constraintSet.connect( tv[ v ].getId(), ConstraintSet.END, getId(), ConstraintSet.END );
            constraintSet.connect( tv[ v ].getId(), ConstraintSet.START, getId(), ConstraintSet.START );
            
            // Set the constraints
            float hBias = ( float ) image.getId();
            float vBias = hBias;
            
            vBias = ( int ) (vBias / mapHeight);
            hBias = ( int ) (hBias % mapWidth);
            
            hBias /= (mapWidth - 1);
            vBias /= (mapHeight - 1);
            
            constraintSet.setHorizontalBias( tv[ v ].getId(), hBias );
            constraintSet.setVerticalBias( tv[ v ].getId(), vBias );
            constraintSet.applyTo( cl );
            
            //
            tv[ v ].setVisibility( INVISIBLE );
            tv[ v ].animate().translationX( destination[ v ][ 0 ] ).translationY( destination[ v ][ 1 ] );
            tv[ v ].animate().rotation( 360 * 4 );
            tv[ v ].animate().setStartDelay( baseDelay );
            tv[ v ].animate().setDuration( baseDelay ).setInterpolator( new DecelerateInterpolator() );
            // Allow support for pausing
            tv[ v ].animate().setUpdateListener( new ValueAnimator.AnimatorUpdateListener()
            {
                @Override
                public void onAnimationUpdate( ValueAnimator animation )
                {
                    if ( tv[ index ] != null && tv[ index ].animator == null )
                    {
                        tv[ index ].animator = animation;
                    }
                }
            } );
            
            // Clean up code!
            tv[ v ].animate().withStartAction( new Runnable()
            {
                @Override
                public void run()
                {
                    tv[ index ].setVisibility( VISIBLE );
                }
            } );
            tv[ v ].animate().withEndAction( new Runnable()
            {
                @Override
                public void run()
                {
                    cl.removeView( tv[ index ] );
                    tv[ index ].clearAnimation();
                    tv[ index ].setVisibility( INVISIBLE );
                    gameEngine.animatorList.remove( tv[ index ].animator );
                    tv[ index ].animator = null;
                    tv[ index ] = null;
                }
            } );
            
            //
            tv[ v ].animate().start();
        }
        
        
        //#######################################
        //
        // Star animation main code for all the
        // regular coins to be matched
        //
        //#######################################
        int tileY = image.getTileY();
        int tileX = image.getTileX();
        // Up, Right, Down-Right, Down-Left, Left
        int[][] direction = { { 0, -1 }, { 1, 0 }, { 1, 1 }, { -1, 1 }, { -1, 0 }, };
        
        
        // Match affected tiles, and Attach a
        // special animation to exit
        // Star has 5 prongs, check each direction
        for ( int i = 0; i < 5; i++ )
        {
            int t_x        = tileX;
            int t_y        = tileY;
            int delayValue = 1;
            
            // Do we have a good tile??
            //                    while ( (t_x < mapWidth && t_x > -1) && (t_y < mapHeight && t_y > -1) )
            while ( (t_x < maxWidth && t_x > minWidth) && (t_y < maxHeight && t_y > minHeight) )
            {
                final BoardTile tile = boardTiles.get( t_y * mapWidth + t_x );
                
                ObjectAnimator anim;
                anim = ObjectAnimator.ofInt( tile, "imageResource", gameEngine.arrayFromResource( R.array.bolt_burst ) );
                anim.setEvaluator( new CustomEvaluator() );
                anim.setInterpolator( new AccelerateInterpolator() );
                anim.setDuration( 17 * 25 );
                anim.removeAllListeners();
                
                //
                if ( tile.tileNum == -1 )
                {
                    // Get the next tile
                    t_x += direction[ i ][ 0 ];
                    t_y += direction[ i ][ 1 ];
                    continue;
                }
                
                // If we are affecting another special
                // item, then run that item's special code
                if ( tile.specialItem > 0 && tile.getPosition() != image.getPosition() )
                {
                    if ( tile.tileNum == BoardTile.CLOCK )
                    {
                        tile.setState( BoardTile.USE_SPECIAL_ITEM );
                    }
                    else if ( tile.tileNum >= BoardTile.RED_GEM )
                    {
                        tile.setState( BoardTile.GEM_MATCHED );
                        tile.animDelay = baseDelay + delayValue;
                    }
                    else
                    {
                        // Capture more specials if found
                        if ( tile.tileNum == BoardTile.BOMB )
                        {
                            specials.add( tile.getPosition() );
                        }
                        else
                        {
                            tile.setState( BoardTile.USE_SPECIAL_ITEM_NEXT );
                        }
                    }
                }
                else
                {
                    //
                    matchList[ t_y ][ t_x ] = 0;
                    
                    // All following animations need to start as the projectile passes over them
                    if ( tile.getPosition() != image.getPosition() )
                    {
                        anim.setStartDelay( baseDelay + delayValue );
                        //
                        // Setup the Bomb animation for this tile
                        tile.setPivotX( tile.getWidth() / 2f );
                        tile.setPivotY( tile.getHeight() / 2f );
                        tile.specialItem = -1;
                        
                        // Attach it to the view
                        tile.setTag( anim );
                        tile.setState( BoardTile.SPECIAL_ANIMATE );
                        tile.setSoundEfx( PlaySound.SPECIAL_MATCHED );
                    }
                }
                
                // Get the next tile
                t_x += direction[ i ][ 0 ];
                t_y += direction[ i ][ 1 ];
                delayValue += (baseDelay / mapWidth);
            }
        }
        
        // If bombs caught in the crossfire
        if ( specials.size() > 0 )
        {
            captureMoreBombs( specials, baseDelay );
        }
        
        //########################################
        // Eliminate any infinite loops
        // caused by solving
        // special tiles withing a special call
        //########################################
        image.specialItem = -1;
        image.setState( BoardTile.SPECIAL_ANIMATE );
        image.setTag( star );
        
        // Save the player some time
        if ( timer != null )
        {
            timer.resume();
        }
*/
    }
    
    
    /**
     * //###############################
     * <p>
     * Strikes the swapped coin, bounces
     * the coins in the air
     * ( while spinning ) and drops them
     * to a particle effect
     * and matches them all
     * <p>
     * //###############################
     */
    private void useSpark( final BoardTile image )
    {
/*
        // Save the player some time
        if ( timer != null )
        {
            timer.pause();
        }
        
        //#######################################
        //
        // Master bomb grows then explodes
        //
        //#######################################
        ConnectionsGridLayout  layout      = mainView.findViewById( R.id.boardGridLayout );
        final ConstraintLayout frame       = mainView.findViewById( R.id.boardSpecials );
        int                    half_width  = image.getWidth() / 2;
        int                    half_height = image.getHeight() / 2;
        int                    width       = image.getWidth();
        int                    height      = image.getHeight();
        int                    xx;
        int                    yy;
        int[]                  resId;
        
        //        frame.addView( spark );
        final int DURATION = 0;
        int       colorToMatch;
        // Center-of-it-all tile
        Point start = new Point( ((( int ) image.getX() / width) * width), ((( int ) image.getY() / height) * height) );
        
        
        //##################################
        //
        // Find all tiles of the same color
        //
        //##################################
        //@@@@@@@@@@@@@@@@@@ Spark sound
        if ( gameEngine.soundPlayer != null && !inHelper )
        {
            gameEngine.soundPlayer.playBgSfx( PlaySound.LIGHTNING_SPECIAL );
        }
        
        // Start the proceeding animation AFTER the
        colorToMatch = boardTiles.get( image.getPosition() - image.swipeDirection ).tileNum;
        
        for ( int i = 0; i < boardTiles.size(); i++ )
        {
            // Center-of-it-all tile
            BoardTile nextTile = boardTiles.get( i );
            
            // Create a branching, jumping effect
            if ( (nextTile.tileNum == colorToMatch || (nextTile.tileNum == BoardTile.CLOCK && nextTile.specialTile == colorToMatch)) && nextTile.getPosition() != image.getPosition() )
            {
                if ( nextTile.getTag() == null )
                {
                    // Must do the first tile as well
                    // Burst the tile at the end
                    //
                    ObjectAnimator coinAnim;
                    resId = gameEngine.arrayFromResource( R.array.beam_explode );
                    
                    coinAnim = ObjectAnimator.ofInt( nextTile, "imageResource", resId );
                    coinAnim.setEvaluator( new CustomEvaluator() );
                    coinAnim.setInterpolator( new LinearInterpolator() );
                    coinAnim.setDuration( resId.length * 25 );
                    coinAnim.setStartDelay( DURATION + 500 );
                    // Will receive a listener
                    coinAnim.removeAllListeners();
                    
                    // Change to the flash coin
                    nextTile.setImageResource( R.drawable.flash_coin );
                    
                    // Clear this tile
                    matchList[ nextTile.getTileY() ][ nextTile.getTileX() ] = 0;
                    
                    // Attach it to the view
                    nextTile.setTag( coinAnim );
                    
                    //##############################
                    // We can solve for a clock
                    //##############################
                    if ( nextTile.tileNum == BoardTile.CLOCK )
                    {
                        nextTile.setState( BoardTile.USE_SPECIAL_ITEM );
                    }
                    else
                    {
                        nextTile.setState( BoardTile.SPECIAL_ANIMATE );
                    }
                }
                
                
                start = new Point( ((( int ) nextTile.getX() / width) * width), ((( int ) nextTile.getY() / height) * height) );
                
                
                // Match affected tiles, and Attach a special animation to exit
                for ( int y = i + 1; y < boardTiles.size(); y++ )
                {
                    final BoardTile      tile = boardTiles.get( y );
                    float                xDist;
                    float                yDist;
                    double               length;
                    double               angle;
                    int                  center;
                    final ImageView      lightning;
                    ObjectAnimator       coinAnim;
                    final ObjectAnimator flasher;
                    
                    
                    if ( tile.tileNum == colorToMatch || (tile.tileNum == BoardTile.CLOCK && tile.specialTile == colorToMatch) || tile.getPosition() == image.getPosition() )
                    //                    if ( tile.tileNum == colorToMatch )
                    {
                        // Get the points for the tiles
                        Point end = new Point( ((( int ) tile.getX() / width) * width), ((( int ) tile.getY() / height) * height) );
                        
                        
                        // Get the length
                        xDist = (end.x - start.x);
                        yDist = (end.y - start.y);
                        length = Math.sqrt( (xDist * xDist) + (yDist * yDist) );
                        angle = PointXYZ.angleOfTwoPoints( start, end ) - 180;
                        
                        // Create the linked lightning
                        lightning = new ImageView( getContext() );
                        lightning.setId( 1000 + y );
                        lightning.setVisibility( VISIBLE );
                        lightning.setScaleType( ImageView.ScaleType.FIT_XY );
                        
                        frame.addView( lightning, width, ( int ) length );
                        
                        lightning.setPivotX( width / 2f );
                        lightning.setPivotY( 0 );
                        
                        //
                        // Adjust the offsets on a grid to center on the tiles
                        //
                        center = half_width;
                        
                        //
                        xx = start.x - center + half_width;
                        yy = start.y + layout.getPaddingTop() + half_height;
                        
                        // Lightning centered with the tile
                        lightning.setX( xx );
                        lightning.setY( yy );
                        lightning.setRotation( ( int ) angle );
                        
                        
                        //####################################
                        //
                        // Animate each lighting bolt
                        //
                        //####################################
                        resId = gameEngine.arrayFromResource( R.array.lightning );
                        flasher = ObjectAnimator.ofInt( lightning, "imageResource", resId );
                        flasher.setEvaluator( new CustomEvaluator() );
                        flasher.setInterpolator( new LinearInterpolator() );
                        flasher.setDuration( DURATION + resId.length * 25 );
                        
                        // Start these flashes now!
                        flasher.addListener( new Animator.AnimatorListener()
                        {
                            @Override
                            public void onAnimationStart( Animator animation )
                            {
*/
/*
                                //@@@@@@@@@@@@@@@@@@ Spark sound
                                if ( gameEngine.soundPlayer != null && tile.getPosition() == image.getPosition() )
                                {
                                    gameEngine.soundPlayer.playBgSfx( PlaySound.SPARK_SPECIAL );
                                }
*//*

                                //@@@@@@@@@@@@@@@@@@ Spark sound
                                if ( gameEngine.soundPlayer != null && tile.getPosition() == image.getPosition() )
                                {
                                    gameEngine.soundPlayer.playBgSfx( PlaySound.SPECIAL_MATCHED );
                                }
                            }
                            
                            @Override
                            public void onAnimationEnd( Animator animation )
                            {
                                gameEngine.animatorList.remove( flasher );
                                frame.removeView( lightning );
                                
*/
/*
                                //@@@@@@@@@@@@@@@@@@ Spark sound
                                if ( gameEngine.soundPlayer != null && tile.getPosition() == image.getPosition() )
                                {
                                    gameEngine.soundPlayer.playBgSfx( PlaySound.SPECIAL_MATCHED );
                                }
*//*

                            }
                            
                            @Override
                            public void onAnimationCancel( Animator animation )
                            {
                            
                            }
                            
                            @Override
                            public void onAnimationRepeat( Animator animation )
                            {
                            
                            }
                        } );
                        //
                        gameEngine.animatorList.add( flasher );
                        flasher.start();
                        
                        //
                        // Burst the tile at the end
                        //
                        resId = gameEngine.arrayFromResource( R.array.beam_explode );
                        coinAnim = ObjectAnimator.ofInt( tile, "imageResource", resId );
                        coinAnim.setEvaluator( new CustomEvaluator() );
                        coinAnim.setInterpolator( new LinearInterpolator() );
                        coinAnim.setDuration( resId.length * 25 );
                        coinAnim.setStartDelay( DURATION + 500 );
                        // Will receive a listener
                        coinAnim.removeAllListeners();
                        
                        // Change to the flash coin
                        tile.setImageResource( R.drawable.flash_coin );
                        
                        // Clear this tile
                        matchList[ tile.getTileY() ][ tile.getTileX() ] = 0;
                        
                        // Attach it to the view
                        tile.setTag( coinAnim );
                        
                        //##############################
                        // We can solve for a clock
                        //##############################
                        if ( tile.tileNum == BoardTile.CLOCK )
                        {
                            tile.setState( BoardTile.USE_SPECIAL_ITEM );
                        }
                        else
                        {
                            tile.setState( BoardTile.SPECIAL_ANIMATE );
                        }
                        
                        // Move back to the last find, and link this tile
                        i = y - 1;
                        break;
                    }
                }
            }
        }
        
        
        // Eliminate any infinite loops caused by solving
        // special tiles within a special call
        image.specialItem = -1;
        resId = gameEngine.arrayFromResource( R.array.beam_explode );
        ObjectAnimator master = ObjectAnimator.ofInt( image, "imageResource", resId );
        
        master.setEvaluator( new CustomEvaluator() );
        master.setInterpolator( new LinearInterpolator() );
        master.setDuration( resId.length * 25 );
        master.setStartDelay( DURATION + 500 );
        // Will receive a listener
        master.removeAllListeners();
        
        // Change to the flash coin
        image.setImageResource( R.drawable.flash_coin );
        
        // Clear this tile
        matchList[ image.getTileY() ][ image.getTileX() ] = 0;
        
        // Attach it to the view
        image.setTag( master );
        image.setState( BoardTile.SPECIAL_ANIMATE );
        
        
        // Save the player some time
        if ( timer != null )
        
        {
            timer.resume();
        }
*/
    }
    
    
    /**
     * //###############################
     * <p>
     * Strikes the swapped coin, bounces
     * the coins in the air
     * ( while spinning ) and drops them
     * to a particle effect
     * and matches them all
     * <p>
     * //###############################
     */
    private void useChargeBeam( final BoardTile image )
    {
/*
        // Save the player some time
        if ( timer != null )
        {
            timer.pause();
        }
        
        //###################################
        //
        //
        //
        //###################################
        ConnectionsGridLayout  layout      = mainView.findViewById( R.id.boardGridLayout );
        final ConstraintLayout frame       = mainView.findViewById( R.id.boardSpecials );
        final int              width       = image.getWidth();
        final int              height      = frame.getHeight();
        final int              tile_height = image.getHeight();
        
        //
        ObjectAnimator bg;
        int[]          resId = gameEngine.arrayFromResource( R.array.laser_beam );
        
        bg = ObjectAnimator.ofFloat( image, "rotation", 0, 1080 );
        bg.setInterpolator( new AccelerateInterpolator() );
        bg.addListener( new Animator.AnimatorListener()
        {
            @Override
            public void onAnimationStart( Animator animation )
            {
                // Tile Matched Sound
                if ( gameEngine.soundPlayer != null && !inHelper )
                {
                    gameEngine.soundPlayer.playBgSfx( PlaySound.CHARGE_BEAM_PART_1 );
                }
            }
            
            @Override
            public void onAnimationEnd( Animator animation )
            {
                int colorToMatch;
                
                // Charge Beam Sound: 2 seconds
                if ( gameEngine.soundPlayer != null && !inHelper )
                {
                    gameEngine.soundPlayer.playBgSfx( PlaySound.CHARGE_BEAM_SPECIAL );
                }
                
                //##################################
                //
                // Find all tiles of the same color
                //
                //##################################
                // Start the proceeding animation AFTER the
                colorToMatch = boardTiles.get( image.getPosition() - image.swipeDirection ).tileNum;
                
                // master tile's initial animation
                // Match affected tiles, and Attach a special animation to exit
                for ( int y = 0; y < boardTiles.size(); y++ )
                {
                    final BoardTile tile = boardTiles.get( y );
                    
                    //
                    if ( tile.tileNum == colorToMatch || (tile.tileNum == BoardTile.CLOCK && tile.specialTile == colorToMatch) || tile.getPosition() == image.getPosition() )
                    {
                        final ImageView  laser    = new ImageView( getContext() );
                        ObjectAnimator[] coinAnim = new ObjectAnimator[ 2 ];
                        int[]            resId;
                        // Get a random delay value
                        int randomDelay = (y / mapHeight) * 40;
                        
                        //
                        laser.setId( 2000 + y );
                        laser.setVisibility( VISIBLE );
                        laser.setScaleType( ImageView.ScaleType.FIT_XY );
                        
                        //
                        laser.setX( tile.getX() );
                        laser.setY( tile.getY() + frame.getPaddingTop() + tile_height - height );
                        frame.addView( laser, width, height );
                        
                        // Animate the laser!
                        resId = gameEngine.arrayFromResource( R.array.laser_beam );
                        coinAnim[ 0 ] = ObjectAnimator.ofInt( laser, "imageResource", resId );
                        coinAnim[ 0 ].setEvaluator( new CustomEvaluator() );
                        coinAnim[ 0 ].setDuration( resId.length * 20 ).setInterpolator( new LinearInterpolator() );
                        coinAnim[ 0 ].setStartDelay( randomDelay );
                        coinAnim[ 0 ].addListener( new AnimatorListenerAdapter()
                        {
                            @Override
                            public void onAnimationStart( Animator animation, boolean isReverse )
                            {
                                // Tile Matched Sound
                                if ( gameEngine.soundPlayer != null )
                                {
                                    gameEngine.soundPlayer.play( PlaySound.CHARGE_BEAM_PART_2 );
                                }
                            }
                            
                            @Override
                            public void onAnimationEnd( Animator animation )
                            {
                                super.onAnimationEnd( animation );
                                frame.removeView( laser );
                            }
                        } );
                        
                        // Set a matching delay for the eploding tile
                        randomDelay += resId.length * 20;
                        
                        
                        //######################################
                        //
                        // Burst at the end
                        //
                        //######################################
                        resId = gameEngine.arrayFromResource( R.array.beam_explode );
                        //
                        coinAnim[ 1 ] = ObjectAnimator.ofInt( tile, "imageResource", resId );
                        coinAnim[ 1 ].setEvaluator( new CustomEvaluator() );
                        coinAnim[ 1 ].setInterpolator( new LinearInterpolator() );
                        coinAnim[ 1 ].setStartDelay( randomDelay );
                        coinAnim[ 1 ].setDuration( resId.length * 20 );
                        // Will receive a listener
                        coinAnim[ 1 ].removeAllListeners();
                        
                        // Setup the pivoting
                        tile.setPivotX( tile.getWidth() / 2f );
                        tile.setPivotY( tile.getHeight() / 2f );
                        
                        // Clear this tile
                        matchList[ tile.getTileY() ][ tile.getTileX() ] = 0;
                        
                        // Attach it to the view
                        tile.setTag( coinAnim );
                        
                        //##############################
                        // We can solve for a clock
                        //##############################
                        if ( tile.tileNum == BoardTile.CLOCK )
                        {
                            tile.setState( BoardTile.USE_SPECIAL_ITEM );
                        }
                        else
                        {
                            tile.setState( BoardTile.SPECIAL_ANIMATE );
                        }
                    }
                    
                }
                
                // Make a random tile a bomb
                // TO JUSTIFY THIS SPECIAL BEING SIMILAR
                // TO THE "SPARK" SPECIAL
                image.setState( BoardTile.MASTER_ITEM );
                image.tileNum = BoardTile.BOMB;
                image.specialItem = 2;
                image.swapTO = new PointXYZ( 0, 0 );
                image.swapTO.data = image.specialTile;
                
                // NOTHING ELSE SHOULD BE RUNNING!!!!!!
                // SO THIS CALL IS ALLOWED
                logicThread.addToStack( LogicThread.CMD_UPDATE_GRID );
            }
            
            @Override
            public void onAnimationCancel( Animator animation )
            {
            
            }
            
            @Override
            public void onAnimationRepeat( Animator animation )
            {
            
            }
        } );
        
        // Need a really quick flash!
        //        bg.setDuration( 50 );
        //        bg.setDuration( resId.length * 25 );
        bg.setDuration( 1000 );
        
        // Eliminate any infinite loops caused by solving
        // special tiles withing a special call
        image.specialItem = -1;
        image.setState( BoardTile.SPECIAL_ANIMATE );
        image.setTag( bg );
        
        // Save the player some time
        if ( timer != null )
        {
            timer.resume();
        }
*/
    }
    
    
    /**
     * //###############################
     * <p>
     * Shuffles all tiles on the board.
     * All tiles spring to one location
     * in the air
     * then fall to a new location
     * <p>
     * //###############################
     */
    public void useShuffler( BoardTile image )
    {
/*
        int       shuffleCount = 0;
        int       index        = 0;
        BoardTile tile;
        boolean   activeTiles  = false;
        
        
        //###############################################
        // NEED TO GIVE PLAYER BACK SPECIALS AFTER
        // SHUFFLE
        // Take this opportunity to save any specials
        //###############################################
        for ( int y = 0; y < boardTiles.size(); y++ )
        {
            tile = boardTiles.get( y );
            
            if ( tile.tileNum != -1 )
            {
                activeTiles = true;
                if ( tile.specialItem >= 2 )
                {
                    // Save that shit
                    gameEngine.savedSpecials.add( new PointXYZ( tile.getPosition(), tile.tileNum, tile.specialItem, tile.specialTile ) );
                }
            }
        }
        
        
        // No need staying if nothing is active
        if ( !activeTiles )
        {
            return;
        }
        
        //#############################################
        //
        //  FIX THE DAMN SHUFFLER AND OTHER BUTTON ISSUES
        //
        //#############################################
        while ( shuffleCount < 4 )
        {
            // Build the main board
            // Animate the coins falling and bouncing into place
            for ( int y = 0; y < mapHeight; y++ )
            {
                for ( int x = 0; x < mapWidth; x++ )
                {
                    tile = boardTiles.get( y * mapWidth + x );
                    
                    if ( tile.tileNum != -1 )
                    {
                        // Keep the player's specials
                        int maxLoops = 0;
                        index = r.nextInt( maxColors );
                        //
                        while ( gameBoard.DuplicateAt( x, y, index ) && maxLoops < 50 )
                        {
                            index = r.nextInt( maxColors );
                            maxLoops++;
                        }
                        
                        // Assign a color to the new tile
                        tile.tileNum = index;
                        tile.specialItem = 0;
                        
                        // Announce it's presence
                        tile.setState( BoardTile.ANNOUNCE_PRESENCE );
                        //@@@@@@@@@@@@@@@@@@@@
                        tile.setSoundEfx( -2 );
                    }
                }
            }
            
            // Make sure the board has solvable tiles
            if ( checkIfMatchesExist( true, true ) || gameEngine.savedSpecials.size() > 0 )
            {
                break;
            }
            //
            shuffleCount++;
        }
        
        
        // If the above fails, give the player a SPARK special for there troubles!
        if ( shuffleCount > 3 )
        {
            Random r = new Random( 412837465 );
            int    i;
            
            i = r.nextInt( boardTiles.size() );
            while ( boardTiles.get( i ).tileNum == -1 || boardTiles.get( i ).tileNum >= BoardTile.CLOCK )
            {
                i = r.nextInt( boardTiles.size() );
            }
            
            //
            hintTile = new Point( i, -1 );
            boardTiles.get( i ).tileNum = BoardTile.SPARK;
            boardTiles.get( i ).specialItem = 2;
            boardTiles.get( i ).specialTile = -1;
        }
        
        //####################################
        //
        // Any special carrying over from
        // last board?
        //
        //####################################
        for ( int i = 0; i < gameEngine.savedSpecials.size(); i++ )
        {
            PointXYZ c = gameEngine.savedSpecials.get( i );
            tile = boardTiles.get( c.x );
            
            //
            if ( tile.tileNum != -1 )
            {
                if ( tile.tileNum < BoardTile.CLOCK )
                {
                    tile.tileNum = c.y;
                    tile.specialItem = c.z;
                    tile.specialTile = ( int ) c.degree;
                }
                else
                {
                    int next = r.nextInt( boardTiles.size() );
                    tile = boardTiles.get( next );
                    
                    //
                    while ( tile.tileNum == -1 || boardTiles.get( next ).tileNum >= BoardTile.CLOCK )
                    {
                        next = r.nextInt( boardTiles.size() );
                        tile = boardTiles.get( next );
                    }
                    
                    //
                    tile.tileNum = c.y;
                    tile.specialItem = c.z;
                    tile.specialTile = ( int ) c.degree;
                }
                
                // Announce it's presence
                tile.setState( BoardTile.ANNOUNCE_PRESENCE );
                //@@@@@@@@@@@@@@@@@@@@
                tile.setSoundEfx( -2 );
            }
        }
        
        
        //#################################
        //
        //
        //#################################
        if ( image != null )
        {
            ObjectAnimator bg;
            int[]          resId = gameEngine.arrayFromResource( R.array.laser_beam );
            
            bg = ObjectAnimator.ofFloat( image, "rotation", 0, 1080 );
            bg.setInterpolator( new AccelerateInterpolator() );
            
            image.specialItem = -1;
            image.setState( BoardTile.SPECIAL_ANIMATE );
            image.setTag( bg );
        }
        
        // No longer required
        gameEngine.savedSpecials.clear();
        
        if ( gameEngine.soundPlayer != null && !inHelper )
        {
            gameEngine.soundPlayer.playBgSfx( PlaySound.SPECIAL_CREATED );
        }
        // Display the changes
        onUpdateGrid();
*/
    }
    
    
    /**
     * //###############################
     * <p>
     * Does a random special from the
     * currently supported specials
     * Or it can give the play a 3
     * free spins on the slot machine!
     * <p>
     * //###############################
     */
    private void useRandom( final BoardTile image )
    {
        SecureRandom r = new SecureRandom();
        
        // Random special Sound
        if ( gameEngine.soundPlayer != null && !inHelper )
        {
            gameEngine.soundPlayer.playBgSfx( PlaySound.RANDOM_SPECIAL );
        }
        
        switch ( r.nextInt( 7 ) )
        {
            case 1:
                useABolt( image );
                break;
            case 2:
                useAStar( image );
                break;
            case 3:
                useSpark( image );
                break;
            case 5:
                useChargeBeam( image );
                break;
            case 6:
                useShuffler( image );
                break;
            case 0:
            default:
                useABomb( image, 0 );
                break;
        }
    }
    
    
    /**
     * //###############################
     * <p>
     * Capture recursive specials
     * <p>
     * //###############################
     */
    public void captureMoreBombs( ArrayList<Integer> specials, int delay )
    {
        // Check for recursive special calls
        for ( int i = 0; i < specials.size(); i++ )
        {
            BoardTile image = boardTiles.get( specials.get( i ) );
            
            // Recursive call
            if ( image.tileNum == BoardTile.BOMB )
            {
                // Classify this as a "caught" special so an extra
                // Thread call is NOT made
                image.isCaught = true;
                useABomb( image, delay );
                // Must init the "caught" specials
                if ( image.getTag() != null )
                {
                    animatorHelper( image.getPosition() );
                }
            }
        }
    }
    
    
    @Override
    protected void onDetachedFromWindow()
    {
        mainView = null;
        gameBoard = null;
        gameEngine = null;
        
        // Kill the thread
        if ( logicThread != null )
        {
            //            logicThread.killThread();
            logicThread = null;
        }
        //
        
        boardTiles = null;
        targetViews = null;
        tilePoints = null;
        coinSet = null;
        coinBg = null;
        glowColors = null;
        
        boardMap = null;
        matchList = null;
        
        specials = null;
        onGridUpdateListener = null;
        onBoosterListener = null;
        
        r = null;
        timer = null;
        linearGradient = null;
        lineBuffer = null;
        bufCanvas = null;
        tileTypes = null;
        
        super.onDetachedFromWindow();
    }
}



/*
        float[] cMatrix = {
                .50f, 0, 0, 0, 0, //red
                0, .50f, 0, 0, 0, //green
                0, 0, .50f, 0, 0, //blue
                0, 0, 0, 1, 0     //alpha
        };
        
*//*

        final ColorMatrix            colorMatrix = new ColorMatrix( cMatrix );
        final ColorMatrixColorFilter cmcf        = new ColorMatrixColorFilter( colorMatrix );
        
        
        // Don't even bother if in helper mode
        if ( inHelper )
        {
            return false;
        }
        
        if ( !canTouch )
        {
            return false;
        }
        
        //#############################
        //
        // Player setting a booster??
        //
        //#############################
        if ( boosterItem != -1 )
        {
            int location;
            
            pressed.x = ( int ) event.getX();
            pressed.y = ( int ) event.getY();
            location = ((pressed.y / size) * getColumnCount()) + (pressed.x / size);
            
            // Do not touch outside of the grid
            // Must be a valid tile
            if ( location >= boardTiles.size() || boardTiles.get( location ).tileNum < 0 || boardTiles.get( location ).specialItem == 3 )
            {
                if ( gameEngine.soundPlayer != null )
                {
                    //@@@@@@@@@@@@@@@@@@@@
                    gameEngine.soundPlayer.play( PlaySound.INVALID );
                }
                
                return false;
            }
            
            // Reset it
            boosterItem = -1;
            
            // We have a good one
            onBoosterListener.boosterLocationSet( location );
            
            return false;
        }
        
        
        //
*/
/*
        int              DIV_NUM         = 2;
        int              TOUCH_NUM       = 3;
        LinearLayout     matchHintLayout = mainView.findViewById( R.id.matchHintLayout );
        ImageView        matchHintIcon   = mainView.findViewById( R.id.matchHintIcon );
        GradientTextView matchHintText   = mainView.findViewById( R.id.matchHintText );
        int[] iconList = {
                R.drawable.clock_1, R.drawable.bomb_1, R.drawable.star_1,         //
                R.drawable.bolt_1, R.drawable.spark_1, R.drawable.charge_beam_1,  //
                R.drawable.question_mark_1, R.drawable.shuffle
        };
*//*

        
        // All touches resets the counter
        logicThread.setHintTimer( CustomTimer.currentTime );
        
        // No touching when the board is not active
        if ( CustomTimer.timerStatus != CustomTimer.TIMER_RUNNING || logicThread.getCurrentCmd() != LogicThread.CMD_IDLE || logicThread.animationsRunning > 0 )
        {
            return false;
        }
        
        
        //##########################################
        //
        // Do not allow touching if targets are all
        // clear
        // Test ONLY if first contact being made
        //
        //##########################################
        if ( tilePoints.size() == 0 )
        {
            int count = 0;
            for ( TextView view : targetViews )
            {
                if ( view.getTag() != null )
                {
                    count += (( PointXYZ ) view.getTag()).x;
                }
            }
            
            //
            if ( count <= 0 && (ConnectionsFragment.levelScore >= gameBoard.neededPoints)*/
/* && gemsToMatch.size() == 0*//*
 )
            {
                return false;
            }
        }
        
        
        //##########################################
        //
        //
        //
        //##########################################
        if ( event.getActionMasked() == MotionEvent.ACTION_UP )
        {
            boolean canMatch = false;
            
            wentback = false;
            
            // All touches resets the counter
            logicThread.setHintTimer( CustomTimer.currentTime );
            
            // Only cases where we can match coins
            if ( tilePoints.size() > 2 || (tilePoints.size() == 2 && matchColor > BoardTile.MAX_COINS) )
            {
                canMatch = true;
            }
            
            //
            // Clean up the board
            //
            for ( int i = 0; i < tilePoints.size(); i++ )
            {
                BoardTile tile = boardTiles.get( tilePoints.get( i ).z );
                
                if ( tile.tileNum > -1 )
                {
                    tile.endAnimation();
                    tile.setImageResource( coinSet[ tile.tileNum ][ 0 ] );
                }
                
                if ( canMatch )
                {
                    if ( matchColor <= BoardTile.MAX_COINS || tile.tileNum > BoardTile.MAX_COINS )
                    {
                        matchList[ tile.getTileY() ][ tile.getTileX() ] = 0;
                    }
                }
            }
            
            
            //#############################
            //
            // Un-dim all coins now
            //
            //#############################
            for ( BoardTile tile : boardTiles )
            {
                if ( tile.getState() != BoardTile.STATE_INACTIVE )
                {
                    tile.pointPosi = -1;
                    tile.clearColorFilter();
                }
            }
            
            //
            // Any matches?
            //
            if ( canMatch )
            {
                //                canDrawLines = false;
                boardMoves++;
                
                // If we have a special, create it!
                if ( tilePoints.size() >= MIN_FOR_SPECIAL )
                {
                    if ( (CustomTimer.currentTime / 1000) > 45 && tilePoints.size() == MIN_FOR_SPECIAL )
                    {
                        // Clock isn't enabled yet
                        logicThread.addToStack( LogicThread.CMD_PROCESS_MATCHES );
                    }
                    else
                    {
                        // Check to make sure we can create one
                        int index = Math.min( (tilePoints.size() - MIN_FOR_SPECIAL), (MAX_FOR_SPECIAL - MIN_FOR_SPECIAL) );
                        int type  = handleSpecialAllow( index );
                        
                        if ( type == 0 )
                        {
                            logicThread.addToStack( LogicThread.CMD_CREATE_SPECIALS );
                        }
                        else if ( type == 1 )
                        {
                            // Give to the player
                            logicThread.addToStack( LogicThread.CMD_GIVE_SPECIAL );
                        }
                        else
                        {
                            // Do not create
                            logicThread.addToStack( LogicThread.CMD_PROCESS_MATCHES );
                        }
                    }
                }
                else
                {
                    logicThread.addToStack( LogicThread.CMD_PROCESS_MATCHES );
                }
                
                //
                canTouch = false;
            }
            else
            {
                tilePoints.clear();
                //                invalidate();
            }
            
            // Hide the coin counter bubble
            matchHintLayout.setVisibility( INVISIBLE );
            matchHintIcon.setVisibility( GONE );
            
            //
            lineBuffer.eraseColor( Color.TRANSPARENT );
            invalidate();
        }
        //##################################
        //
        // Pointer has pressed screen
        //
        //##################################
        else if ( event.getActionMasked() == MotionEvent.ACTION_DOWN )
        {
            int       position;
            BoardTile tile;
            
            pressed.x = ( int ) event.getX();
            pressed.y = ( int ) event.getY();
            position = ((pressed.y / size) * getColumnCount()) + (pressed.x / size);
            
            // Do not touch outside of the grid
            if ( position >= boardTiles.size() )
            {
                return true;
            }
            
            //###################################
            // Get the position of the tile
            // under the players finger
            // Is it a valid tile?
            //###################################
            tile = boardTiles.get( position );
            
            if ( tile.tileNum < 0 )
            {
                return false;
            }
            
            
            // Clear the points buffer.
            // Used to track where the selected coins are active
            lineBuffer.eraseColor( Color.TRANSPARENT );
            tilePoints.clear();
            invalidate();
            
            // Specials or standard icons
            matchColor = boardTiles.get( position ).tileNum;
            
            // Set Pressed state
            if ( matchColor >= BoardTile.MAX_COINS )
            {
                if ( matchColor == BoardTile.CLOCK )
                {
                    matchColor = tile.specialTile;
                    matchHintText.setText( String.format( Locale.getDefault(), " %d ", tilePoints.size() + 1 ) );
                    
                    // Coin sound
                    if ( gameEngine.soundPlayer != null )
                    {
                        gameEngine.soundPlayer.play( PlaySound.COIN );
                    }
                }
                else
                {
                    // Keep the name of the special displayed
                    //                    matchHintText.setText( itemNames[ (matchColor - BoardTile.CLOCK) % itemNames.length ] );
                    matchHintText.setText( itemNames[ matchColor ] );
                    // Specials sound
                    if ( gameEngine.soundPlayer != null )
                    {
                        gameEngine.soundPlayer.play( PlaySound.SPECIAL_TOUCH );
                    }
                }
                
                //
                tile.spinCoin();
                
                // Do not show the counter box if not wanted
                if ( (GameEngine.systemFlags & GameEngine.MATCH_NUM_OFF) != GameEngine.MATCH_NUM_OFF )
                {
                    matchHintLayout.setVisibility( VISIBLE );
                    moveTheCursor( tile, matchHintLayout, false );
                }
            }
            else
            {
                //                boardTiles.get( position ).growCoin();
                tile.spinCoin();
                //                boardTiles.get( position ).flipCoin();
                matchHintText.setText( String.format( Locale.getDefault(), " %d ", tilePoints.size() + 1 ) );
                
                // Do not show the counter box if not wanted
                if ( (GameEngine.systemFlags & GameEngine.MATCH_NUM_OFF) != GameEngine.MATCH_NUM_OFF )
                {
                    matchHintLayout.setVisibility( VISIBLE );
                    moveTheCursor( tile, matchHintLayout, false );
                }
                
                // Coin sound
                if ( gameEngine.soundPlayer != null )
                {
                    gameEngine.soundPlayer.play( PlaySound.COIN );
                }
            }
            
            
            //#################################
            //
            // Dim all coins now. Leave like
            // coins as is
            //
            //#################################
            for ( BoardTile t : boardTiles )
            {
                if ( t.getState() != BoardTile.STATE_INACTIVE )
                {
                    if ( (t.specialItem > 1 && t.tileNum == tile.tileNum) || t.tileNum != tile.tileNum )
                    {
                        t.setColorFilter( cmcf );
                    }
                }
            }
            
            //
            tile.clearColorFilter();
            tile.pointPosi = 0;
            
            //
            pressed = new PointXYZ( ((pressed.x / size) * size) + (size / DIV_NUM), ((pressed.y / size) * size) + (size / DIV_NUM), position );
            tilePoints.add( pressed );
            //            moveTheCursor( tile, matchHintLayout, false );
            
            //
            return true;
        }
        //##################################
        //
        // Pointer is moving
        //
        //##################################
        else if ( event.getActionMasked() == MotionEvent.ACTION_MOVE )
        {
            PointXYZ test = new PointXYZ( ( int ) event.getX(), ( int ) event.getY() );
            PointXYZ next = new PointXYZ( test );
            // Offset the touch zone to allow for better diagonal movement between tiles
            int       bound = (size / TOUCH_NUM);
            BoardTile tile;
            BoardTile selected;
            int       position;
            int       x     = next.x / size;
            int       y     = next.y / size;
            
            
            // Make sure this tile is valid
            if ( x < 0 || x >= getColumnCount() || y < 0 || y > getRowCount() )
            {
                return true;
            }
            
            //
            position = ((next.y / size) * getColumnCount()) + (next.x / size);
            
            // Do not touch outside of the grid
            if ( position >= boardTiles.size() || matchColor >= BoardTile.RED_GEM )
            {
                return true;
            }
            
            // Get the tile
            tile = boardTiles.get( position );
            
            // No touching Gems at all if already selected!
            if ( tile.tileNum < 0 || tile.tileNum >= BoardTile.RED_GEM )
            {
                return true;
            }
            
            //####################################
            // If special selected, no touching
            // another special.
            // Only touch original
            //####################################
            if ( (matchColor > BoardTile.CLOCK && tile.tileNum > BoardTile.CLOCK) )
            {
                if ( tilePoints.get( 0 ).z != tile.getPosition() )
                {
                    return true;
                }
            }
            
            
            //#########################################
            //
            // Get the current tile under the pointer
            //
            //#########################################
            next = new PointXYZ( ((next.x / size) * size) + (size / DIV_NUM), ((next.y / size) * size) + (size / DIV_NUM) );
            selected = boardTiles.get( (next.y / size) * getColumnCount() + (next.x / size) );
            
            
            // Make sure it's within a touchable point
            // for a new tile: X
            if ( test.x < (next.x - bound) || test.x > (next.x + bound) )
            {
                return true;
            }
            // tile: Y
            if ( test.y < (next.y - bound) || test.y > (next.y + bound) )
            {
                return true;
            }
            
            
            //##################################
            //
            // Can't be the same tile
            // That is being tested against
            //
            //##################################
*/
/*
            if ( next.x == pressed.x && pressed.y == next.y )
            {
                // For removal of special attachments
                if ( matchColor > BoardTile.MAX_COINS && tilePoints.size() == 2 )
                {
                    // Un-spin
                    position = tilePoints.get( 1 ).z;
                    tile = boardTiles.get( position );
                    
                    //
                    tile.endAnimation();
                    tile.setImageResource( coinSet[ tile.tileNum ][ 0 ] );
                    //
                    tilePoints.remove( 1 );
                    
                    // Dim it again
                    tile.clearColorFilter();
                    tile.cardFlipped = false;
                    tile.pointPosi = -1;
                    
                    
                    // Keep the name of the special displayed
                    //                    matchHintText.setText( itemNames[ (matchColor - BoardTile.CLOCK) % itemNames.length ] );
                    matchHintText.setText( itemNames[ matchColor ] );
                    
                    // Play SFX
                    if ( gameEngine.soundPlayer != null )
                    {
                        gameEngine.soundPlayer.play( PlaySound.COIN_REVERSE );
                    }
                    
                    position = tilePoints.get( 0 ).z;
                    tile = boardTiles.get( position );
                    moveTheCursor( tile, matchHintLayout, true );
                    
                    // Show the lines
                    invalidate();
                }
                
                return true;
            }
*//*

            
            
            //#####################################
            //
            // We have a new tile to test against
            //
            //#####################################s
            PointXYZ end;
            PointXYZ start;
            
            if ( selected.pointPosi != -1 )
            {
                // Tile already exist
                // Test to see if it was the previous tile ( going backwards )
                // remove the CURRENT "pressed" tile if true
                int i = selected.pointPosi;
                
                if ( i == (tilePoints.size() - 2) )
                {
                    // De-select the tile
                    selected.pointPosi = -1;
                    
                    wentback = true;
                    
                    
                    //
                    test = tilePoints.get( tilePoints.size() - 1 );
                    position = ((test.y / size) * getRowCount()) + (test.x / size);
                    //                    position = selected.getPosition();
                    
                    tile = boardTiles.get( position );
                    
                    // Dim it again
                    tile.clearColorFilter();
                    
                    //
                    tile.endAnimation();
                    tile.setImageResource( coinSet[ tile.tileNum ][ 0 ] );
                    
                    // Remove the line from the screen
                    // Get the line we wish to erase
                    start = tilePoints.get( tilePoints.size() - 2 );
                    end = tilePoints.get( tilePoints.size() - 1 );
                    
                    // Set paint to draw transparent line
                    Xfermode mode = subPaint.getXfermode();
                    subPaint.setXfermode( new PorterDuffXfermode( PorterDuff.Mode.CLEAR ) );
                    
                    // clear the line
                    bufCanvas.drawLine( start.x, start.y, end.x, end.y, subPaint );
                    
                    // Restore normal drawing
                    subPaint.setXfermode( mode );
                    
                    // Remove the line from the list
                    tilePoints.remove( tilePoints.size() - 1 );
                    pressed = new PointXYZ( tilePoints.get( tilePoints.size() - 1 ) );
                    
                    // Play SFX
                    if ( gameEngine.soundPlayer != null )
                    {
                        gameEngine.soundPlayer.play( PlaySound.COIN_REVERSE );
                    }
                    
                    // Update the counter bubble
                    matchHintText.setText( String.format( Locale.getDefault(), "%d", tilePoints.size() ) );
                    
                    // Show the lines
                    invalidate();
                    
                    // No need to show an icon
                    if ( tilePoints.size() >= MIN_FOR_SPECIAL )
                    {
                        int index = Math.min( (tilePoints.size() - MIN_FOR_SPECIAL), (MAX_FOR_SPECIAL - MIN_FOR_SPECIAL) );
                        
                        if ( handleSpecialAllow( index ) > -1 )
                        {
                            matchHintIcon.setVisibility( VISIBLE );
                            matchHintIcon.setImageResource( iconList[ index ] );
                        }
                        else
                        {
                            matchHintIcon.setVisibility( GONE );
                            matchHintIcon.setImageResource( 0 );
                        }
                    }
                    else
                    {
                        matchHintIcon.setVisibility( GONE );
                        matchHintIcon.setImageResource( 0 );
                    }
                    
                    // Animate the cursor to new location
                    moveTheCursor( boardTiles.get( tilePoints.get( i ).z ), matchHintLayout, true );
                }
                
                //
                return false;
            }
            else
            {
                test = tilePoints.get( tilePoints.size() - 1 );
            }

            
*/
/*
            for ( int i = 0; i < tilePoints.size(); i++ )
            {
                // Make sure we have not touched this tile yet
                test = tilePoints.get( i );
                //
                if ( test.x == next.x && test.y == next.y )
                {
                    // Tile already exist
                    // Test to see if it was the previous tile ( going backwards )
                    // remove the CURRENT "pressed" tile if true
                    if ( i == (tilePoints.size() - 2) )
                    {
                        // Un-spin
                        test = tilePoints.get( tilePoints.size() - 1 );
                        position = ((test.y / size) * getRowCount()) + (test.x / size);
                        tile = boardTiles.get( position );
                        
                        // Dim it again
                        //                        tile.setColorFilter( dimmer, PorterDuff.Mode.DARKEN );
                        tile.clearColorFilter();
                        
                        //
                        tile.endAnimation();
                        tile.setImageResource( coinSet[ tile.tileNum ][ 0 ] );
                        
                        // Remove the line from the screen
                        // Get the line we wish to erase
                        start = tilePoints.get( tilePoints.size() - 2 );
                        end = tilePoints.get( tilePoints.size() - 1 );
                        
                        // Set paint to draw transparent line
                        Xfermode mode = subPaint.getXfermode();
                        subPaint.setXfermode( new PorterDuffXfermode( PorterDuff.Mode.CLEAR ) );
                        
                        // clear the line
                        bufCanvas.drawLine( start.x, start.y, end.x, end.y, subPaint );
                        
                        // Restore normal drawing
                        subPaint.setXfermode( mode );
                        
                        // Remove the line from the list
                        tilePoints.remove( tilePoints.size() - 1 );
                        pressed = new PointXYZ( tilePoints.get( tilePoints.size() - 1 ) );
                        
                        // Play SFX
                        if ( gameEngine.soundPlayer != null )
                        {
                            gameEngine.soundPlayer.play( PlaySound.COIN_REVERSE );
                        }
                        
                        
                        if ( matchColor >= BoardTile.MAX_COINS )
                        {
                            // Keep the name of the special displayed
                            //                    matchHintText.setText( itemNames[ (matchColor - BoardTile.CLOCK) % itemNames.length ] );
                            matchHintText.setText( itemNames[ matchColor ] );
                        }
                        else
                        {
                            // Update the counter bubble
                            matchHintText.setText( String.format( Locale.getDefault(), "%d", tilePoints.size() ) );
                        }
                        
                        // Show the lines
                        invalidate();
                        
                        // No need to show an icon
                        if ( tilePoints.size() >= MIN_FOR_SPECIAL )
                        {
                            int index = Math.min( (tilePoints.size() - MIN_FOR_SPECIAL), (MAX_FOR_SPECIAL - MIN_FOR_SPECIAL) );
                            
                            if ( handleSpecialAllow( index ) > -1 )
                            {
                                matchHintIcon.setVisibility( VISIBLE );
                                matchHintIcon.setImageResource( iconList[ index ] );
                            }
                            else
                            {
                                matchHintIcon.setVisibility( GONE );
                                matchHintIcon.setImageResource( 0 );
                            }
                        }
                        else
                        {
                            matchHintIcon.setVisibility( GONE );
                            matchHintIcon.setImageResource( 0 );
                        }
                        
                        // Animate the cursor to new location
                        moveTheCursor( boardTiles.get( tilePoints.get( i ).z ), matchHintLayout, true );
                    }
                    
                    //
                    return true;
                }
            }
*//*

            
            
            //##################################
            //
            // First test passed! Now see if the
            // color and positions are good
            //
            //##################################
            float xDist  = (next.x - test.x);
            float yDist  = (next.y - test.y);
            int   length = ( int ) Math.sqrt( (xDist * xDist) + (yDist * yDist) );
            
            //
            position = ((next.y / size) * getColumnCount()) + (next.x / size);
            tile = boardTiles.get( position );
            
            
            //################################
            //
            // We have a match!
            //
            //################################
            if ( matchColor == BoardTile.CLOCK )
            {
                matchColor = boardTiles.get( position ).specialTile;
            }
            
            //
            if ( (length == distances[ 0 ] || length == distances[ 1 ]) && matchColor <= BoardTile.MAX_COINS && ((tile.tileNum == matchColor) || (tile.tileNum == BoardTile.CLOCK && tile.specialTile == matchColor)) )
            {
                // All test passed
                // Add current tile's position
                // This test includes CLOCK
                next.z = position;
                pressed = new PointXYZ( next );
                // Set card as touched mode
                tile.pointPosi = tilePoints.size();
                
                //
                tilePoints.add( next );
                
                //boardTiles.get( position ).growCoin();
                
*/
/*
                if ( tile.tileNum == BoardTile.CLOCK )
                {
                    tile.spinCoin();
                }
                else
                {
                    //                    boardTiles.get( position ).flipCoin();
                    tile.spinCoin();
                }
                
*//*

                //                if ( tilePoints.size() > 2 )
                if ( tilePoints.size() > 1 )
                {
                    start = tilePoints.get( tilePoints.size() - 2 );
                    end = tilePoints.get( tilePoints.size() - 1 );
                    
                    //
                    bufCanvas.drawLine( start.x, start.y, end.x, end.y, subPaint );
                    bufCanvas.drawLine( start.x, start.y, end.x, end.y, paint );
                    
                    // Keep the name of the special displayed
                    matchHintText.setText( String.format( Locale.getDefault(), " %d ", tilePoints.size() ) );
                    
                    // No need to show an icon
                    if ( tilePoints.size() >= ConnectionsGridLayout.MIN_FOR_SPECIAL )
                    {
                        int index = Math.min( (tilePoints.size() - MIN_FOR_SPECIAL), (MAX_FOR_SPECIAL - MIN_FOR_SPECIAL) );
                        
                        if ( handleSpecialAllow( index ) > -1 )
                        {
                            if ( index > 0 )
                            {
                                invalidate();
                            }
                            
                            matchHintIcon.setVisibility( VISIBLE );
                            matchHintIcon.setImageResource( iconList[ index ] );
                        }
                        else
                        {
                            matchHintIcon.setVisibility( GONE );
                            matchHintIcon.setImageResource( 0 );
                        }
                    }
                    else
                    {
                        matchHintIcon.setVisibility( GONE );
                        matchHintIcon.setImageResource( 0 );
                    }
                    
                    // Show the lines
                    invalidate();
                }
                
                // Play SFX
                if ( gameEngine.soundPlayer != null )
                {
                    gameEngine.soundPlayer.play( PlaySound.COIN );
                }
                
                // Un-Dim it
                tile.clearColorFilter();
                
                // Animate the cursor to new location
                moveTheCursor( tile, matchHintLayout, true );
                
                return true;
            }
            //################################
            //
            // Support for specials
            //
            //################################
            else if ( (length == distances[ 0 ] || length == distances[ 1 ]) && matchColor > BoardTile.MAX_COINS && tilePoints.size() < 2 )
            {
                // All test passed
                // Add current tile's position
                next.z = position;
                
                // Set card as touched mode
                tile.pointPosi = tilePoints.size();
                
                //
                tilePoints.add( next );
                
                //                tile.pulsateCoin();
                tile.spinCoin();
                
                // Play SFX
                if ( gameEngine.soundPlayer != null )
                {
                    gameEngine.soundPlayer.play( PlaySound.COIN );
                }
                
                // Un-Dim it
                tile.clearColorFilter();
                
                // Get the swiping direction
                boardTiles.get( pressed.z ).swipeDirection = getDirection( pressed, next );
                // Animate the cursor to new location
                moveTheCursor( boardTiles.get( next.z ), matchHintLayout, true );
                
                return true;
            }
        }
*/
