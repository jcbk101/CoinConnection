package com.genesyseast.coinconnection.PlaySound;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Point;
import android.icu.text.DateTimePatternGenerator;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.net.Uri;
import android.os.Build;
import android.util.Log;

import com.genesyseast.coinconnection.GameEngine.GameEngine;
import com.genesyseast.coinconnection.R;
import com.google.android.exoplayer2.SimpleExoPlayer;

import java.util.ArrayList;

public class PlaySound
        implements SoundPool.OnLoadCompleteListener, MediaPlayer.OnErrorListener
{
    implements ExoPlayer.EventListener
    
    public static final int BOMB_EXPAND                          = 0;
    public static final int BOMB_SPECIAL                         = 1;
    public static final int BUTTON_CLICK                         = 2;
    public static final int CHARGE_BEAM_PART_1                   = 3;
    public static final int CHARGE_BEAM_PART_2                   = 4;
    public static final int CHARGE_BEAM_SPECIAL                  = 5;
    public static final int COIN                                 = 6;
    public static final int COIN_MATCH                           = 7;
    public static final int COIN_REVERSE                         = 8;
    public static final int DIALOG_CLICK                         = 9;
    public static final int ERROR                                = 10;
    public static final int INVALID                              = 11;
    public static final int LEVEL_COMPLETE_PART_1                = 12;
    public static final int LEVEL_COMPLETE_PART_2                = 13;
    public static final int LEVEL_FAIL                           = 14;
    public static final int LEVEL_SELECT                         = 15;
    public static final int LIGHTNING_SPECIAL                    = 16;
    public static final int LOGO_REVEAL                          = 17;
    public static final int PAUSE_GAME                           = 18;
    public static final int POINTS_ADD                           = 19;
    public static final int POINTS_ADD_LOOP                      = 20;
    public static final int POP                                  = 21;
    public static final int QUIT_GAME                            = 22;
    public static final int RANDOM_SPECIAL                       = 23;
    public static final int REEL_STOP_1                          = 24;
    public static final int REEL_STOP_2                          = 25;
    public static final int REEL_STOP_WIN_3                      = 26;
    public static final int SLOT_ARM                             = 27;
    public static final int SLOTS_FREE_SPINS                     = 28;
    public static final int SLOTS_LOSE_GAME                      = 29;
    public static final int SLOTS_PRIZE_ADD                      = 30;
    public static final int SLOTS_REEL_TICK                      = 31;
    public static final int SLOTS_WIN_GAME                       = 32;
    public static final int SPARK_SPECIAL                        = 33;
    public static final int SPECIAL_CREATED                      = 34;
    public static final int SPECIAL_MATCHED                      = 35;
    public static final int SPECIAL_TOUCH                        = 36;
    public static final int STAR_LEVEL_UP                        = 37;
    public static final int STAR_SHOOT                           = 38;
    public static final int START_GAME                           = 39;
    public static final int TOAST_ALERT                          = 40;
    public static final int UNPAUSE_GAME                         = 41;
    //
    public static final int BEACH_BG_SWINGING_SWEET              = 0;
    public static final int FAIRYTALE_BG_HAPPY_LULLABLY          = 1;
    public static final int FOREST_BG_MYSTERIOUS_AMBIENCE_SONG21 = 2;
    public static final int HALLOWEEN_BG_CREEP                   = 3;
    public static final int NIGHTTIME_BG_EMOTIONAL_DELUGE        = 4;
    public static final int OCEAN_BG_BLUE_MEADOW_IN_GREEN_SKY    = 5;
    public static final int WINTER_BG_WINTER_DUST                = 6;
    public static final int GAME_COMPLETE_BG_HAPPY_ADVETURE      = 7;
    public static final int MENU_BG_GONE_FISHIN_BY_MEMORAPHILE   = 8;
    public static final int SLOTS_BG_SOMEWHERE_IN_THE_ELEVATOR   = 9;
    
    //
    public static final int PLAY = 0;
    public static final int LOOP = 1;
    public static final int STOP = -1;
    
    
    private       int                    maxStreams;
    public        int[]                  soundEffects;
    public        int[]                  allSounds;
    public        int[]                  bgMusic;
    private       Context                context;
    public static int                    currentSoundList = 0;
    private       int                    soundsLoaded     = 0;
    private       int                    maxSounds        = 0;
    private       SoundPool[]            soundPool;
    private       MediaPlayer            sfx;
    public        MediaPlayer            music;
    public        int                    soundPoolcount   = 0;
    private       int                    SOUNDS_PER_POOL  = 5;
    private       OnSoundsLoadedListener onSoundsLoadedListener;
    private       ArrayList<MediaPlayer> mediaList;
    private       int                    errorsCaused     = 0;
    
    // ExoPlayer
    private SimpleExoPlayer player;
    
    
    
    
    /**
     * Listener interface
     */
    public interface OnSoundsLoadedListener
    {
        void onSoundsLoaded();
    }
    
    /**
     * Main constructor
     */
    public PlaySound( Context context, int maxStreams )
    {
        this.context = context;
        this.maxStreams = maxStreams;
        this.soundEffects = null;
        
/*
        //
        if ( Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP )
        {
            AudioAttributes audioAttributes;
            audioAttributes = new AudioAttributes.Builder().setUsage( AudioAttributes.USAGE_MEDIA )
                                                           .setContentType( AudioAttributes.CONTENT_TYPE_MUSIC )
                                                           .build();
            //
            soundPool = new SoundPool.Builder().setMaxStreams( maxStreams ).setAudioAttributes( audioAttributes ).build();
        }
        else
        {
            soundPool = new SoundPool( maxStreams, AudioManager.STREAM_MUSIC, 0 );
        }
*/
        
        //
        soundsLoaded = 0;
        
        //
        player = new SimpleExoPlayer.Builder( context).build();
        
        //
        mediaList = new ArrayList<>();
    }
    
    
    /**
     * Second constructor
     *
     * @param maxStreams
     * @param soundEfx
     */
    public PlaySound( Context context, int maxStreams, int soundEfx )
    {
        this.context = context;
        this.maxStreams = maxStreams;
        
/*
        //
        if ( Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP )
        {
            AudioAttributes audioAttributes;
            audioAttributes = new AudioAttributes.Builder().setUsage( AudioAttributes.USAGE_MEDIA )
                                                           .setContentType( AudioAttributes.CONTENT_TYPE_MUSIC )
                                                           .build();
            //
            soundPool = new SoundPool.Builder().setMaxStreams( maxStreams ).setAudioAttributes( audioAttributes ).build();
        }
        else
        {
            soundPool = new SoundPool( maxStreams, AudioManager.STREAM_MUSIC, 0 );
        }
*/
        //
        soundsLoaded = 0;
    
        //
        player = new SimpleExoPlayer.Builder( context).build();
        
        // load the files into memory
        setSounds( soundEfx );
        
        //
        mediaList = new ArrayList<>();
    }
    
    
    /**
     * Reset per new level
     */
    public void resetErrorsCaused()
    {
        this.errorsCaused = 0;
    }
    
    /**
     * Custom listener
     *
     * @param onSoundsLoadedListener
     */
    public void setOnSoundsLoadedListener( OnSoundsLoadedListener onSoundsLoadedListener )
    {
        this.onSoundsLoadedListener = onSoundsLoadedListener;
    }
    
    /**
     * Get the music play list
     *
     * @param musicList
     *
     * @return
     */
    public int setMusic( int musicList )
    {
        if ( musicList > 0 && context != null )
        {
            // Now load all the goodies
            TypedArray arrays;
            
            
            //############################
            // Map Sizes
            //############################
            arrays = context.getResources().obtainTypedArray( musicList );
            bgMusic = new int[ arrays.length() ];
            
            // Referrences to RAW sound files
            for ( int i = 0; i < arrays.length(); i++ )
            {
                this.bgMusic[ i ] = arrays.getResourceId( i, 0 );
            }
            
            arrays.recycle();
            
            
            return bgMusic.length;
        }
        
        return 0;
    }
    
    
    /**
     * Array of sound effects to load
     *
     * @param soundEfx
     */
    public int setSounds( int soundEfx )
    {
        if ( soundEfx > 0 && context != null )
        {
            // Now load all the goodies
            TypedArray arrays;
            
            if ( this.soundEffects != null && currentSoundList != soundEfx && soundPool != null )
            {
                for ( SoundPool s : soundPool )
                {
                    s.release();
                    s = null;
                }
                
                //
                soundPool = null;
                releaseAll();
            }
            
            
            //############################
            // Map Sizes
            //############################
            arrays = context.getResources().obtainTypedArray( soundEfx );
            soundEffects = new int[ arrays.length() ];
            allSounds = new int[ arrays.length() ];
            soundPoolcount = (arrays.length() / SOUNDS_PER_POOL) + 1;
            soundPool = new SoundPool[ soundPoolcount ];
            
            // Referrences to RAW sound files
            for ( int i = 0; i < arrays.length(); i++ )
            {
                this.soundEffects[ i ] = arrays.getResourceId( i, 0 );
                this.allSounds[ i ] = arrays.getResourceId( i, 0 );
            }
            
            // Create the instances of sound pool
            for ( int i = 0; i < soundPoolcount; i++ )
            {
                soundPool[ i ] = createSoundPool();
                soundPool[ i ].setOnLoadCompleteListener( this );
            }
            
            //
            for ( int y = 0; y < soundPoolcount; y++ )
            {
                for ( int i = 0; i < SOUNDS_PER_POOL; i++ )
                {
                    if ( (y * SOUNDS_PER_POOL) + i >= soundEffects.length )
                    {
                        break;
                    }
                    
                    // Max 4 Sounds per sound pool
                    soundEffects[ (y * SOUNDS_PER_POOL) + i ] = soundPool[ y ].load( context, soundEffects[ (y * SOUNDS_PER_POOL) + i ],
                                                                                     1
                                                                                   );
                }
            }
            //
            arrays.recycle();
            
            // Save for onPause(), onResume()
            currentSoundList = soundEfx;
            soundsLoaded = 0;
            
            //
            return (maxSounds = soundEffects.length);
        }
        
        return 0;
    }
    
    
    /**
     * Play the sound requested
     *
     * @param soundIndex
     */
    public int play( int soundIndex )
    {
        return play( soundIndex, PLAY, 0 );
    }
    
    
    /**
     * Play the sound requested
     *
     * @param soundIndex
     */
    public int play( int soundIndex, int soundType )
    {
        return play( soundIndex, soundType, 0 );
    }
    
    
    /**
     * Play the sound effect using SoundPool requested
     *
     * @param soundIndex
     */
    public int play( int soundIndex, int soundType, int streamId )
    {
        int retValue = soundIndex;
        
        if ( (GameEngine.systemFlags & GameEngine.SFX_OFF) == 0 && soundPool != null )
        {
            try
            {
                float volume     = ( float ) GameEngine.musicVolume / ( float ) GameEngine.maxVolume;
                int   fileIndex  = (soundIndex % SOUNDS_PER_POOL);
                int   groupIndex = (soundIndex / SOUNDS_PER_POOL);
                
                // We want Sound effects if BIT not set
                if ( soundType == LOOP )
                {
                    retValue = soundPool[ groupIndex ].play( soundEffects[ fileIndex ], volume, volume, 1, -1, 1f );
                }
                else if ( soundType == STOP )
                {
                    soundPool[ groupIndex ].stop( streamId );
                }
                else
                {
                    retValue = soundPool[ groupIndex ].play( soundEffects[ fileIndex ], volume, volume, 1, 0, 1 );
                }
                
                if ( retValue <= 0 )
                {
                    Log.d( "Error@@@@:", "-----===== Sound: " + soundIndex + " did not play =====-----" );
                }
            }
            catch ( Exception ex )
            {
                ex.getMessage();
            }
        }
        
        return retValue;
    }
    
    
    /**
     * Play background music
     *
     * @param soundIndex
     * @param soundType
     *
     * @return
     */
    public int playBgMusic( int soundIndex, int soundType )
    {
        if ( ((GameEngine.systemFlags & GameEngine.MUSIC_OFF) == 0 || soundType == STOP) && bgMusic != null )
        {
            try
            {
                if ( soundType == STOP )
                {
                    if ( music != null )
                    {
                        music.stop();
                        music.release();
                        GameEngine.musicIsPlaying = false;
                    }
                }
                else if ( soundType == LOOP )
                {
                    // All sounds are listed
                    music = MediaPlayer.create( context, bgMusic[ soundIndex ] );
                    music.setOnCompletionListener( mp -> {
                        mp.release();
                        GameEngine.musicIsPlaying = false;
                    } );
                    music.setOnErrorListener( this );
                    
                    music.setLooping( true );
                    music.start();
                    GameEngine.musicIsPlaying = true;
                }
                else
                {
                    music = MediaPlayer.create( context, bgMusic[ soundIndex ] );
                    music.setOnCompletionListener( mp -> {
                        mp.release();
                        GameEngine.musicIsPlaying = false;
                    } );
                    music.setOnErrorListener( this );
                    
                    music.setLooping( false );
                    music.start();
                    GameEngine.musicIsPlaying = true;
                }
            }
            catch ( Exception ex )
            {
                ex.getMessage();
            }
        }
        
        return 0;
    }
    
    
    /**
     * Fade music out method
     */
    public ValueAnimator fadeOutMusic()
    {
        ValueAnimator fadeOut    = ValueAnimator.ofInt( GameEngine.maxVolume, 0 );
        GameEngine    gameEngine = GameEngine.getInstance( context );
        
        
        if ( music != null && GameEngine.musicIsPlaying )
        {
            fadeOut.addUpdateListener( new ValueAnimator.AnimatorUpdateListener()
            {
                @Override
                public void onAnimationUpdate( ValueAnimator animation )
                {
                    int volume = ( int ) animation.getAnimatedValue();
                    
                    if ( music != null )
                    {
                        try
                        {
                            music.setVolume( ( float ) volume / ( float ) GameEngine.maxVolume,
                                             ( float ) volume / ( float ) GameEngine.maxVolume
                                           );
                        }
                        catch ( IllegalStateException ise )
                        {
                            ise.printStackTrace();
                        }
                    }
                }
            } );
            fadeOut.setDuration( 1000 ).addListener( new AnimatorListenerAdapter()
            {
                @Override
                public void onAnimationEnd( Animator animation )
                {
                    super.onAnimationEnd( animation );
                    
                    if ( music != null )
                    {
                        float volume = ( float ) (GameEngine.musicVolume / GameEngine.maxVolume);
                        
                        try
                        {
                            music.stop();
                            music.release();
                            GameEngine.musicIsPlaying = false;
                        }
                        catch ( IllegalStateException ise )
                        {
                            ise.printStackTrace();
                        }
                        //                    music.setVolume( volume, volume );
                    }
                }
            } );
        }
        
        //
        fadeOut.start();
        gameEngine.animatorList.add( fadeOut );
        
        return fadeOut;
    }
    
    
    /**
     * For music only
     *
     * @param soundIndex
     *
     * @return
     */
    public int playBgSfx( int soundIndex )
    {
        return playBgSfx( soundIndex, PLAY );
    }
    
    public int playBgSfx( int soundIndex, int soundType )
    {
        // Try and play it in the SoundPool and hope it does not fail
        play( soundIndex, soundType, 0 );
//        Log.d( "Media Error", "Attempted to play sound in SoundPool" );
        
        return 0;
    }
    
    
    /**
     * Release to sound player
     */
    public void destroyAll()
    {
        if ( soundPool != null )
        {
            for ( SoundPool sounds : soundPool )
            {
                sounds.release();
                sounds = null;
            }
        }
        
        if ( music != null )
        {
            music.release();
            music = null;
        }
        
        if ( sfx != null )
        {
            sfx.release();
            sfx = null;
        }
        
        //
        for ( MediaPlayer mediaPlayer : mediaList )
        {
            mediaPlayer.release();
        }
    }
    
    
    /**
     * Release all soundPool instances
     */
    public void releaseAll()
    {
        if ( soundPool != null )
        {
            for ( int y = 0; y < soundPoolcount; y++ )
            {
                for ( int i = 0; i < SOUNDS_PER_POOL; i++ )
                {
                    if ( (y * SOUNDS_PER_POOL) + i >= soundEffects.length )
                    {
                        break;
                    }
                    
                    // Unload then release
                    soundPool[ y ].unload( soundEffects[ (y * SOUNDS_PER_POOL) + i ] );
                }
                
                soundPool[ y ].release();
            }
        }
    }
    
    /**
     * Sound pool allocation
     */
    private SoundPool createSoundPool()
    {
        SoundPool soundPool = null;
        
        //
        if ( Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP )
        {
            AudioAttributes audioAttributes;
            audioAttributes = new AudioAttributes.Builder().setUsage( AudioAttributes.USAGE_MEDIA )
                                                           .setContentType( AudioAttributes.CONTENT_TYPE_MUSIC )
                                                           .build();
            //
            soundPool = new SoundPool.Builder().setMaxStreams( maxStreams ).setAudioAttributes( audioAttributes ).build();
        }
        else
        {
            soundPool = new SoundPool( maxStreams, AudioManager.STREAM_MUSIC, 0 );
        }
        
        return soundPool;
    }
    
    
    /**
     * Return when loading files are complete
     *
     * @param soundPool
     * @param sampleId
     * @param status
     *
     * @Override
     */
    public void onLoadComplete( SoundPool soundPool, int sampleId, int status )
    {
        // Start the game once all sounds are loaded
        // Need to display a loading screen for this too.
        
        soundsLoaded++;
        
        Log.d( "Sound Loader", "Current Resource: " + sampleId + ", Loaded: " + soundsLoaded + " / " + maxSounds );
        
        if ( soundsLoaded >= maxSounds && onSoundsLoadedListener != null )
        {
            onSoundsLoadedListener.onSoundsLoaded();
        }
    }
    
    @Override
    public boolean onError( MediaPlayer mp, int what, int extra )
    {
        //mp.release();
        //
        clearSoundEffectsBuffer();
        errorsCaused++;
        Log.d( "Media Error", "Errors counted: " + errorsCaused );
        
        return true;
    }
    
    
    /**
     * Help to reduce sound errors
     */
    public void clearSoundEffectsBuffer()
    {
        for ( MediaPlayer mediaPlayer : mediaList )
        {
            mediaPlayer.release();
        }
        
        mediaList.clear();
    }
}
 
 
 /*   public int playBgSfx( int soundIndex, int soundType )
    {
        //        if ( errorsCaused > 2 )
        {
            // Try and play it in the SoundPool and hope it does not fail
            play( soundIndex, soundType, 0 );
            Log.d( "Media Error", "Attempted to play sound in SoundPool" );
        }
        else
        {
            if ( (GameEngine.systemFlags & GameEngine.SFX_OFF) == 0 && soundPool != null )
            {
                try
                {
                    if ( soundType == STOP && sfx != null )
                    {
                        sfx.stop();
                        sfx.release();
                    }
                    else
                    {
                        if ( sfx == null )
                        {
                            sfx = new MediaPlayer();
                            sfx.setOnErrorListener( this );
                        }
                        else
                        {
                            try
                            {
                                sfx.reset();
                            }
                            catch ( IllegalStateException ise )
                            {
                                ise.printStackTrace();
                            }
                        }
*//*
                    if ( sfx != null )
                    {
                        sfx.release();
                    }
                    
*//*
                        Uri mediaPath = Uri.parse( "android.resource://" + context.getPackageName() + "/" + allSounds[ soundIndex ] );
                        sfx.setDataSource( context, mediaPath );
                        sfx.prepare();
                        //                        sfx.start();
                        
*//*
                        sfx = MediaPlayer.create( context, allSounds[ soundIndex ] );
*//*
                        sfx.setOnCompletionListener( new MediaPlayer.OnCompletionListener()
                        {
                            @Override
                            public void onCompletion( MediaPlayer mp )
                            {
                                mp.release();
                                //                                mp.reset();
*//*
                                if ( mediaList.contains( mp ) )
                                {
                                    mediaList.remove( mp );
                                }
*//*
                            }
                        } );
                        
                        //
*//*
                        if ( !mediaList.contains( sfx ) )
                        {
                            mediaList.add( sfx );
                        }
*//*
                        
                        //
                        sfx.start();
                    }
                }
                catch ( Exception ex )
                {
                    ex.printStackTrace();
                }
            }
        }
        
        return 0;
    }
*/



/*
    public int playBgMusic( int soundIndex, int soundType )
    {
        if ( ((GameEngine.systemFlags & GameEngine.MUSIC_OFF) == 0 || soundType == STOP) && bgMusic != null )
        {
            try
            {
                if ( soundType == STOP )
                {
                    if ( music != null )
                    {
                        music.stop();
                        music.release();
                        GameEngine.musicIsPlaying = false;
                    }
                }
                else if ( soundType == LOOP )
                {
                    if ( music == null )
                    {
                        music = new MediaPlayer();
                    }
                    else
                    {
                        try
                        {
                            music.reset();
                        }
                        catch ( IllegalStateException ise )
                        {
                            ise.printStackTrace();
                        }
                    }
                    
                    Uri mediaPath = Uri.parse( "android.resource://" + context.getPackageName() + "/" + bgMusic[ soundIndex ] );
                    music.setDataSource( context, mediaPath );
                    music.prepare();
                    //                    music.start();
                    
                    // All sounds are listed
                    //                    music = MediaPlayer.create( context, bgMusic[ soundIndex ] );
                    music.setOnCompletionListener( mp -> {
                        mp.release();
                        GameEngine.musicIsPlaying = false;
                    } );
                    music.setOnErrorListener( this );
                    
                    music.setLooping( true );
                    music.start();
                    GameEngine.musicIsPlaying = true;
                }
                else
                {
                    if ( music == null )
                    {
                        music = new MediaPlayer();
                    }
                    else
                    {
                        try
                        {
                            music.reset();
                        }
                        catch ( IllegalStateException ise )
                        {
                            ise.printStackTrace();
                        }
                    }
                    
                    // All sounds are listed
                    Uri mediaPath = Uri.parse( "android.resource://" + context.getPackageName() + "/" + bgMusic[ soundIndex ] );
                    music.setDataSource( context, mediaPath );
                    music.prepare();
*/
/*
                    music = MediaPlayer.create( context, bgMusic[ soundIndex ] );
*//*

                    music.setOnCompletionListener( mp -> {
                        mp.release();
                        GameEngine.musicIsPlaying = false;
                    } );
                    music.setOnErrorListener( this );
                    
                    music.setLooping( false );
                    music.start();
                    GameEngine.musicIsPlaying = true;
                }
            }
            catch ( Exception ex )
            {
                ex.getMessage();
            }
        }
        
        return 0;
    }
*/
